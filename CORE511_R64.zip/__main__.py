"""Core of Life R64: preregistration-safe game updater and website correction."""
import argparse,hashlib,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path
STATE=Path('/var/lib/core511/state.json')
ACTIVE=Path('/var/lib/core511/r64-updates/active.json')

def run(args):subprocess.run(args,check=True)
def state_hash():return hashlib.sha256(STATE.read_bytes()).hexdigest() if STATE.exists() else None

def workflow(game,site,args,call=run,fingerprint=state_hash):
 def invoke(file,action):return call([sys.executable,'-u',str(file),action])
 if args.site_only:
  if args.recover:raise RuntimeError('Site kurtarma için --site-only --rollback-latest kullanın')
  return invoke(site,args.action)
 if args.game_only:return invoke(game,args.action)
 if args.check:
  invoke(site,'--check');invoke(game,'--check');return
 if args.recover:
  if ACTIVE.exists():invoke(game,'--recover')
  else:print('Yarım oyun kurulumu yok.',flush=True)
  print('Kurtarma tamamlandıktan sonra --apply ile paket tamamlanabilir.',flush=True);return
 if args.rollback_latest:
  # Game must be empty and in prereg/maintenance before any rollback.
  invoke(game,'--check');invoke(site,'--rollback-latest');invoke(game,'--rollback-latest');return
 invoke(site,'--check')
 before=fingerprint();invoke(game,'--apply');changed=fingerprint()!=before
 try:invoke(site,'--apply')
 except BaseException:
  if changed:
   print('Site kurulumu tamamlanmadı; bu işlemde kurulan oyun sürümü geri alınıyor.',flush=True)
   invoke(game,'--rollback-latest')
  raise
 print('R64 OYUN VE SITE TAMAMLANDI. Ön kayıt ayarı korundu. Hesap servisi yeniden başlatılmadı.',flush=True)

def main(archive=None,argv=None):
 parser=argparse.ArgumentParser(description=__doc__);group=parser.add_mutually_exclusive_group(required=True)
 for name in ('check','apply','recover','rollback-latest'):group.add_argument('--'+name,action='store_true')
 scope=parser.add_mutually_exclusive_group();scope.add_argument('--game-only',action='store_true');scope.add_argument('--site-only',action='store_true')
 args=parser.parse_args(argv);args.action=next('--'+k.replace('_','-') for k in ('check','apply','recover','rollback_latest') if getattr(args,k))
 if os.geteuid()!=0:raise RuntimeError('Root olarak çalıştırın')
 os.umask(0o077)
 with zipfile.ZipFile(archive or Path(sys.argv[0]).resolve()) as z,tempfile.TemporaryDirectory(prefix='core-r64-') as temp:
  files=json.loads(z.read('bundle.json'))
  if set(files)!={'GAME_R64.zip','SITE_R64.zip'}:raise RuntimeError('Paket listesi geçersiz')
  for name,sha in files.items():
   data=z.read(name)
   if hashlib.sha256(data).hexdigest()!=sha:raise RuntimeError('Paket doğrulanamadı: '+name)
   (Path(temp)/name).write_bytes(data)
  return workflow(Path(temp)/'GAME_R64.zip',Path(temp)/'SITE_R64.zip',args)
if __name__=='__main__':
 try:main()
 except (Exception,KeyboardInterrupt) as error:
  print('DURDU: '+(str(error) if isinstance(error,RuntimeError) else type(error).__name__),flush=True);sys.exit(1)
