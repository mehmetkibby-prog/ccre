import hashlib,json,os,sys,tempfile,zipfile
from pathlib import Path
archive=Path(sys.argv[0]).resolve();os.umask(0o077)
try:
 with zipfile.ZipFile(archive) as z,tempfile.TemporaryDirectory(prefix='core-disk-cleanup-') as temp:
  manifest=json.loads(z.read('modules.json'))
  expected={'installer.py','storage.py','r63_support.py','retention.py','central.mjs','cleanup.py','runtime_stage.py','inplace_stage.py','ingress_stage.py','client_stage.py','rollback_scope.py','schema_sources.json','artifact_sources.json'}
  if set(manifest)!=expected or len(z.namelist())!=len(set(z.namelist())):raise RuntimeError('Paket dosya listesi bozuk')
  for name,sha in manifest.items():
   data=z.read('support/'+name)
   if hashlib.sha256(data).hexdigest()!=sha:raise RuntimeError('Paket bütünlüğü bozuk')
   (Path(temp)/name).write_bytes(data)
  sys.path.insert(0,temp)
  from cleanup import main
  main()
except BlockingIOError:
 print('DURDU: Başka bir kurulum veya yedek çalışıyor. Bitince aynı komutu tekrar çalıştırın.',flush=True);sys.exit(1)
except (Exception,KeyboardInterrupt) as e:
 message=str(e) if isinstance(e,RuntimeError) or type(e).__name__=='Refused' else type(e).__name__
 if isinstance(e,FileNotFoundError) and e.filename:message+=': '+str(e.filename)
 print('DURDU: '+message,flush=True);sys.exit(1)
