// Called inside the existing chest receipt transaction: a replay never posts twice.
// A chest has at most 16 configured reward rows. No extra writer job or broadcast scan.
export function azrailLinesR62(player,rewards){
 const prefix=`${player.name}, Azrail Sandığı: `,parts=rewards.length?rewards.map(row=>`${row.name} ×${row.amount}`):['Bu sandıktan eşya çıkmadı.'];
 const lines=[];let line=prefix;
 for(const part of parts){if(prefix.length+part.length>140)throw Error('azrail_item_name_bound');if(line!==prefix&&line.length+2+part.length>140){lines.push(line);line=prefix;}line+=(line===prefix?'':', ')+part;}
 lines.push(line);return lines;
}
export function announceAzrailR62(db,player,rewards,now,publish){
 if(process.env.CORE511_R62_AZRAIL!=='1')return;
 if(rewards.length>16)throw Error('azrail_reward_bound');
 const insert=db.prepare("INSERT INTO messages(player_id,player_name,recipient_id,scope,area,channel,body,created_at) VALUES(?,'Sunucu',NULL,'world',NULL,1,?,?) RETURNING *");
 const cycle=typeof publish==='function'?db.prepare('SELECT cycle FROM world_state WHERE id=1').get().cycle:null;
 for(const body of azrailLinesR62(player,rewards)){
  const message=insert.get(player.id,body,Math.floor(now/1000));
  // Empty room list denotes the existing native world-chat audience. The
  // outbox captures authenticated recipients and delivers after commit/fsync.
  if(typeof publish==='function')publish(cycle,[],{type:'chat_message',chatScope:'world',cycle,eventId:`chat-message:${message.id}`,message,serverAt:now});
 }
}
