import fs from 'node:fs';import {createHash} from 'node:crypto';
const sha=s=>createHash('sha256').update(s).digest('hex');
export async function load(url,context,next){
 const result=await next(url,context);if(!url.endsWith('/benchmark/my-load-real.mjs'))return result;
 let source=String(result.source),original=source;const edits=[];function edit(from,to){if(source.split(from).length!==2)throw Error('recovery_observer_anchor:'+from.slice(0,60));source=source.replace(from,to);edits.push({from,to});}
 source="import {observeRecovery} from "+JSON.stringify(new URL('./recovery-observer.mjs',import.meta.url).href)+";\n"+source;
 edit(' const receiptCount=()=>'," const recoveryObserver=observeRecovery(s,sql,clients,OUT);\n const receiptCount=()=>");
 edit('clearInterval(timer);timer=null;const drainStarted=',"clearInterval(timer);timer=null;recoveryObserver.start();const drainStarted=");
 edit('  const duplicateKeys=sql.prepare(',"  await recoveryObserver.wait();\n  const duplicateKeys=sql.prepare(");
 edit('  const plain={affected:0,',"  await recoveryObserver.wait();\n  const plain={affected:0,");
 let inverse=source;for(const {from,to}of [...edits].reverse())inverse=inverse.replace(to,from);inverse=inverse.slice(inverse.indexOf('\n')+1);if(inverse!==original)throw Error('recovery_observer_inverse');
 fs.writeFileSync(process.env.CORE_OUT+'.recovery-driver-proof.json',JSON.stringify({originalLoadedSHA256:sha(original),loadedSHA256:sha(source),inverseEqual:true,edits},null,2));return {...result,source};
}
