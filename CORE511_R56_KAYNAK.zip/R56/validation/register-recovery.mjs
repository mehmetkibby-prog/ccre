import {register} from 'node:module';register(new URL('./recovery-loader.mjs',import.meta.url));
