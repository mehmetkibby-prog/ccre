import {register} from 'node:module';register(new URL('./portable-loader.mjs',import.meta.url));
