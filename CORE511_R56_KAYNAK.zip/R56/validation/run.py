#!/usr/bin/env python3
"""Standalone isolated native game tests. No live service or database is opened."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,platform,re,shlex,signal,subprocess,sys
R=Path(__file__).resolve().parents[1];C=R/'working/core511-source/scripts/core511'
sha=lambda b:hashlib.sha256(b).hexdigest()
def core_identity():
 rows=[]
 def visit(folder):
  for p in sorted(folder.iterdir(),key=lambda p:p.name):
   if p.name.startswith('.') or p.name in ('evidence','node_modules') or p.is_symlink():continue
   if p.is_dir():visit(p)
   elif p.is_file() and p.suffix in ('.mjs','.js','.json','.c'):
    b=p.read_bytes();rows.append({'path':p.relative_to(C).as_posix(),'bytes':len(b),'sha256':sha(b)})
 visit(C);return sha(json.dumps({'kind':'core511-source-candidate-v1','baselineManifestSha256':'bb3a6cc689c695d97f127a2eefb9ad141b0e655eb39bbebeea5f05704074ad3b','files':rows},ensure_ascii=False,separators=(',',':')).encode())
def assignments(file):
 values={}
 for line in file.read_text().splitlines():
  if not line.strip() or line.lstrip().startswith('#'):continue
  key,eq,value=line.partition('=');assert eq and re.fullmatch('[A-Z_][A-Z0-9_]*',key);values[key]=value
 return values
read=lambda p:json.loads(p.read_bytes())
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('case',choices=['matrix','crash','plain','verify']);p.add_argument('--players',type=int,choices=[30,50,70,80,100],default=100);p.add_argument('--repeat',type=int,default=1);p.add_argument('--out',type=Path);p.add_argument('--dry-run',action='store_true');a=p.parse_args()
 meta=read(R/'SOURCE.json');identity=core_identity();assert identity==meta['sourceCore'],'Source identity differs'
 node=R/'runtime/node-v22.22.0-linux-x64/bin/node';assert node.is_file();os.chmod(node,node.stat().st_mode|0o100)
 observed=subprocess.check_output([str(node),'--version'],text=True).strip();assert observed==meta['nodeVersion']
 assert sha((R/'working/native510-bb3a6cc689c6/realm-package-manifest.json').read_bytes())==meta['nativeManifestSHA256']
 if a.case=='verify':print(json.dumps({'status':'PASS','version':meta['version'],'sourceCore':identity,'node':observed}));return
 total=a.players if a.case=='matrix' else 80;duration=60 if a.case=='matrix' else 50
 name=f'{a.case}-{total}-{a.repeat}';out=(a.out or R/'evidence'/name).resolve()
 profile={**assignments(R/'profiles/features.env'),**assignments(R/'profiles'/(a.case+'.env'))}
 runtime={'COL_CLOUD_ISOLATED_FIXTURE':'1','R35_CORE_REGRESSION':'1','CORE511_R40_BAG_LIMIT':'1','COL_TEST_ACORN_MODULE':str(R/'working/deps/build/node_modules/acorn/dist/acorn.mjs'),'COL_CORE511_SCOPE_MODULE':str(R/'working/deps/build/node_modules/eslint-scope'),'CORE511_LOCAL_REPRO_AUTHORIZED':'1','COL_HANDOFF_PLAYERS':str(total),'CORE_PER':str((total+3)//4),'CORE_MS':str(duration*1000),'CORE_OUT':str(out/'result.json')}
 runtime['NODE_OPTIONS']='--no-warnings --import '+str(R/'validation/register.mjs')+' --import '+str(R/'tests-r57/observe-full-rewards.mjs')+' --import '+str(R/'validation/register-recovery.mjs')
 settings={**profile,**runtime};command=[str(node),'--no-lazy',str(C/'benchmark/my-load-real.mjs')]
 if a.dry_run:print(shlex.join(['env',*[k+'='+v for k,v in settings.items()],*command]));return
 out.mkdir(parents=True,exist_ok=False)
 env={k:v for k,v in os.environ.items() if not k.startswith(('CORE_','CORE511_','COL_','R35_','R43_','R47_','R51_','R57_','R61_')) and k!='NODE_OPTIONS'};env.update(settings)
 def cgroup(name):
  f=Path('/sys/fs/cgroup')/name;return f.read_text().strip() if f.exists() else None
 files=[*sorted((R/'validation').glob('*.mjs')),Path(__file__),R/'validation/portable-loader.mjs',R/'validation/register.mjs',R/'tests-r57/observe-full-rewards.mjs',R/'tests-r57/full-reward-tracker.mjs',R/'profiles/features.env',R/'profiles'/(a.case+'.env'),C/'benchmark/my-load-real.mjs',*sorted((R/'tests/native-fixture-support').rglob('*'))];files=[f for f in files if f.is_file()]
 proof={'status':'RUNNING','version':meta['version'],'sourceCore':identity,'case':a.case,'players':total,'seconds':duration,'repeat':a.repeat,'command':command,'environment':settings,'nodeVersion':observed,'nodeSHA256':sha(node.read_bytes()),'cpuMax':cgroup('cpu.max'),'memoryMax':cgroup('memory.max'),'platform':platform.platform(),'liveVds':False,'sourceTree':str(R),'testFilesSHA256':{str(f.relative_to(R)):sha(f.read_bytes()) for f in files},'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (out/'source.json').write_text(json.dumps(proof,indent=2)+'\n');(out/'command.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\ncd '+shlex.quote(str(R))+'\n'+shlex.join(['env',*[k+'='+v for k,v in settings.items()],*command])+'\n')
 print('START '+meta['version']+' '+name,flush=True)
 with (out/'run.log').open('w') as log:
  child=subprocess.Popen(command,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=child.wait(timeout=duration+420)
  except BaseException:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   raise
 proof.update(exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceUnchanged=core_identity()==identity,testFilesUnchanged=all(sha((R/f).read_bytes())==h for f,h in proof['testFilesSHA256'].items()))
 checks={};summary={}
 try:
  result=read(out/'result.json');accept=read(out/'result.acceptance.json');shutdown=read(out/'result.shutdown.json');driver=read(out/'result.json.driver-proof.json');log=(out/'run.log').read_text()
  channels=result.get('handoffChannels',{});before={x['channel']:x['incarnation'] for x in channels.get('before',[])};after={x['channel']:x['incarnation'] for x in channels.get('after',[])}
  checks={'exitZero':code==0,'sourceUnchanged':proof['sourceUnchanged'],'testFilesUnchanged':proof['testFilesUnchanged'],'completed':result.get('completed') is True,'population':sum(c['players'] for c in result.get('channels',[]))==total,'driverInverse':driver.get('inverseEqual') is True,'noChildExit':'CHILD_EXIT ' not in log,'sameFourIncarnations':len(before)==4 and before==after,'noFaults':not result.get('faults'),'noUnacked':result.get('unacked')==0,'noUnfinishedRewards':accept.get('unfinishedRewards')==0,'noDuplicateKeys':accept.get('duplicateKeys')==0,'cleanShutdown':shutdown.get('clean') is True}
  drain=read(out/'result.drain120.json');checks['drain120Complete']=len(drain)==4 and drain[-1]['second']==120 and drain[-1]['pending']==0 and drain[-1]['duplicateKeys']==0
  if a.case=='crash':checks['relogin24of24']=accept.get('affected')==24 and accept.get('passed')==24 and accept.get('sameIncarnations') is True
  else:checks['noDisconnects']=result.get('disconnects')==0
  summary={'drain120':[{k:x[k] for k in ('second','elapsedMs','pending','duplicateKeys','reasons')} for x in drain],'version':meta['version'],'case':a.case,'players':total,'repeat':a.repeat,'sourceCore':identity,'checks':checks,'latency':result.get('latency'),'durableDeath':result.get('rewardObservationR54',{}).get('durableDeathFromInputMs'),'allRewards':result.get('rewardObservationR54',{}).get('fullRewardsR57',{}).get('deathAndAllRewardsMs'),'disconnects':result.get('disconnects'),'unacked':result.get('unacked'),'childExitCount':len(re.findall(r'^CHILD_EXIT ',log,re.M)),'channels':channels,'acceptance':accept,'resources':result.get('resources'),'faults':result.get('faults'),'actionRejections':result.get('errCodes')}
 except Exception as error:proof['analysisError']=str(error)
 passed=bool(checks) and all(checks.values());proof['status']='PASS' if passed else 'FAIL';summary['status']=proof['status'];(out/'source.json').write_text(json.dumps(proof,indent=2)+'\n');(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(json.dumps({'status':proof['status'],'case':name,'failed':[k for k,v in checks.items() if not v],'allRewards':summary.get('allRewards'),'disconnects':summary.get('disconnects'),'reloginPassed':summary.get('acceptance',{}).get('passed'),'folder':str(out)}),flush=True)
 if not passed:raise SystemExit(1)
if __name__=='__main__':main()
