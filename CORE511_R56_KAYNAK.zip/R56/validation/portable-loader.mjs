// Validation-only portability and observations; production source stays byte exact.
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath,pathToFileURL} from 'node:url';import {createHash} from 'node:crypto';
import {load as fixtureLoad,resolve as fixtureResolve} from '../tests/native-fixture-support/cloud-fixture-loader.mjs';
const root=path.resolve(import.meta.dirname,'..'),sha=s=>createHash('sha256').update(s).digest('hex'),seen=new Set();
export async function resolve(specifier,context,next){
 let name=specifier.startsWith('file:')?fileURLToPath(specifier):specifier;
 for(const prefix of ['/tmp/core511-build-deps/','/tmp/col-perf-r11-dependencies/'])if(name.startsWith(prefix))name=path.join(root,'working/deps/build',name.slice(prefix.length));
 const result=await fixtureResolve(name!==specifier?pathToFileURL(name).href:specifier,context,next);
 if(result.url?.startsWith('file:')){
  const file=fileURLToPath(result.url),real=fs.existsSync(file)?fs.realpathSync(file):file;
  if(real.startsWith('/workspace/ccre/')&&!real.startsWith(root+'/'))throw Error('handoff_external_workspace_dependency:'+real);
  if(real.startsWith('/tmp/core511-build-deps/')||real.startsWith('/tmp/col-perf-r11-dependencies/'))throw Error('handoff_external_dependency:'+real);
  if(process.env.CORE_OUT&&!seen.has(real)){seen.add(real);fs.appendFileSync(process.env.CORE_OUT+'.imports-'+process.pid+'.jsonl',JSON.stringify({path:real,insideTree:real.startsWith(root+'/')})+'\n');}
 }
 return result;
}
export async function load(url,context,next){
 const result=await fixtureLoad(url,context,next);
 if(!url.endsWith('/benchmark/my-load-real.mjs'))return result;
 const total=Number(process.env.COL_HANDOFF_PLAYERS);if(![30,50,70,80,100].includes(total))throw Error('handoff_population_invalid');
 const distribution=[1,2,3,4].map(ch=>Math.floor(total/4)+([2,3,4,1].indexOf(ch)<total%4?1:0));
 let source=String(result.source);const original=source,edits=[];
 function change(from,to){if(source.split(from).length!==2)throw Error('handoff_anchor:'+from.slice(0,70));source=source.replace(from,to);edits.push({from,to});}
 change('for(let channel=1;channel<=4;channel++)for(let i=0;i<PER;i++)',`for(let channel=1;channel<=4;channel++)for(let i=0;i<${JSON.stringify(distribution)}[channel-1];i++)`);
 change("for(let i=0;i<PER;i++)for(const channel of [2,3,4,1])await connect(players.find(p=>p.channel===channel&&p.id.endsWith(':'+((channel-1)*25+i))));","for(let i=0;i<PER;i++)for(const channel of [2,3,4,1]){const p=players.find(p=>p.channel===channel&&p.id.endsWith(':'+((channel-1)*25+i)));if(p)await connect(p);}");
 change('clients.length===PER*4&&clients.every',`clients.length===${total}&&clients.every`);
 change('yuk_basladi ${PER*4} oyuncu','yuk_basladi ${clients.length} oyuncu');
 change('globalThis.__chStart=chState();',"globalThis.__chStart=chState();globalThis.__handoffChannelsStart=s.supervisor.snapshot().map(r=>({channel:r.channel,incarnation:r.incarnation}));");
 change('const out={completed:true,',"const out={completed:true,handoffChannels:{before:globalThis.__handoffChannelsStart,after:s.supervisor.snapshot().map(r=>({channel:r.channel,incarnation:r.incarnation}))},");
 change(" const errors=[];for(const fn of cleanup.toReversed())try{await fn();}catch(e){errors.push(e.message);}"," const errors=[];for(const fn of cleanup.toReversed())try{await fn();}catch(e){errors.push({code:e.code??null,message:e.message});}\n const shutdownFaults=s?.faultEvidence?.()??[],hostClosed=s?.host?s.host.closed===true:true;const shutdown={afterCleanup:true,hostClosed,cleanupErrors:errors,faults:shutdownFaults,clean:hostClosed&&!errors.length&&!shutdownFaults.length};fs.writeFileSync(OUT.replace(/\\.json$/,'.shutdown.json'),JSON.stringify(shutdown,null,2));if(!shutdown.clean)process.exitCode=1;");
 let inverse=source;for(const {from,to}of [...edits].reverse())inverse=inverse.replace(to,from);if(inverse!==original)throw Error('handoff_inverse_mismatch');
 fs.writeFileSync(process.env.CORE_OUT+'.driver-proof.json',JSON.stringify({originalSHA256:sha(original),loadedSHA256:sha(source),inverseEqual:true,players:total,distribution,edits},null,2));
 return {...result,source};
}
