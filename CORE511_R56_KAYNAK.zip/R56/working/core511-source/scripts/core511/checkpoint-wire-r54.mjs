import {createHash} from 'node:crypto';
import {deflateRawSync,inflateRawSync} from 'node:zlib';
import {rewardAsyncReplyR54} from './r54-options.mjs';
import {demand} from './contract.mjs';
const WIRE=224*1024,RAW=768*1024;
const digest=value=>createHash('sha256').update(value).digest('hex');
// A lossless, request-local wire image. No new disk rows, authority, gameplay
// fields or raised IPC limit. Small checkpoints keep their exact old shape.
export function packCheckpointR54(value){
 const text=JSON.stringify(value),bytes=Buffer.byteLength(text);
 if(bytes<=WIRE)return value;
 if(!rewardAsyncReplyR54||bytes>RAW)return null;
 const packed={codec:'deflate-r54',bytes,sha256:digest(text),data:deflateRawSync(text,{level:1}).toString('base64')};
 return Buffer.byteLength(JSON.stringify(packed))<=WIRE?packed:null;
}
export function unpackCheckpointR54(value){
 if(!value?.codec)return value;
 demand(rewardAsyncReplyR54&&value.codec==='deflate-r54'&&Object.keys(value).sort().join(',')==='bytes,codec,data,sha256'&&Number.isSafeInteger(value.bytes)&&value.bytes>WIRE&&value.bytes<=RAW&&typeof value.data==='string'&&value.data.length<=WIRE&&/^[A-Za-z0-9+/]*={0,2}$/.test(value.data)&&typeof value.sha256==='string'&&/^[a-f0-9]{64}$/.test(value.sha256),'checkpoint_join_encoding');
 let text;
 try{text=inflateRawSync(Buffer.from(value.data,'base64'),{maxOutputLength:value.bytes}).toString('utf8');}
 catch{demand(false,'checkpoint_join_encoding');}
 demand(Buffer.byteLength(text)===value.bytes&&digest(text)===value.sha256,'checkpoint_join_encoding');
 try{return JSON.parse(text);}catch{demand(false,'checkpoint_join_encoding');}
}
