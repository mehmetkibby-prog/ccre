# Bağımsız kalıcı ödül kurtarma testi

Linux x86_64 / glibc >=2.28, Python 3.10+ gerekir. Node22.22.0, kilitli bağımlılıklar ve izole native test fixture'ları dahildir. Canlı VDS üzerinde çalıştırmayın; geçici oyuncu/SQLite/sunucu süreçleri kullanır. Tam mevcut core511-source ve native510 kaynak dışa aktarımı paketlenmiştir; üretim medyası/derlenmiş web dosyalarından mevcut olmayanlar NATIVE_EXPORT.json içinde listelidir. Sıfırdan canlı oyun kurulum arşivi değildir.

```bash
python3 validation/run.py verify
python3 validation/run.py crash --repeat 1
python3 validation/run.py crash --repeat 2
python3 validation/run.py crash --repeat 3
python3 validation/run.py plain --repeat 1
python3 validation/run.py plain --repeat 2
```

Her komutu sırayla çalıştırın. Crash: 80 oyuncu / 4 kanal, oyuncu başına60 canavar,50s,HP500,GEAR15s,POKE25s,HIT_N3,24tekrar giriş. Plain sadece hata enjeksiyonu/yeniden giriş değişkenleri çıkarılmış aynı yük. Profiles tüm CORE_* ve CORE511_* ortamını içerir. `--dry-run` kesin komutu basar; her koşu command.sh/source.json dosyasında aynısını kaydeder. Yük bittiğinde120s otomatik sunucu boşaltması eklenir ve0/30/60/120 noktalarındaSQL okunur. Zamanlayıcı gecikmeleri elapsedMs alanındadır. Elle claim veya ödül bitiş işareti yazılmaz. Kalıcı ölüm/ödül mantığı gerçek ilgili sürüm kaynaklarıdır.

`summary.json` ham runner sonucu; `result.acceptance.json` kullanıcı ödül/tekrar giriş kriterleridir. Eski kapalı soketlerin cevaplanmamış istekleri runner FAIL yapabilir; bunu sıfırlamayın. Son adayda client-audit.json bu isteklerin hangi sokette olduğunu açıklar. Source.json başta/sonda kaynak ve testdosyası SHA kontrolünü içerir. Recovery-driver-proof.json ve driver-proof.json salt test adaptörlerinin tersine çevirme kanıtlarıdır. Portable-loader eski test bağımlılık yollarını paketin içine yönlendirir. Native dosyaların özgün hashleri değiştirilmez.

Yeni R62'de `CORE511_R62_REWARD_RECOVERY=1` seçili kurulum profilidir; kaynak varsayılanı0. EskiR62/R61/R56 kodları bu anahtarla taklit edilmez, ayrı tam ağaçlardır. `SOURCE.json` gerçek kimliği gösterir. Düzeltme için recovery-tests/recovery.test.mjs dosyası vardır.

Yeni R62'nin normal yük kontrolü ayrı runner kullanır (120s ek boşaltma/routeobserver olmadan):

```bash
python3 validation/run-matrix.py matrix --players 100
```

Matrix:100 oyuncu, bütün oyuncular savaşır, dörtkanal toplam240paylaşılan canavar,60s. Crash/plain4800canavardan farklıdır. R61/R62_BASE kaynaklarında standart validation/run.py matrix çalışır fakat120s ek boşaltma içerir. R56 paketi bu teslimde crash/plain karşılaştırması için hazırlanmıştır. Tarihsel eski matrix sayıları mevcut GitHub r62-claude-handoff teslimindedir. Bu sürümde yeniden ölçülen normal100 sonucu yeni rapordadır.
