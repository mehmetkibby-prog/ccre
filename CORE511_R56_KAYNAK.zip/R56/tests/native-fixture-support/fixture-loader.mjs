import {load as prior} from './support/r43-fixture-loader.mjs';
export async function load(url,context,next){
 const result=await prior(url,context,next);
 if(url.includes('/performance_r53_work/working/')&&url.endsWith('/tests/attack-native.test.mjs'))return {...result,source:String(result.source).replace("'49d51d3adaf72f25a05fe269c4af911c0cfb2e23533fa13a03f502868176bca3'",'p.generatedSha256')};
 if(process.env.R51_BROWSER_FIXTURE==='1'&&url.endsWith('/native-http-server.mjs')){
  const original="JSON.parse(fs.readFileSync(new URL('./generated/native-http-composition-proof.json',import.meta.url)))";
  let source=String(result.source);if(source.split(original).length!==2)throw Error('r51_browser_proof_anchor');
  source=source.replace(original,"(await import('./compose-native-http.mjs')).composeNativeHttp().proof");return {...result,source};
 }
 if(process.env.R47_FRAME_DIAGNOSTIC==='1'&&url.endsWith('/reliable-stream.mjs')){
  const anchor="size=Buffer.byteLength(text);";let source=String(result.source);
  if(source.split(anchor).length!==2)throw Error('frame diagnostic anchor drift');
  source=source.replace(anchor,anchor+"if(size>1048576)console.warn('TEST_FRAME_LIMIT',JSON.stringify({type:value?.type,method:value?.method??null,bytes:size,kind:value?.payload?.kind,payloadKeys:Object.keys(value?.payload??{}),nestedArrays:Object.fromEntries(Object.entries(value?.payload?.payload??{}).filter(([k,v])=>Array.isArray(v)).map(([k,v])=>[k,{rows:v.length,bytes:Buffer.byteLength(JSON.stringify(v))}])),arrays:Object.fromEntries(Object.entries(value?.payload??{}).filter(([k,v])=>Array.isArray(v)).map(([k,v])=>[k,v.length]))}));");
  return {...result,source};
 }
 if(url.endsWith('/tests/presence-outbox.test.mjs')){
  // This historical test predates R35 compact receipts (unchanged in R46/47).
  // Replay omits cosmetic events; verify the retained durable payload exactly.
  const anchor='assert.deepEqual(json(await writer.command(peer,request)),json(result));';
  let source=String(result.source);if(source.split(anchor).length!==2)throw Error('presence_outbox_fixture_drift');
  source="import {replayValue} from '../compact-receipt.mjs';\n"+source.replace(anchor,"assert(result.result.events.length>0);assert.deepEqual(json(await writer.command(peer,request)),json(replayValue(result)));");
  return {...result,source};
 }
 return result;
}

// The source-only base omits this built native chunk. Use its exact native TS
// implementation (types erased), only in tests; no production auth is replaced.
export async function resolve(specifier,context,next){
 if(specifier.endsWith('/channel-runtime/assets/guild-village-runtime-Dke_G6YB.js'))return {url:new URL('./support/native-guild-runtime.mjs',import.meta.url).href,shortCircuit:true};
 return next(specifier,context);
}
