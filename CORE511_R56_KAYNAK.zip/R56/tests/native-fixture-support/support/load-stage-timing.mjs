// Test-only, bounded stage observations. Original promises and ordering are
// retained. Results are requested once after the measurement has ended.
export function installR43TestTiming(runtime){
 const stages={},seen=new WeakMap(),c=runtime.channel;
 function record(name,at,detail){
  const ms=performance.now()-at,s=stages[name]??={count:0,totalMs:0,maxMs:0,slowest:[]};
  s.count++;s.totalMs+=ms;s.maxMs=Math.max(s.maxMs,ms);
  if(s.slowest.length<8||ms>s.slowest.at(-1).ms){s.slowest.push({ms,at,detail});s.slowest.sort((a,b)=>b.ms-a.ms);s.slowest.length=Math.min(8,s.slowest.length);}
 }
 function wrap(object,method,name,detail=()=>undefined){
  if(!object||typeof object[method]!=='function')throw Error('missing timing hook '+name);
  const original=object[method];object[method]=function(...args){
   const at=performance.now(),meta=detail(args),result=original.apply(this,args);
   if(result?.then)result.then(()=>record(name,at,meta),()=>record(name,at,meta));else record(name,at,meta);
   return result;
  };
 }
 wrap(c.checkpoints,'drain','actorCheckpoint',a=>a[0]);
 wrap(c.combatCheckpoints,'drain','combatCheckpoint');
 wrap(c.attack,'submit','attackWriter',a=>({actor:a[0].actor,targets:a[0].payload.localScope?.targets?.length}));
 wrap(c.attack,'committed','attackRefresh');
 wrap(c.attack,'publishLocalDeath','deathPublication');
 const attack=c.attack.attack;c.attack.attack=function(input){
  const result=attack.call(this,input);
  if(result&&typeof result==='object'&&input.kernel.players.get(input.id)?.barrier){
   const elapsed=Date.now()-(input.receivedAtMs??input.now);
   record('attackBeforeBarrier',performance.now()-Math.max(0,elapsed),{actor:input.id});
  }
  return result;
 };
 const acquire=c.lanes.acquire,release=c.lanes.release;
 c.lanes.acquire=function(...args){const value=acquire.apply(this,args);if(value)seen.set(value,performance.now());return value;};
 c.lanes.release=function(lease){const at=seen.get(lease);if(at!==undefined){record('resourceLease',at,{resources:lease.keys.length});seen.delete(lease);}return release.call(this,lease);};
 process.on('message',message=>{if(message?.type==='r43-timing-snapshot')process.send({type:message.type,request:message.request,stages});});
}
