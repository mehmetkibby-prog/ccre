import {readFile} from 'node:fs/promises';
// Test-only adaptation for this source-only export: missing .d.mts declarations
// are not executable. Every present member's pinned byte/hash check is retained.
// No production module or SQL behavior is rewritten by this loader.
export async function load(url,context,next){
 const r=await next(url,context);
 if(url.endsWith('/perf-r11/tests/reward/fixture.mjs')){
  let s=String(r.source);const from="absent.some(name => name !== 'vds-server/src/loadtest-entry.mjs')";
  if(!s.includes(from))throw Error('fixture adapter anchor changed');
  s=s.replace(from,"absent.some(name => name !== 'vds-server/src/loadtest-entry.mjs' && !name.endsWith('.d.mts'))");return {...r,source:s};
 }
 return r;
}
