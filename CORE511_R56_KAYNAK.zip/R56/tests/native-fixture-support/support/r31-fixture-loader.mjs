import {load as exportLoad} from './export-fixture-loader.mjs';
// The old small process fixture bypasses NativeHttpBindings.open, which creates
// the existing R18 tower schema before owners start. Supply that SAME existing
// setup in the isolated test DB only. No production code/schema is changed.
export async function load(url,context,next){
 const r=await exportLoad(url,context,next);
 if(url.endsWith('/tests/process-fixture.mjs')){
  let s=String(r.source);const anchor='writer=new GameWriter(f.f.database,';if(!s.includes(anchor))throw Error('process fixture setup anchor drift');
  s="import {createTowerSchema} from '../tower-config.mjs';\nimport {createAdventureSchema} from '../adventure-schema.mjs';\n"+s.replace(anchor,'createTowerSchema(f.sql);createAdventureSchema(f.sql);'+anchor);
  // Old fixture callers used ticket for first entry. R29 correctly requires an
  // explicit choice on character entry. Select the former fixture distribution
  // in the TEST CLIENT, never in coordinator/authentication/production code.
  s=s.replace("http:async(action='ticket',body={})=>{const r=await core.http","http:async(action='ticket',body={})=>{if(action==='ticket'&&!core.authority.admission(id)){action='character';const counts=core.authority.counts();body={channel:[2,3,4,1].sort((a,b)=>(counts.get(a)??0)-(counts.get(b)??0))[0],...body};}const r=await core.http");
  s=s.replace("const http=async(action,body={})=>{const response=await core.http","const http=async(action,body={})=>{if(action==='ticket'&&!core.authority.admission(f.id)){action='character';const counts=core.authority.counts();body={channel:[2,3,4,1].sort((a,b)=>(counts.get(a)??0)-(counts.get(b)??0))[0],...body};}const response=await core.http");
  return {...r,source:s};
 }
 return r;
}
