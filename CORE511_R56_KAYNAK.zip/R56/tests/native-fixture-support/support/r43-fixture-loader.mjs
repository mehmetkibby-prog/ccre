import {load as previous} from './r42-fixture-loader.mjs';
export async function load(url,context,next){
 const result=await previous(url,context,next);let source=String(result.source??'');
 if(url.endsWith('/tests/pvp-native.test.mjs')){
  // R35 compact receipts deliberately omit obsolete player_state visuals.
  // The first arena round delivery must include them; replay must not. Keep
  // every durable response, reward row, event ID and nonvisual event equal.
  const anchor='const a=await authority.command(peer,request),state=capture(db.sqlite),b=await authority.command(peer,request);assert.deepEqual(json(a),json(b));';
  if(source.split(anchor).length!==2)throw Error('R43 PvP replay test anchor drift');
  source=source.replace(anchor,`const a=await authority.command(peer,request),state=capture(db.sqlite),b=await authority.command(peer,request);
   const states=a.result.events.filter(e=>e[3]?.type==='player_state');
   if(mode==='arena-round'&&phase==='before')assert.equal(states.length,3);
   assert.equal(b.result.events.filter(e=>e[3]?.type==='player_state').length,0);
   assert.deepEqual(json(b),json({...a,result:{...a.result,events:a.result.events.filter(e=>e[3]?.type!=='player_state')}}));`);
  return {...result,source};
 }
 if(url.endsWith('/tests/attack-native.test.mjs')){
  // The inherited proof predates R42's generated rules. Pin the byte-exact
  // delivered R42 files, which R43 does not modify, not the older proof hash.
  source=source.replace('p.generatedSha256',"'49d51d3adaf72f25a05fe269c4af911c0cfb2e23533fa13a03f502868176bca3'").replace('p.writerSha256',"'22c4851dfbd67315401f058d9dc746230ce5309d648f2543821f5c02f3633622'");
  source="import {replayValue} from '../compact-receipt.mjs';\n"+source;
  source=source.replace('assert.deepEqual(json(replay),json(ack));','assert(ack.result.events.some(e=>e[3]?.type===\'monster_preview\'));assert.deepEqual(json(replay),json(replayValue(ack)));');
  source=source.replace('assert.deepEqual(json(a),json(b));','assert.deepEqual(json(b),json(replayValue(a)));');
  return {...result,source};
 }
 if(url.endsWith('/tests/mixed-native.test.mjs')){
  // The old isolated mixed fixture omitted the real adventure service now
  // required by the unchanged native attack writer, including crash recovery.
  source="import {AdventureService} from '../adventure-service.mjs';\nimport {replayValue} from '../compact-receipt.mjs';\n"+source;
  source=source.replace('const s=await setupPvp(t);',"const s=await setupPvp(t);s.globals.__colAdventure=new AdventureService(s.sql,{now:()=>s.nowMs,random:()=>.5,uuid:()=> 'isolated-mixed-adventure',globals:s.globals});");
  source=source.replace('assert.deepEqual(json(a),json(b));',"if(phase==='before')assert(a.result.events.some(e=>e[3]?.type==='monster_result'));assert.deepEqual(json(b),json(replayValue(a)));");
  source=source.replace('const resumed=new ChannelOwnership(db,',"s.globals.__colAdventure=new AdventureService(db.sqlite,{now:()=>s.nowMs,random:()=>.5,uuid:()=> 'isolated-mixed-adventure',globals:s.globals});const resumed=new ChannelOwnership(db,");
  return {...result,source};
 }
 if(url.endsWith('/tests/mixed-crash-fixture.mjs')){
  source="import {AdventureService} from '../adventure-service.mjs';\n"+source;
  source=source.replace('const handler=',"const globals={};globals.__colAdventure=new AdventureService(db.sqlite,{now:()=>data.request.payload.nowMs,random:()=>.5,uuid:()=> 'isolated-mixed-adventure',globals});const handler=").replace('globalsFor:()=>({})','globalsFor:()=>globals');
  return {...result,source};
 }
 if(process.env.R43_TEST_TIMING==='1'&&(url.endsWith('/tests/process-channel-fixture.mjs')||url.endsWith('/benchmark/native-channel-entry.mjs'))){
  source='import {installR43TestTiming} from '+JSON.stringify(new URL('./load-stage-timing.mjs',import.meta.url).href)+';\n'+source;
  const anchor='await runChannelProcess({afterCreate(runtime){';
  if(source.split(anchor).length!==2)throw Error('R43 load timing entry anchor drift');
  source=source.replace(anchor,anchor+'installR43TestTiming(runtime);');
  return {...result,source};
 }
 return result;
}
