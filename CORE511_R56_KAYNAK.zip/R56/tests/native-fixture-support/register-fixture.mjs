import {register} from 'node:module';register(new URL('./fixture-loader.mjs',import.meta.url));
