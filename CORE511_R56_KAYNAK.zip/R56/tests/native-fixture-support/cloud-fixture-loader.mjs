// Cloud test compatibility only; never included in the game payload.
// Node uses direct statx, so fakeroot alone cannot model /etc ownership.
// This opt-in fixture maps only the safe, config-free container /etc UID.
// These tests do NOT certify production filesystem ownership/security.
import {lstatSync, existsSync} from 'node:fs';
import {load as prior, resolve as priorResolve} from './fixture-loader.mjs';
export const resolve = priorResolve;
export async function load(url, context, next) {
  const result = await prior(url, context, next);
  let source = String(result.source ?? '');
  if (process.env.COL_CLOUD_ISOLATED_FIXTURE === '1' && /\/vds-server\/src\/feature-settings(?:-r(?:11|13|15|18)|504|510)\.mjs$/.test(url)) {
    const parent = lstatSync('/etc');
    if (!parent.isDirectory() || parent.isSymbolicLink() || (parent.mode & 0o022)) throw Error('cloud_fixture_etc_parent_not_safe');
    const file = /FEATURE_FILE = '([^']+)'/.exec(source)?.[1];
    if (!file || existsSync(file)) throw Error('cloud_fixture_requires_absent_feature_config');
    const anchor = 'parent.uid === 0';
    if (source.split(anchor).length !== 2) throw Error('cloud_fixture_uid_anchor_drift');
    return {...result,source:source.replace(anchor,`parent.uid === ${parent.uid}`)};
  }
  if (url.endsWith('/tests-r55/browser-qa.mjs')) {
    const anchor = "executablePath:'/root/.cache/ms-playwright/chromium_headless_shell-1161/chrome-linux/headless_shell'";
    if (source.split(anchor).length !== 2) throw Error('cloud_browser_path_anchor_drift');
    return {...result, source:source.replace(anchor, "executablePath:process.env.PLAYWRIGHT_EXECUTABLE_PATH || '/usr/bin/chromium'")};
  }
  return result;
}
