import {register} from 'node:module';
register(new URL('./cloud-fixture-loader.mjs', import.meta.url));
