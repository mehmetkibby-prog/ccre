// Test observer: a client death alone cannot certify every pending reward.
const summary=a=>{const s=[...a].sort((x,y)=>x-y),q=p=>s.length?s[Math.min(s.length-1,Math.ceil(s.length*p)-1)]:null;return {n:s.length,p50:q(.5),p95:q(.95),p99:q(.99),max:s.at(-1)??null};};
export class FullRewardTrackerR57 {
 constructor(clock=()=>performance.now()){this.clock=clock;this.open=new Map();this.done=[];this.errors=[];this.checks=0;this.finalWithoutKill=0;}
 sent(actor,input,at,measured){if(input.action==='attack')this.open.set(input.intentId,{actor,intent:input.intentId,at,measured});}
 provisional(intent){const r=this.open.get(intent);if(r)r.provisional=true;}
 discard(intent){const r=this.open.get(intent);if(r&&!r.targets&&!r.clientAt)this.open.delete(intent);}
 noKillFinal(intent){const r=this.open.get(intent);if(r&&!r.targets){if(r.measured)this.finalWithoutKill++;this.open.delete(intent);}}
 death(intent,at){const r=this.open.get(intent);if(r){r.clientAt??=at;this.finish(r);}}
 kills(actor,intent,hits){const r=this.open.get(intent);if(!r||r.actor!==actor||r.targets)return false;const targets=[...new Map((hits??[]).filter(h=>h.killed).map(h=>[JSON.stringify([h.id,h.spawnRound]),{id:h.id,spawnRound:h.spawnRound}])).values()];if(!targets.length)return false;r.targets=targets;return true;}
 inspect(read,afterRead){
  const waiting=[...this.open.values()].filter(r=>r.targets&&!r.durableAt&&!r.proving);if(!waiting.length)return;
  try{
   const targets=[...new Map(waiting.flatMap(r=>r.targets).map(t=>[JSON.stringify([t.id,t.spawnRound]),t])).values()];if(targets.length>4096)throw Error('full_reward_observer_bound');
   const rows=read(targets);this.checks++;const completed=new Set(rows.filter(r=>r.completed).map(r=>JSON.stringify([r.id,r.spawnRound])));
   const ready=waiting.filter(r=>r.targets.every(t=>completed.has(JSON.stringify([t.id,t.spawnRound]))));if(!ready.length)return;
   // Capture this durability promise synchronously after this exact SQL read.
   // A visible later main-connection COMMIT may still have a WAL fsync pending.
   const durable=afterRead();for(const r of ready)r.proving=true;
   void Promise.resolve(durable).then(()=>{const now=this.clock();for(const r of ready){r.durableAt=now;this.finish(r);}},error=>{this.errors.push(error?.code??error?.message??'durability_failed');});
  }catch(error){this.errors.push(error?.code??error?.message??'observation_failed');}
 }
 finish(r){if(!r.durableAt||!r.clientAt)return;if(r.measured)this.done.push({intent:r.intent,targets:r.targets.length,serverMs:r.durableAt-r.at,completeMs:Math.max(r.durableAt,r.clientAt)-r.at,afterClientMs:Math.max(0,r.durableAt-r.clientAt)});this.open.delete(r.intent);}
 report(){return {definition:'Max of client durable-death arrival and first post-ACK SQL observation that every killed normal_defeat has rewards_completed_at>0, followed by the durability promise covering that SQL snapshot. Includes all native awards; does not claim final inventory rendering time.',deathAndAllRewardsMs:summary(this.done.map(r=>r.completeMs)),serverAllRewardsMs:summary(this.done.map(r=>r.serverMs)),rewardTailAfterClientDeathMs:summary(this.done.map(r=>r.afterClientMs)),killsCovered:this.done.reduce((n,r)=>n+r.targets,0),finalWithoutKill:this.finalWithoutKill,checks:this.checks,pending:[...this.open.values()].filter(r=>r.measured&&(r.provisional||r.targets)).map(r=>({intent:r.intent,targets:r.targets?.length??0,clientSeen:Boolean(r.clientAt),durabilityObserved:Boolean(r.durableAt)})),errors:this.errors};}
}
