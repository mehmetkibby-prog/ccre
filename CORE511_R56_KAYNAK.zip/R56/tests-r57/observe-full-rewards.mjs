import {isMainThread} from 'node:worker_threads';
import {FullRewardTrackerR57} from './full-reward-tracker.mjs';
if(isMainThread&&typeof process.send!=='function'){
 const {GameWriter}=await import(process.env.R57_FULL_REWARD_BASELINE==='1'?'../../r56_performance_work/working/core511-source/scripts/core511/writer-runtime.mjs':'../working/core511-source/scripts/core511/writer-runtime.mjs');
 const {RewardObservationR54}=await import('../working/core511-source/scripts/core511/benchmark/reward-observation-r54.mjs');
 const tracker=new FullRewardTrackerR57(),sent=RewardObservationR54.prototype.sent,finish=RewardObservationR54.prototype.finish,result=RewardObservationR54.prototype.result,packet=RewardObservationR54.prototype.packet,report=RewardObservationR54.prototype.report;
 let writer;
 // The separate reward connection can COMMIT before its own fsync/ACK. A
 // read must cover that currently active external writer as well as main WAL.
 const inspect=()=>{if(writer&&!writer.database.sqlite.isTransaction)tracker.inspect(targets=>writer.database.sqlite.prepare(`SELECT d.monster_id id,d.spawn_round spawnRound,d.rewards_completed_at>0 completed FROM json_each(?) j JOIN normal_defeats d ON d.monster_id=json_extract(j.value,'$.id') AND d.spawn_round=json_extract(j.value,'$.spawnRound')`).all(JSON.stringify(targets)),()=>Promise.all([writer.durableGroups?.afterRead?.(),writer.rewardWorkerR533?.lane?.busy]));};
 RewardObservationR54.prototype.sent=function(c,payload,at,measured){tracker.sent(c.p.id,payload,at,measured);return sent.call(this,c,payload,at,measured);};
 RewardObservationR54.prototype.finish=function(state,r,now){const value=finish.call(this,state,r,now);tracker.death(r.payload.intentId,now);return value;};
 RewardObservationR54.prototype.result=function(c,pending,reply){const added=pending.payload.action==='attack'&&tracker.kills(c.p.id,pending.payload.intentId,reply.body?.hits);const value=result.call(this,c,pending,reply);if(pending.payload.action==='attack'){if(reply.status===202&&reply.body?.combatPending)tracker.provisional(pending.payload.intentId);else if(!reply.body?.hits?.some(h=>h.killed))tracker.discard(pending.payload.intentId);}if(added)inspect();return value;};
 RewardObservationR54.prototype.packet=function(c,p,onFinal){let added=false;for(const event of p.events??(p.type==='event'?[p.event??p.payload??p.data]:[])){if(event?.attackerId!==c.p.id)continue;if(event.type==='monster_result'){added=tracker.kills(c.p.id,event.intentId,event.hits)||added;const prior=this.state(c).inputs.get(event.intentId);if(prior?.provisional&&prior.targets.size&&!event.hits?.some(h=>h.killed))tracker.noKillFinal(event.intentId);}if(event.type==='monster_reject')tracker.discard(event.intentId);}const value=packet.call(this,c,p,onFinal);if(added)inspect();return value;};
 RewardObservationR54.prototype.report=function(){return {...report.call(this),fullRewardsR57:tracker.report()};};
 const command=GameWriter.prototype.command;
 GameWriter.prototype.command=async function(peer,request){
  writer=this;const ack=await command.call(this,peer,request),value=ack.result;
  if(request.operation==='attack'){
   tracker.kills(request.playerId,request.payload.input.intentId,value?.result?.body?.hits);
   for(const entry of request.payload.batchAttacksR57??[]){const answer=value?.batchResultsR57?.find(r=>r.actor===entry.actor&&r.sequence===entry.sequence);tracker.kills(entry.actor,entry.input.intentId,answer?.result?.body?.hits);}
  }
  // Other native commands can finish pending awards too; do not attribute a
  // delayed observation at the next attack to actual server work.
  if(['attack','native_action','monster_reward','heartbeat'].includes(request.operation))inspect();
  return ack;
 };
}
