import {settleFreezeRequestsR85} from './freeze-outcomes-r85.mjs';
import {captureStoppedR533,stoppedOwnerMatchesR533} from './shared-stopped-r533.mjs';
import {captureSharedAbortOwners,sharedAbortOwnerMatches} from './shared-abort-proof-r532.mjs';
import {recoveryCause,recoveryDiagnostic} from './recovery-diagnostics-r532.mjs';
import {retiredActorIsolation} from './r48_2-options.mjs';
import {actorFaultIsolation} from './r48-options.mjs';
import {actorRejection} from './actor-rejection.mjs';
import {sharedHoldRollbackIsolation} from './shared-hold-rollback.mjs';
import {requestDigest} from './generated/owner-protocol.mjs';
import {randomUUID} from 'node:crypto';
import {demand} from './contract.mjs';
import {recoveryWatchdog} from './r47-options.mjs';
import {captureReturnSessions,rehomeWorldActors} from './global-return.mjs';
import {coldSettlementResources} from './settlement-resources.mjs';
import {foregroundClaimTargetsR85,foregroundScopeR112,assertClaimRefreshR112} from './reward-actor-scope-r85.mjs';

// Private parent pipe. HP and contribution proposals live only in the world
// owner; this book retains authority until the source confirms local promotion.
// A lost grant/finish/COMMIT acknowledgement retires all five OS owners.
export class SharedCombatBridge {
 constructor(world,{set=setTimeout,clear=clearTimeout,clock=()=>performance.now()}={}){this.world=world;this.core=world.core;this.set=set;this.clear=clear;this.clock=clock;this.requests=new Map();this.terminal=null;this.waiters=new Set();this.idleWaiters=new Set();this.ownershipHolds=new Set();this.actorWaits=0;this.actorRejections=0;this.actorConflicts=[];this.channelReleaseR111=process.env.CORE511_R111_CHANNEL_RELEASE!=='0';this.unchangedReleaseR112=process.env.CORE511_R112_RELEASE!=='0';}
 // A parent-only admission/retirement hold is acquired after accepted work
 // drains, outside the SQLite queue. It never grants a player write lease.
 reserveOwnership(){
  demand(!this.terminal,'shared_ownership_busy');let resolve;const hold={done:new Promise(r=>resolve=r),release:()=>{this.ownershipHolds.delete(hold);resolve();}};this.ownershipHolds.add(hold);return hold;
 }
 async terminalIdle(){if(!this.terminal)return;if(recoveryWatchdog)demand(!this.core.recoveringWorld,'global_world_busy');await new Promise((resolve,reject)=>this.waiters.add({resolve,reject}));}
 async idle(){if(!this.requests.size)return;await new Promise((resolve,reject)=>this.idleWaiters.add({resolve,reject}));}
 wake(){if(!this.terminal){for(const waiter of this.waiters)waiter.resolve();this.waiters.clear();}if(!this.requests.size){for(const waiter of this.idleWaiters)waiter.resolve();this.idleWaiters.clear();}}
 get busy(){return this.requests.size>0;}
 scopeCurrent(row,held){return Boolean(row&&this.requests.get(row.id)===row&&this.world.row===row.world&&!row.world.exited&&!this.core.recoveringWorld&&(held===undefined||this.terminal===held&&row.terminal===held));}
 assertScope(row,held,code='shared_bridge_superseded'){demand(this.scopeCurrent(row,held),code);}
 failScope(row,error,requestMethod,held){if(this.scopeCurrent(row,held))this.fail(error,{error,requestMethod});}
 source(peer,payload){const owner=this.core.writer.owners.get(payload?.actor);demand(owner&&owner.channel===peer.channel&&owner.incarnation===peer.incarnation&&owner.epoch===payload.epoch&&['active','draining'].includes(owner.state),'shared_source_owner_fenced');return {...peer,actor:payload.actor,epoch:payload.epoch};}
 entry(peer,payload){
  const row=this.requests.get(payload.id);demand(row&&!row.coldGroup&&row.source.actor===payload.actor&&row.source.epoch===payload.epoch&&row.source.channel===peer.channel&&row.source.incarnation===peer.incarnation&&row.proof===payload.proof&&this.world.row===row.world&&!row.world.exited,'shared_bridge_lease_fenced');
  const move=row.commandAck?.result.moves?.find(m=>m.id===payload.actor);if(move){const owner=this.core.writer.owners.get(move.id);demand(owner?.epoch===move.target.epoch&&owner.channel===move.target.channel&&owner.incarnation===move.target.incarnation,'shared_return_owner_fenced');}else this.source(peer,payload);return row;
 }
 async acquire(peer,payload){
  // A refreshed channel can resume before another owner's final ACK. Local
  // work is already safe; a new cross-owner hold must wait until all global
  // leases are released so it cannot race another channel's resume operation.
  await this.world.global.newSharedInput();
  return this.reserve(this.source(peer,payload),payload.id);
 }
 async reserve(source,id,coldGroup=null){
  const world=this.world.row;demand(typeof id==='string'&&id.length>=16&&id.length<=160&&!this.requests.has(id)&&world?.state==='running'&&!world.exited,'shared_bridge_request');
  const row={id,source,world,phase:'acquiring',proof:null,coldGroup,local:[]};this.requests.set(row.id,row);
  try{await this.acquirePartitionR113?.(row);demand(this.scopeCurrent(row),'shared_world_replaced');const grant=await world.control.request('shared_acquire',{peer:source,id:row.id,area:this.partitionAreaR113??null});demand(this.scopeCurrent(row),'shared_world_replaced');row.proof=grant.proof;await this.beforeGrantR113?.(row,grant);demand(this.scopeCurrent(row),'shared_world_replaced');row.phase='leased';return grant;}catch(error){this.failScope(row,error,'shared_reserve');throw error;}
 }
 // Parent-only read lease for native transfer/entry. It never enters the
 // channel command protocol or authorizes a shared monster mutation. Keep
 // the group in its freezing phase while queued earlier casts finish.
 async acquireCold(group){
  const c=this.core;demand(this.registeredCold(group)&&group.phase==='freezing','shared_cold_group');let source;
  if(c.entryReads?.get(group.source)===group){group.assertUnadmitted();source={...c.process(group.peer).peer,actor:group.source,epoch:c.authority.owner(group.source)?.epoch??1};}
  else{const entry=group.entries.get(group.source);source=this.source(c.process(entry.owner).peer,{actor:group.source,epoch:entry.owner.epoch});}
  const id=randomUUID(),grant=await this.reserve(source,id,group),row=this.requests.get(id);demand(row?.proof===grant.proof,'shared_cold_grant');return row;
 }
 registeredCold(group){return this.core.transferGroups.has(group)||this.core.entryReads?.get(group.source)===group;}
 assertCold(row,group){demand(this.registeredCold(group)&&row?.coldGroup===group&&this.scopeCurrent(row)&&row.phase==='leased','shared_cold_fenced');this.core.process(row.source);return row;}
 async checkpointCold(row,group){
  this.assertCold(row,group);demand(group.phase==='freezing'&&!row.local.length,'shared_cold_checkpoint_phase');if(this.core.entryReads?.get(group.source)===group)group.assertUnadmitted();else this.source(row.source,{actor:row.source.actor,epoch:row.source.epoch});
  try{
   const c=this.core,cycle=c.database.sqlite.prepare('SELECT cycle FROM world_state WHERE id=1').get().cycle;
   for(const {channel,resources}of coldSettlementResources(c.database.sqlite,group.source))if(channel!==0){
    const target=c.process(c.processes.get(channel)?.peer),token=randomUUID(),local={target,token,cycle,resources};row.local.push(local);
    const ack=await target.control.request('settlement_freeze',{token,cycle,resources});this.assertCold(row,group);c.process(target.peer);
    const owner=c.writer.system.owner('channel:'+channel);demand(ack?.token===token&&ack.cycle===cycle&&ack.channel===channel&&ack.incarnation===target.peer.incarnation&&JSON.stringify(ack.resources)===JSON.stringify(resources)&&Number.isSafeInteger(ack.sequence)&&ack.sequence>=0&&owner?.online===1&&owner.incarnation===target.peer.incarnation&&owner.sequence>=ack.sequence,'shared_cold_local_ack');
   }
   const ack=await row.world.control.request('shared_checkpoint',{peer:row.source,proof:row.proof});this.assertCold(row,group);return ack;
  }catch(error){this.failScope(row,error,'shared_checkpointCold');throw error;}
 }
 async finishCold(row,group){
  this.assertCold(row,group);
  try{
   await Promise.all(row.local.map(async({target,token,cycle})=>{this.core.process(target.peer);const ack=await target.control.request('settlement_resume',{token});this.core.process(target.peer);demand(ack?.token===token&&ack.cycle===cycle&&ack.channel===target.peer.channel&&ack.incarnation===target.peer.incarnation&&ack.resumed,'shared_cold_local_resume_ack');}));this.assertCold(row,group);row.local=[];
   const ack=await row.world.control.request('shared_finish',{peer:row.source,proof:row.proof,changes:{monsters:[],participants:[],bossParticipants:[],combatEvents:[]}});this.assertCold(row,group);row.phase='finished';this.requests.delete(row.id);this.releasePartitionR113?.(row);this.wake();return ack;
  }catch(error){this.failScope(row,error,'shared_finishCold');throw error;}
 }
 async prepare(peer,payload){
  for(;;){const holds=[...this.ownershipHolds,...[...(this.core.transferGroups??[])].filter(g=>g.phase!=='freezing')];if(!holds.length)break;await Promise.all(holds.map(g=>g.done));}
  const row=this.entry(peer,payload);demand(row.phase==='leased'&&!this.terminal&&Array.isArray(payload.players)&&payload.players.includes(row.source.actor)&&new Set(payload.players).size===payload.players.length,'shared_terminal_scope');
  const sourcePlayers=payload.players.map(id=>{const owner=this.core.writer.owners.get(id);demand(owner?.channel===peer.channel&&owner.incarnation===peer.incarnation,'shared_terminal_source_players');return {id,epoch:owner.epoch};});
  const held={row,token:randomUUID(),phase:'freezing',channels:[],sourcePlayers,sessions:captureReturnSessions(this.core)};if(retiredActorIsolation)held.abortOwners=captureSharedAbortOwners(this.core);held.stoppedCandidates=captureStoppedR533(this.core,sourcePlayers);held.stopped=new Map();this.terminal=held;row.terminal=held;
  const current=()=>this.scopeCurrent(row,held);
  try{
   const channels=[...this.core.processes.values()].filter(c=>c.online);demand(channels.length===4,'shared_terminal_channels');
   // Keep the same signed world lease, source durable barrier, native command
   // and receipt. Audited attack/claim scopes select only affected residents.
   // Drain shared contributions before deriving the authoritative SQL scope.
   const scopedInput=payload.foregroundAttackR112?.action==='attack'?payload.foregroundAttackR112:sourcePlayers.length===1&&foregroundClaimTargetsR85(payload.foregroundClaimR85)?payload.foregroundClaimR85:null;
   if(actorFaultIsolation&&scopedInput){
    await row.world.control.request('shared_checkpoint',{peer:row.source,proof:row.proof});demand(current(),'shared_prepare_superseded');
    const scope=foregroundScopeR112(this.core.database.sqlite,scopedInput,row.source.actor,peer.channel);
    if(scope&&sourcePlayers.every(p=>scope.actors.includes(p.id)))held.foregroundClaimR85={scope,input:JSON.stringify(scopedInput),operation:scopedInput.action==='attack'?'attack':'native_action'};
   }
   if(row.partitionActorsR113)demand(held.foregroundClaimR85,'shared_partition_scope_changed');
   if(held.foregroundClaimR85){
    if(row.partitionActorsR113)demand(held.foregroundClaimR85.scope.actors.every(id=>row.partitionActorsR113.includes(id)),'shared_partition_actor_changed');
    const selected=held.foregroundClaimR85.only=new Map(channels.map(c=>[c.peer.channel,[]]));
    for(const id of held.foregroundClaimR85.scope.actors){
     const stopped=held.stoppedCandidates.get(id);
     if(stopped){selected.get(stopped.peer.channel).push({id,epoch:stopped.epoch});continue;}
     const live=this.core.authority.admission(id)||this.core.authority.simulation?.(id);if(!live)continue;
     const owner=this.core.authority.owner(id),channel=channels.find(c=>c.peer.channel===owner?.channel&&c.peer.incarnation===owner.incarnation);
     demand(channel&&owner.epoch===live.epoch&&owner.channel===live.channel,'shared_claim_owner_fenced');
     selected.get(channel.peer.channel).push({id,epoch:owner.epoch});
    }
   }
   const holds=channels.map(async channel=>{
    const freezes=[...this.core.permanent.entries.values()].filter(e=>e.phase==='freezing'&&e.owner?.channel===channel.peer.channel&&e.owner?.incarnation===channel.peer.incarnation).map(e=>({id:e.id,epoch:e.owner.epoch,token:e.token}));
    for(const e of this.core.transitions.values())if(e.phase==='freezing'&&e.owner.channel===channel.peer.channel&&e.owner.incarnation===channel.peer.incarnation)freezes.push(e.request);
    const only=held.foregroundClaimR85?.only.get(channel.peer.channel),except=channel.peer.channel===peer.channel?sourcePlayers:[];
    const answer=await channel.control.request('shared_hold',{token:held.token,except,freezes,...(only?{only}:{}),stopped:[...held.stoppedCandidates.values()].filter(p=>p.peer.channel===channel.peer.channel&&p.peer.incarnation===channel.peer.incarnation&&(!only||only.some(a=>a.id===p.actor&&a.epoch===p.epoch)))});demand(answer.token===held.token&&answer.channel===channel.peer.channel&&answer.incarnation===channel.peer.incarnation&&Array.isArray(answer.actors),'shared_hold_ack');demand(current(),'shared_prepare_superseded');held.channels.push({channel,answer});
    if(only&&!answer.aborted){const reported=[...answer.actors,...(answer.stoppedActors??[]).map(a=>({id:a.actor,epoch:a.epoch})),...except];demand(answer.actors.every(a=>only.some(p=>p.id===a.id&&p.epoch===a.epoch))&&only.every(p=>reported.some(a=>a.id===p.id&&a.epoch===p.epoch)),'shared_claim_hold_scope');}
   });
   if(actorFaultIsolation){
    // A structured abort still joins every successful hold before release.
    // An unproven failed transport escalates promptly: retiring a hung sibling
    // may be necessary to settle its control request. No timeout grants thaw.
    const results=await settleFreezeRequestsR85(holds,{set:this.set,clear:this.clear}),failed=results.find(r=>r.status==='rejected');if(failed)throw failed.reason;
    if(held.channels.some(({answer})=>answer.aborted===true)){
     demand(held.phase==='freezing'&&!row.commandAck,'shared_abort_after_commit');
     for(const {channel,answer}of held.channels)if(answer.aborted){
      const rejection=answer.rejected;demand(typeof rejection?.actor==='string'&&Number.isSafeInteger(rejection.epoch)&&(['checkpoint_snapshot_conflict','actor_command_pending'].includes(rejection.code)||retiredActorIsolation&&['actor_quarantined','actor_checkpoint_rejected'].includes(rejection.code)||sharedHoldRollbackIsolation&&rejection.code==='actor_command_rejected'),'shared_abort_rejection');
      if(retiredActorIsolation&&['actor_quarantined','actor_checkpoint_rejected'].includes(rejection.code)||sharedHoldRollbackIsolation&&rejection.code==='actor_command_rejected'){const owner=held.abortOwners.get(rejection.actor);demand(sharedAbortOwnerMatches(owner,rejection,channel.peer),'shared_abort_actor_proof');}
      if(rejection.code==='actor_command_pending')demand([...this.core.actorIsolation.unknownActors.get(rejection.actor)??[]].some(r=>r.owners.some(a=>a.id===rejection.actor&&a.owner?.epoch===rejection.epoch&&a.owner.channel===channel.peer.channel&&a.owner.incarnation===channel.peer.incarnation)),'shared_abort_pending_proof');
     }
     await Promise.all(channels.map(async channel=>{const ack=await channel.control.request('shared_abort',{token:held.token});demand(ack?.aborted===true&&ack.token===held.token&&ack.channel===channel.peer.channel&&ack.incarnation===channel.peer.incarnation,'shared_abort_ack');}));
     demand(current(),'shared_prepare_superseded');
     await row.world.control.request('shared_finish',{peer:row.source,proof:row.proof,changes:{monsters:[],participants:[],bossParticipants:[],combatEvents:[]}});
     demand(current(),'shared_prepare_superseded');row.phase='finished';row.terminal=null;this.terminal=null;this.wake();return {prepared:false,rejected:true};
    }
   }else await Promise.all(holds);

   for(const {channel,answer}of held.channels)for(const actor of answer.stoppedActors??[]){
    const p=held.stoppedCandidates.get(actor.actor);
    demand(p&&p.peer.channel===channel.peer.channel&&p.peer.incarnation===channel.peer.incarnation&&actor.epoch===p.epoch&&actor.token===p.token&&actor.finalSequence===p.finalSequence&&stoppedOwnerMatchesR533(this.core,p),'shared_stopped_actor_proof');held.stopped.set(p.actor,p);
   }
   await row.world.control.request('shared_checkpoint',{peer:row.source,proof:row.proof});demand(current(),'shared_prepare_superseded');held.phase='frozen';
   if(held.foregroundClaimR85&&!this.claimScopeCurrent(held)){await this.abortTerminal(row);return {prepared:false,rejected:true};}
   return {prepared:true,players:held.foregroundClaimR85?held.foregroundClaimR85.scope.actors.filter(id=>!sourcePlayers.some(p=>p.id===id)):[...held.channels.flatMap(c=>c.answer.actors.map(a=>a.id)),...held.stopped.keys()],...(held.stopped.size?{stoppedPlayers:[...held.stopped.keys()]}:{})};
  }catch(error){if(current())this.fail(error,{error:error,requestMethod:'shared_prepare'});throw error;}
 }
 assertWrite(sql,payload,context){
  const held=this.terminal,row=held?.row;demand(held?.phase==='frozen'&&row.source.actor===context.actor&&row.source.epoch===context.epoch&&row.source.incarnation===context.peer.incarnation&&payload.sharedLease===row.proof,'shared_terminal_writer_fenced');
  this.assertClaimCommand(held,payload,held.foregroundClaimR85?.operation??'native_action');
  for(const p of held.stopped?.values()??[])demand(stoppedOwnerMatchesR533(this.core,p,sql),'shared_stopped_actor_changed');
  for(const {channel,answer}of held.channels)for(const actor of answer.actors){const current=this.core.authority.owner(actor.id,sql);demand(current?.channel===channel.peer.channel&&current.incarnation===channel.peer.incarnation&&current.epoch===actor.epoch&&current.sequence===actor.sequence,'shared_terminal_actor_changed');}
  return true;
 }
 allows(id,peer,request){const held=this.terminal;return held?.phase==='frozen'&&request.payload?.sharedLease===held.row.proof&&peer.incarnation===held.row.source.incarnation&&request.playerId===held.row.source.actor&&(held.channels.some(c=>c.answer.actors.some(a=>a.id===id))||this.stoppedAllows(id,peer,request));}
 stoppedAllows(id,peer,request){const h=this.terminal,p=h?.stopped?.get(id);return Boolean(p&&h.phase==='frozen'&&request.payload?.sharedLease===h.row.proof&&peer.incarnation===h.row.source.incarnation&&peer.channel===h.row.source.channel&&request.playerId===h.row.source.actor&&stoppedOwnerMatchesR533(this.core,p));}
 blocking(peer,request){
  const held=this.terminal;if(!held||held.phase==='freezing'||request.payload?.sharedLease===held.row.proof&&peer.incarnation===held.row.source.incarnation)return null;
  // Include all declared AND post-write audited players, not only the caller.
  // A resumed actor cannot award, heal or damage a still-refreshing teammate.
  const ids=new Set([request.playerId,...(request.payload?.resources??[]).filter(k=>k.startsWith('player:')).map(k=>k.slice(7))]);
  return held.channels.some(c=>c.answer.actors.some(a=>ids.has(a.id)&&!(held.phase==='refreshing'&&c.channel.peer.channel===peer.channel&&c.channel.peer.incarnation===peer.incarnation&&(c.releasedR111||c.unchangedReleasedR112?.has(a.id)))))?held:null;
 }
 wakeWritable(){for(const waiter of this.waiters)if(waiter.peer&&!this.blocking(waiter.peer,waiter.request)){this.waiters.delete(waiter);waiter.resolve();}}

 conflict(kind,peer,request,held){
  if(kind==='wait')this.actorWaits++;else this.actorRejections++;
  const row={at:Date.now(),kind,operation:request.operation,action:request.payload?.input?.action??null,actor:request.playerId,epoch:request.epoch,sequence:request.sequence,channel:peer.channel,phase:held.phase,terminalOperation:held.row.id,sourceActor:held.row.source.actor,sourceChannel:held.row.source.channel};
  this.actorConflicts.push(row);if(this.actorConflicts.length>256)this.actorConflicts.shift();return row;
 }
 async writable(peer,request){
  // Wait OUTSIDE SQLite. Only this exact channel's validated post-COMMIT,
  // post-reload release ACK can wake its ordinary work early. Admission and
  // other global terminalIdle() waiters still join EVERY channel release.
  for(let held;(held=this.blocking(peer,request));){this.conflict('wait',peer,request,held);if(recoveryWatchdog)demand(!this.core.recoveringWorld,'global_world_busy');await new Promise((resolve,reject)=>this.waiters.add({resolve,reject,peer,request}));this.core.process(peer);}
 }
 assertRefresh(payload,result,context){const h=this.terminal;return assertClaimRefreshR112(h?.foregroundClaimR85,h?.row.proof,payload,result,context);}
 claimScopeCurrent(held){const claim=held.foregroundClaimR85;return !claim||JSON.stringify(foregroundScopeR112(this.core.database.sqlite,JSON.parse(claim.input),held.row.source.actor,held.row.source.channel))===JSON.stringify(claim.scope);}
 assertClaimCommand(held,payload,operation){
  const claim=held?.foregroundClaimR85;if(!claim)return;
  const actors=new Set(claim.scope.actors),resources=payload.resources??[],ids=resources.filter(k=>k.startsWith('player:')).map(k=>k.slice(7));
  demand(operation===(claim.operation??'native_action')&&JSON.stringify(payload.input)===claim.input&&ids.every(id=>actors.has(id))&&claim.scope.actors.every(id=>ids.includes(id)),'shared_terminal_actor_fenced');
 }
 guard(peer,request){
  const active=this.terminal;
  if(active?.foregroundClaimR85&&request.payload?.sharedLease===active.row.proof){
   this.assertClaimCommand(active,request.payload,request.operation);
   // The first guard runs before any native SQL/RNG and its rejection is
   // certified only after the existing writer ROLLBACK. The post-write guard
   // still checks every actual player write, but cannot reread participants
   // which the successful native boss award legitimately deletes.
   if(!this.core.writer.playerWrites.active)demand(this.claimScopeCurrent(active),'shared_terminal_actor_fenced');
  }
  const held=this.blocking(peer,request);if(held){const context=this.conflict('reject',peer,request,held);try{demand(false,'shared_terminal_actor_fenced');}catch(error){error.context=context;throw error;}}return true;
 }
 ownsStatus(peer,request){
  const h=this.terminal,r=h?.row,q=r?.commandRequest;
  return Boolean(h?.phase==='frozen'&&q&&r.source.channel===peer.channel&&r.source.incarnation===peer.incarnation&&q.operationId===request.operationId&&q.playerId===request.playerId&&q.epoch===request.epoch&&q.sequence===request.sequence&&q.operation===request.operation);
 }
 rejectedStatus(peer,request,digest){
  const row=[...this.requests.values()].find(r=>r.commandRejected&&r.commandRequest?.operationId===request.operationId);if(!row)return null;const q=row.commandRequest;
  demand(row.phase==='finished'&&!row.terminal&&row.source.channel===peer.channel&&row.source.incarnation===peer.incarnation&&q.playerId===request.playerId&&q.epoch===request.epoch&&q.sequence===request.sequence&&q.operation===request.operation&&requestDigest({realmId:this.core.realmId,channel:peer.channel,playerId:q.playerId,epoch:q.epoch,sequence:q.sequence,operation:q.operation,payload:q.payload})===digest,'shared_command_status_fenced');
  return {status:'not_executed',error:{code:row.commandRejected.code,message:row.commandRejected.message},rejection:actorRejection(row.commandRejected)};
 }
 async abortCommand(row,error,peer,request){
  const proof=actorRejection(error),held=this.terminal;
  if(!proof||proof.actor!==request.playerId||proof.epoch!==request.epoch||proof.sequence!==request.sequence||proof.key!==request.operationId||proof.operation!==request.operation||proof.channel!==peer.channel||proof.incarnation!==peer.incarnation||proof.sharedLease!==row.proof)return false;
  demand(held===row.terminal&&held.phase==='frozen'&&!row.commandAck,'shared_abort_after_commit');
  await this.abortTerminal(row);row.commandRejected=error;return true;
 }
 async abortTerminal(row){
  const held=row.terminal;demand(held&&this.scopeCurrent(row,held)&&held.phase==='frozen'&&!row.commandAck,'shared_abort_after_commit');
  try{
   await Promise.all(held.channels.map(async({channel})=>{const ack=await channel.control.request('shared_abort',{token:held.token});demand(ack?.aborted===true&&ack.token===held.token&&ack.channel===channel.peer.channel&&ack.incarnation===channel.peer.incarnation,'shared_abort_ack');}));
   this.assertScope(row,held,'shared_abort_superseded');
   await row.world.control.request('shared_finish',{peer:row.source,proof:row.proof,changes:{monsters:[],participants:[],bossParticipants:[],combatEvents:[]}});
   this.assertScope(row,held,'shared_abort_superseded');this.clearUnknown(row);row.phase='finished';row.terminal=null;this.terminal=null;this.wake();
  }catch(error){this.failScope(row,error,'shared_abortTerminal',held);throw error;}
 }
 async cancel(peer,payload){
  demand(actorFaultIsolation,'shared_cancel_disabled');const row=this.entry(peer,payload);demand(payload.operationId==='shared:'+row.id&&!row.commandRequest&&!row.commandAck,'shared_cancel_submitted');
  if(row.cancelled){demand(row.phase==='finished','shared_cancel_phase');return {cancelled:true};}
  demand(row.phase==='leased','shared_cancel_phase');await this.abortTerminal(row);row.cancelled=true;return {cancelled:true};
 }
 async reconcileStatus(peer,request,ack){
  demand(this.ownsStatus(peer,request),'shared_command_status_fenced');return this.acceptCommand(this.terminal.row,ack);
 }
 async acceptCommand(row,ack){
  const held=row.terminal;this.assertScope(row,held);demand(held&&ack?.key===row.commandRequest.operationId&&ack.result,'shared_command_receipt');
  if(row.commandAck)demand(row.commandAck.key===ack.key,'shared_command_receipt');else row.commandAck=ack;
  if(ack.result.passiveAdmissions?.length){row.passiveAdmission??=this.admitPassive(held,ack.result.passiveAdmissions);await row.passiveAdmission;}
  this.assertScope(row,held);this.reloadCommittedWorldR112(row,held);this.clearUnknown(row);return row.commandAck;
 }
 // Start publishing committed shared HP/deaths alongside the source's cold
 // inventory read. Both are read-only views of an already durable command.
 // finish still awaits publication before any foreign actor is released;
 // all mutation/ownership leases remain held. This internal writer ACK is
 // not the final client reply and never acknowledges speculative damage.
 reloadCommittedWorldR112(row,held){
  this.assertScope(row,held);demand(row.commandAck,'shared_terminal_commit_missing');
  if(row.committedReloadR112)return row.committedReloadR112;
  row.committedReloadR112=(async()=>{
   const committed=row.commandAck.result.committedR113,world=committed?.sharedWorld;
   const snapshot=committed?.version===1&&committed.operationId===row.commandAck.key&&world?.system?.incarnation===row.world.peer.incarnation&&world.system.epoch===row.world.owner.epoch?world:(await this.core.reader.query('kernel511_world_boot',[row.world.peer.incarnation,row.world.owner.epoch])).rows;
   this.assertScope(row,held);await row.world.control.request('shared_reload',{peer:row.source,proof:row.proof,snapshot});this.assertScope(row,held);
  })();
  // Observe failures immediately even if the source disappears before finish.
  // Keep the original rejected promise so finish/status cannot turn a failed
  // publication into success. A replaced generation is never recovered here.
  void row.committedReloadR112.catch(error=>this.failScope(row,error,'shared_committed_reload',held));
  return row.committedReloadR112;
 }
 clearUnknown(row){if(row.commandWatchdog!==undefined&&row.commandWatchdog!==null)this.clear(row.commandWatchdog);row.commandWatchdog=null;row.commandUnknown=null;}
 stopUnknownTimers(){for(const row of this.requests.values())this.clearUnknown(row);}
 watchUnknown(row,error){
  if(row.commandUnknown)return;row.commandUnknown={at:this.clock(),error};
  // One cold failure timer, never a gameplay poll. A coupled world commit
  // cannot keep every owner frozen forever, nor be treated as rollback.
  row.commandWatchdog=this.set(()=>{row.commandWatchdog=null;void this.expireUnknown(row).catch(error=>{if(row.commandUnknown&&!row.commandAck)this.failScope(row,error,'shared_watchUnknown',row.terminal);});},10000);row.commandWatchdog?.unref?.();
 }
 async expireUnknown(row){
  if(!this.scopeCurrent(row,row.terminal)||!row.commandUnknown||row.commandAck||this.core.stopping)return;
  const pending=row.commandUnknown,peer={channel:row.source.channel,incarnation:row.source.incarnation,realm:this.core.realmId},status=await this.core.actorIsolation.commandStatus(peer,row.commandRequest);
  if(status.status==='committed')return;
  // Only actual exit of all old owners and durable CURRENT DB recovery may
  // reconcile this genuinely shared unknown. No epoch/lease expires here.
  if(!this.scopeCurrent(row,row.terminal)||row.commandAck||row.commandUnknown!==pending)return;
  const error=Object.assign(Error('shared_command_outcome_unknown'),{code:'shared_command_outcome_unknown',fenceContext:{actor:row.source.actor,channel:row.source.channel,incarnation:row.source.incarnation,operation:row.commandRequest.operation,phase:'shared_terminal_unknown',requestEpoch:row.source.epoch,sequence:row.commandRequest.sequence,leaseKind:'shared'}});
  this.core.onFault({actor:row.source.actor,channel:row.source.channel,error,authentication:true,sharedUnknownDeadline:true,elapsedMs:this.clock()-pending.at});this.fail(error,{error:error,requestMethod:'shared_expireUnknown'});
 }
 async command(peer,request){
  const held=this.terminal,row=held?.row;demand(row&&this.scopeCurrent(row,held)&&request.payload?.sharedLease===row.proof&&request.playerId===row.source.actor&&['attack','pvp_attack','heartbeat','movement','retaliation_death','native_action','mode_action','dungeon_entry'].includes(request.operation)&&!row.commandAck,'shared_terminal_command');
  if(!actorFaultIsolation){try{const ack=await this.core.writer.command(peer,request);this.assertScope(row,held);row.commandAck=ack;if(ack.result.passiveAdmissions?.length)await this.admitPassive(held,ack.result.passiveAdmissions);this.assertScope(row,held);return ack;}catch(error){this.failScope(row,error,'shared_command',held);throw error;}}
  row.commandRequest=request;let ack;
  try{ack=await this.core.writer.command(peer,request);}catch(error){
   if(!this.scopeCurrent(row,held))throw error;
   let aborted;try{aborted=await this.abortCommand(row,error,peer,request);}catch(abortError){this.failScope(row,abortError,'shared_command',held);throw abortError;}if(aborted)throw error;
   if(/^SQLITE_(CORRUPT|NOTADB|IOERR|FULL)/.test(error?.code??'')){this.failScope(row,error,'shared_command',held);throw error;}
   // The exact durable receipt still decides the outcome. Superseded control
   // state neither replays the writer nor recovers a replacement generation.
   try{const status=await this.core.actorIsolation.commandStatus(peer,request);this.assertScope(row,held);if(status.status==='committed')return status.ack;}catch(statusError){this.failScope(row,statusError,'shared_command',held);throw statusError;}
   this.watchUnknown(row,error);this.core.onFault({actor:request.playerId,channel:peer.channel,error,authentication:true,sharedCommandPending:true});throw error;
  }
  try{return await this.acceptCommand(row,ack);}catch(error){this.failScope(row,error,'shared_command',held);throw error;}
 }
 async admitPassive(held,admissions){
  const c=this.core,row=held.row;this.assertScope(row,held);for(const entry of admissions){
   const owner=c.authority.owner(entry.id),simulation=c.authority.simulation(entry.id),channel=held.channels.find(r=>r.channel.peer.channel===entry.channel&&r.channel.peer.incarnation===entry.incarnation);
   demand(channel&&!channel.answer.actors.some(a=>a.id===entry.id)&&owner?.epoch===entry.epoch&&owner.incarnation===entry.incarnation&&owner.channel===entry.channel&&owner.sequence===0&&simulation?.run_id===entry.runId&&simulation.epoch===entry.epoch&&!c.authority.admission(entry.id),'shared_passive_admission_owner');
   const bundle=await c.load(entry.id),identity={actor:entry.id,account:bundle.player.account_id,session:'simulation:'+entry.runId,epoch:entry.epoch,channel:entry.channel,boot:entry.incarnation,realm:c.realmId};
   this.assertScope(row,held);const ack=await channel.channel.control.request('shared_admit',{bundle,identity,frozen:{token:held.token}});demand(ack?.token===held.token&&ack.id===entry.id&&ack.epoch===entry.epoch&&ack.admitted,'shared_passive_admission_ack');this.assertScope(row,held);channel.answer.actors.push({id:entry.id,epoch:entry.epoch,sequence:0,rates:null});
  }
 }
 async finish(peer,payload){
  const row=this.entry(peer,payload),held=row.terminal;demand(row.phase==='leased','shared_finish_phase');row.phase='finishing';let released=false;
  const current=()=>this.scopeCurrent(row,held&&!released?held:undefined);
  try{
   demand(current(),'shared_finish_superseded');
   if(held){
    await this.reloadCommittedWorldR112(row,held);demand(current(),'shared_finish_superseded');held.phase='refreshing';
    if(row.commandAck.result.moves?.length){row.phase='returning';return {returning:true,token:held.token};}
    const invalidation=row.commandAck.result.sharedRefresh;demand(!invalidation||invalidation.version===1&&Array.isArray(invalidation.actors)&&typeof invalidation.all==='boolean','shared_refresh_metadata');
    await Promise.all(held.channels.map(async entry=>{
     const {channel,answer}=entry;entry.refreshActors=!invalidation||invalidation.all?answer.actors.map(a=>a.id):answer.actors.filter(a=>invalidation.actors.includes(a.id)).map(a=>a.id);
     if(this.unchangedReleaseR112&&invalidation?.all===false){
      const expected=answer.actors.filter(a=>!entry.refreshActors.includes(a.id));
      if(expected.length){
       const early=await channel.control.request('shared_release',{token:held.token,refreshActors:entry.refreshActors,releaseUnchangedOnly:true});
       demand(current(),'shared_finish_superseded');this.core.process(channel.peer);
       demand(early?.token===held.token&&early.channel===channel.peer.channel&&early.incarnation===channel.peer.incarnation&&Array.isArray(early.unchangedReleased)&&early.unchangedReleased.length===expected.length&&new Set(early.unchangedReleased.map(a=>a.id)).size===expected.length&&expected.every(a=>early.unchangedReleased.some(b=>b.id===a.id&&b.epoch===a.epoch)),'shared_unchanged_release_ack');
       entry.unchangedReleasedR112=new Set(expected.map(a=>a.id));this.wakeWritable();
      }
     }
     const ack=await channel.control.request('shared_release',{token:held.token,refreshActors:entry.refreshActors,...(row.commandAck.result.committedR113?{committedResult:row.commandAck.result}:{})});demand(ack.token===held.token&&ack.released,'shared_release_ack');demand(current(),'shared_finish_superseded');
     // The existing channel protocol has now refreshed and unlocked all of
     // its held actors. Do not make their next normal kill wait for a slower
     // sibling. Shared ownership and the source world lease remain held.
     if(this.channelReleaseR111){entry.releasedR111=true;this.wakeWritable();}
     (this.refreshTrace??=[]).push({at:Date.now(),operation:row.id,kind:row.commandRequest?.operation??null,action:row.commandRequest?.payload?.input?.action??null,scoped:!!held.foregroundClaimR85,channel:channel.peer.channel,heldActors:answer.actors.length,refreshActors:entry.refreshActors.length,tables:invalidation?.tables??null,...ack.refresh});if(this.refreshTrace.length>2048)this.refreshTrace.shift();
    }));
    demand(current(),'shared_finish_superseded');this.terminal=null;released=true;this.wake();
   }
   // The channel holds were intentionally released. The original row still
   // owns its world lease until this finish reply; do not demand the old held
   // pointer again or clear a later terminal when this ACK eventually arrives.
   demand(current(),'shared_finish_superseded');const ack=await row.world.control.request('shared_finish',{peer:row.source,proof:row.proof,changes:payload.changes});demand(current(),'shared_finish_superseded');row.phase='finished';return ack;
  }catch(error){if(current())this.fail(error,{error,requestMethod:'shared_finish'});throw error;}
 }
 async returnReady(peer,payload){
  const row=this.entry(peer,payload),h=row.terminal;demand(row.phase==='returning'&&h===this.terminal&&Array.isArray(payload.actors),'shared_return_not_ready');
  row.phase='rehoming';
  try{
   demand(payload.actors.length===h.sourcePlayers.length&&h.sourcePlayers.every(p=>payload.actors.some(a=>a.id===p.id&&a.epoch===p.epoch)),'shared_return_source_group');
   const source=h.channels.find(c=>c.channel.peer.incarnation===peer.incarnation);demand(source,'shared_return_source_channel');source.answer.actors.push(...payload.actors);
   const held={token:h.token,channels:h.channels.map(({channel,answer})=>({peer:channel.peer,control:channel.control,ack:answer}))};
   await rehomeWorldActors(this.core,held,row.commandAck.result.moves,h.sessions,{exportMethod:'shared_export',admitMethod:'shared_admit'});this.assertScope(row,h,'shared_return_superseded');
   await Promise.all(h.channels.map(async({channel})=>{const answer=await channel.control.request('shared_release',{token:h.token});demand(answer.token===h.token&&answer.released,'shared_release_ack');this.assertScope(row,h,'shared_return_superseded');}));this.assertScope(row,h,'shared_return_superseded');
   const answer=await row.world.control.request('shared_finish',{peer:row.source,proof:row.proof,changes:{monsters:[],participants:[],bossParticipants:[],combatEvents:[]}});this.assertScope(row,h,'shared_return_superseded');row.phase='finished';this.terminal=null;this.wake();return answer;
  }catch(error){this.failScope(row,error,'shared_returnReady',h);throw error;}
 }
 complete(peer,payload){const row=this.entry(peer,payload);demand(row.phase==='finished','shared_complete_phase');this.requests.delete(row.id);this.releasePartitionR113?.(row);this.wake();return {completed:true};}
 abort(error){this.stopUnknownTimers();for(const set of [this.waiters,this.idleWaiters]){for(const waiter of set)waiter.reject(error);set.clear();}}
 fail(error,context={error}){const cause=recoveryCause(this.core,context,'shared_combat_failure');recoveryDiagnostic(this.core,'shared_combat_failure',cause);this.abort(error);this.core.recoveringWorld=true;this.world.global.recover({error,sharedCombat:true,recoveryCause:cause});}
 recovered(){this.stopUnknownTimers();for(const hold of this.ownershipHolds)hold.release();this.requests.clear();this.terminal=null;this.wake();}
}
