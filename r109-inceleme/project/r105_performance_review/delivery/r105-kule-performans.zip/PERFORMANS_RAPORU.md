# R105 performans ölçümü — 11 Kasım 2026

Sonuç: 50 ve 100 oyuncuda ana süreç yükü azaldı. **100 oyuncuda tick <20 ms ve
50 ms üstü gecikme sıfır hedefleri karşılanmadı.** Bu rapor sıfır donma veya
canlı VDS için 100 oyuncu kapasite garantisi değildir. Test edilen kule akışları
komut hatası, native fault veya takılı kalan hesap olmadan tamamlandı.

## Yöntem

10, 50, 100 oyuncu; 200 oyuncu testi yapılmadı. Önceki kaynak, kule/Discord
onarımı tamamlanmış R105_TOWER2 yerel checkpoint'idir; böylece performans
adımlarının katkısı ayrı karşılaştırılır. Sonraki kaynak R105_PERF1 adayıdır.
Her çalışmada10 s ısınma ardından60 s ölçüm; yeni geçici SQLite verisi, dört
ayrı kanal süreci, gerçek oyun kuralları, hareket, düz saldırı, loot/ödül ve
otomatik kule kat geçişi. Süre/ödül/denge kuralları değiştirilmez; yalnız test
karakterleri yüksek HP ve kule düşmanları85HP/9hasar kullanır. Beşli gruplar
kanallara dağıtılır. Doğru sonuç kontrolleri üretim akışında çalışır.

Makine CPU kotası4 çekirdek. Bot üreticileri de ana test sürecinde çalışır;
ana süreç metrikleri bu yükü de içerir. Bunlar tarayıcı FPS veya ağ RTT ölçüsü
olmaz. Tick, mevcut benchmark'ın asenkron tamamlanma dahil duvar süresidir;
tabloda dört kanalın en yüksek p95/p99 değeri verilir. Timer ile histogram
aynı duraklamayı izleyebilir: sayılar yalnız timer sayılarıdır, ikisi toplanmaz.
Bellek RSS'tir; ikinci bellek değeri izlenen süreçlerin maksimumlarının toplamı,
yani aynı anda kesin ölçülmüş toplam değildir. Testler ardışık çalıştırıldı;
ölçüm sırasında başka ağır build/test başlatılmadı.

Efsane kanal kapasitesi25 ile10/50/100 testi yapılır. Akademi mevcut kapasitesi
10/kanal korunarak10 oyuncuyla ayrıca sınandı. Akademi'ye25/kanal yazma denemesi
yalnız geçici test manifestinde güvenlik kontrolünce açılıştan önce reddedildi;
yük ölçümü sayılmadı, canlı veya paket kapasitesi değiştirilmedi.

## Ham karşılaştırma

| Deneme | Oyuncu | Tick p95 / p99 ms | Tick max ms | >50ms ana / kanallar | Ana max ms | Ana ELU | RAM ana / süreçler MiB |
|---|---:|---:|---:|---:|---:|---:|---:|
| İlk / önce | 10 | 4.37 / 7.38 | 55.28 | 3 / 6 | 78.05 | 11.8% | 392 / 1009 |
| İlk / önce | 50 | 15.53 / 28.52 | 119.76 | 6 / 11 | 111.15 | 39.4% | 581 / 1266 |
| İlk / önce | 100 | 28.61 / 42.06 | 95.19 | 9 / 5 | 112.92 | 68.5% | 714 / 1455 |
| İlk / sonra | 10 | 9.41 / 51.11 | 204.73 | 40 / 154 | 1223.69 | 20.1% | 379 / 969 |
| İlk / sonra | 50 | 14.63 / 26.25 | 76.32 | 3 / 9 | 85.46 | 31.7% | 634 / 1324 |
| İlk / sonra | 100 | 27.72 / 48.86 | 136.08 | 4 / 6 | 72.72 | 57.0% | 705 / 1465 |
| Tekrar / önce | 10 | 5.30 / 16.09 | 138.70 | 13 / 41 | 259.05 | 13.9% | 388 / 996 |
| Tekrar / sonra | 10 | 4.80 / 10.37 | 75.75 | 3 / 12 | 74.38 | 9.1% | 390 / 978 |
| Akademi / sonra | 10 | 4.86 / 9.69 | 32.04 | 0 / 4 | 48.92 | 9.4% | 388 / 997 |

10 oyunculuk ilk aday ölçümündeki1.224 s sıçrama gizlenmedi. Aynı iş yüküyle
iki sürüm tekrar ölçüldü; adayda bu uzun sıçrama tekrarlanmadı. Tekrarda ana
GC en uzunu önce21,87 ms / sonra8,02 ms; toplam GC472,49 /246,51 ms oldu.
Önceki sürümde de259 ms timer sıçraması görüldü. İlk1.224 s sıçramanın sebebi
bu verilerle kesinleştirilemedi; yalnız GC veya yalnız kod değişikliğine
atfedilmez. Tek örneklerden istatistiksel kapasite sonucu çıkarılmadı.

50 oyuncuda ana ELU39,4%→31,7%,100 oyuncuda68,5%→57,0% oldu.100 oyuncuda
p95 küçük ölçüde azalırken p99 arttı; bütün metrikler iyileşti denmiyor.
10 oyuncunun ilk ve tekrarlı sonuçları birlikte tutuldu, yalnız iyi sonuç
seçilmedi. En uzun tick ile event-loop duraklaması farklı ölçülerdir.

## Profilin bağımsız incelemesi

Gönderilen profil60,993 s; yaklaşık990 ms inspector başlangıcı içeriyor.
Başlangıç çıkarıldığında örneklenmiş non-idle oranı yaklaşık21,88%. Bu gerçek
CPU kullanımına veya oyuncu başına doğrusal kapasiteye doğrudan çevrilemez.
SQL ölçüm wrapper self süresi yaklaşık543 ms, native SQL leaf toplamı2845 ms.
Dolayısıyla wrapper bütün SQL'den daha pahalı iddiası doğrulanmadı. prepare
~515 ms; kule award çağrı yolu~138 ms, dünya ayarı okuması~97 ms pay taşıyor.
Örneklenmiş profil tek başına134 duraklama veya325 ms GC sebebini kanıtlamaz;
yukarıdaki timer ölçümleri ayrıca yapıldı.

## Uygulananlar ve korunanlar

1. Ayrıntılı SQL attribution varsayılanda kapalı. Kuyruk/commit/fsync süreleri
   ve CPU ölçümleri açık. Gerekli incelemede bağlantı oluşturulmadan önce
   CORE511_SQL_TIMING_R105=1 ile ayrıntı açılır. SQL sonucu/hatası değişmez.
2. Kule ödülleri, dünya ayarları ve presence lease sabit sorguları mevcut
   sınırlı statement cache'ini kullanır. Sorgu sonucu cache'lenmez.
3. Şema/TEMP/rollback kontrolleri korunur; aynı writer işleminde zaten
   güvenli sürüm tekrar kullanımı vardı. Açılışa hapsetmek uygulanmadı.
4. Ping/presence zaten RAM'de; online uygunluk ve oturum sahipliği için
   gereken yazmaları30 saniye geciktirerek davranış değiştirilmedi.
5. Mevcut8 iş/8ms yazma grupları korunur; komut SAVEPOINT'leri kaldırılmadı.
6. Dünya değişmediyse aynı revision ve şema sürümüyle daha önce fsync edilmiş
   immutable görüntü kullanılır.20 alakasız yazmada tam dünya okuması20→0.
7. Süreç yanıtının JSON'u tek gönderimde tekrar kullanılır. Asenkron buffer'lar
   farklı mesajlar arasında paylaşılmaz. Protokol/boyut/replay sınırları aynıdır.
8. Belirtilen scope'lar AsyncLocalStorage değil, SQL yazma/refresh korumaları;
   bunlar ve gerçek savaş kalıcılığı bağlamı kaldırılmadı.
9. EXPLAIN mevcut player/monster/engagement/item indekslerini doğruladı;
   yeni/mükerrer indeks ve veri şeması geçişi yok.
10. Bu tablolar ve çalıştırılabilir yük testi; karar/değişiklikler ayrı commit.

## Doğrulama ve kapsam

SQL ölçüm aç/kapat, native sonuç/hata eşitliği, kısmi rollback, gecikmiş fsync,
yeni/aynı dünya revision'u, şema değişimi, native kule/ödül, dünya reseti
sırasında SIGKILL, presence yetkilendirme, IPC Unicode/sıkıştırma/bozuk paket
ve yeniden bağlantıda tek dispatch regresyonları çalıştırıldı. Ana testte
bulunmayan geçici eslint-scope bağımlılığı geri bağlanıp ilgili3 test geçti;
bu eksik test ortamı bir oyun hatası olarak raporlanmadı.

Ham kanıtlar çalışma dizinindeki evidence/baseline-*, candidate-*, verify-*
ve academy-final-10.json dosyalarıdır. Tam kaynak ve ayrı commit'ler
/workspace/ccre/r105_performance_review altında. Eski before-* ve confirm-*
başarısız fixture denemeleri ham geçmiş olarak saklanır, ölçüm tablosuna
başarılı test gibi eklenmez. Canlı VDS'ye yük veya kurulum yapılmadı.
