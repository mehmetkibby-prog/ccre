# R105 Kadim Kule, Discord ve performans düzenlemesi

Paket: R105_PERF1. Kurulu R104_AKADEMI4 üzerine Efsane ve Akademi birlikte güncellenir.
Önceki yerel R105 kule/bağlantı çalışmaları bu pakete dahildir; tek paket kurulur.

Kadim Kule'de eski canavar kaydının güncel savaş durumunun üzerine yazılması
engellendi. Bağlantı akışı kesildiğinde otomatik toparlanma eklendi. Ana site,
Akademi kayıt sayfası, hesap giriş ekranı ve oyundaki Discord bağlantıları
https://discord.gg/pBywtjhTN olarak yenilendi.

SQL ayrıntı ölçümü varsayılan olarak kapatıldı; mevcut sorgu önbelleği kule
ödüllerinde/dünya işlerinde kullanıldı. Değişmeyen dünya görüntüsü ve süreç
yanıtı yeniden kullanılarak gereksiz kopyalama azaltıldı. Kayıt/ödül/oturum
korumaları tutuldu. Ölçümler ve sınırlar PERFORMANS_RAPORU.md içindedir.

Kurulum yalnız değişen kodu ve ana sitenin tek HTML dosyasını yedekler.
Tam veritabanı taraması veya sıkıştırma yapmaz. Oyuncu ilerlemesi, ödüller,
IP başına oto atak sınırı ve Akademi açılış ayarları değişmez. Bir önceki
sürüme bağımsız dönüş kaydı korunur; iki sunucu ve sekiz kanal hazır
olmadan önceki sağlam kurulum yedeği temizlenmez.

ZIP'i Drive'a yükleyip bağlantısını gönderin. Bu dosyanın SHA256 değeriyle
kısa indirme komutu sağlanacaktır. İndirilmiş paket için ön kontrol:

```bash
python3 /root/r105-kule-performans.zip --check
```

Admin panelinden bakım geri sayımı tamamlandıktan sonra:

```bash
python3 /root/r105-kule-performans.zip --apply
```

Kurulum sonucunda iki sunucu ve sekiz kanal doğrulanır. Hata olursa çıktıyı
paylaşın; eski ZIP'leri veya aynı komutu körlemesine tekrar çalıştırmayın.
Oyuncular yeni istemciyi almak için kurulumdan sonra sayfayı bir kez yeniler.
Bu paket hazırlanırken canlı sunucuya kurulum yapılmadı.
