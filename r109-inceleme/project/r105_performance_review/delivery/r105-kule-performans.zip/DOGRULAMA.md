# R105_PERF1 doğrulama

## Bulunan neden

Oyuncunun gönderdiği canlı günlükte channel2 için tekrarlanan
`attack_frame_conflict` kaydı vardı. Eski R104 koduyla üç ayrı Chromium
sürecindeki gerçek oyun istemcileri normal hareket ve saldırı yaparken
aynı hata üretildi. Bu neden testine ağ kesintisi enjekte edilmedi.

Bir canavar ölünce oyuncu durumu yenilenirken SQL'deki daha eski canavar
canı, kanalın kabul ettiği güncel canın üzerine yazılıyordu. İki canavarlı
ayrı native testte 85 → 55 düşmüş can, diğer canavar ölünce tekrar 85 oldu.
Düzeltmeden sonra üç hesapta da 55 kaldı. Eski veri ölmüş canavarı da
geri getiremiyor. Yeni katın yeni canavarları ve kesinleşen savaş
sonuçları normal biçimde yüklenmeye devam ediyor.

## Yerel kontroller

- Beş hedefli durum yenileme testi ve sekiz bağlantı/toparlanma testi.
- Gerçek native servis ve üç hesapla komşu canavar ölümü regresyonu.
- Üç bağımsız Chromium süreci, aynı IP, üç hesap, ortak grup ile on kat;
  gerçek hareket/saldırı, normal dünya akışı ve otomatik kat geçişleri.
- Dağıtılacak dosyalarla PC/Efsane ve mobil/Akademi: karakter, kanal,
  görünür oyun arayüzü, bağlantı toparlanması ve Discord hedefi.
- Gerçek runtime-entry ile geliştirme dizini dışından iki sunucu/sekiz
  kanal açılışı ve temiz kapanış; Efsane örneğinde 15.000 canavarlı açılış.
- Yirmi kurucu testi: iki sunucu, kod ve site geri dönüşü, değişmiş siteyi
  üzerine yazmadan durma, oyuncu ilerlemesini koruma, eksik istemci modülü
  reddi ve tek önceki sürüm yedeği. Native SQL ölçüm dosyasının önceki hash
  kontrolü, yedeği, geri dönüşü ve sembolik bağ reddi de kapsanır.
- Tüm yeni istemci JS dosyalarında eski Discord adresi bulunmadığı kontrolü.
  Eski sürümün dosyaları geri dönüş için değiştirilmez.

Bunlar izole yerel veri tabanlarıyla testlerdir; canlı VDS yük testi veya
üç farklı tarayıcı markası testi değildir. Önceki R105'in bağlantı toparlanma
testleri kasıtlı akış kesintisi kullanır; ilk çakışmanın neden testi kullanmaz.
Savaş hasarı, ödüller, kat zorluğu, IP sınırı ve veri şeması değiştirilmedi.

## Performans çalışması

Kule düzeltmesi ve Discord tamamlandıktan sonra yapıldı. Her önerinin kararı
ayrı commit; gerekçeler decisions/01–09 dosyalarında tutulur. Gerçek sorgu
planları mevcut indeksleri doğruladığı için yeni indeks/şema geçişi yoktur.
Küçük yazmalar zaten gruplu; SAVEPOINT, fsync, sahiplik ve şema korumaları
kaldırılmadı. Yeni dünya görüntüsü yolu aynı revision'da şema değişimini
atlamaz. IPC buffer'ları mesajlar arasında paylaşılmaz.

10, 50 ve 100 oyuncu için 10 saniye ısınma +60 saniye yerel ölçüm yapılır.
Oyuncular dört gerçek kanal sürecinde hareket eder, kule canavarlarıyla
savaşır, ödül alır ve kat değiştirir. Botlar da ölçüm makinesinde çalışır;
bu test canlı VDS kapasitesi taahhüdü değildir. Tam sayılar, tekrar denemeleri
ve hedefe ulaşılmayan ölçüler PERFORMANS_RAPORU.md içinde yer alır.
