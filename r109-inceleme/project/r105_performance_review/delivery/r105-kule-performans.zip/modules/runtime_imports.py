"""Check changed runtime imports against the final release before stopping it.

Only imports in deployed core modules are examined. Generated browser chunks,
tests and generator tools are not server entry points. This check does not
execute JavaScript or open a database.
"""
import posixpath,re
from pathlib import Path
from storage import require

IMPORT=re.compile(r'''(?:\b(?:import|export)\s+(?:[^;\n]*?\s+from\s*)?|\bimport\s*\(\s*)["']([^"']+)["']''')
CORE='core511-source/scripts/core511/'

def validate(root,plan,archive):
 checked=0
 for name in plan['files']:
  if not name.startswith(CORE) or not name.endswith('.mjs') or '/tests/' in name or Path(name).name.startswith(('extract-','patch-')):continue
  text=archive.read('payload/'+name).decode()
  for specifier in IMPORT.findall(text):
   if not specifier.startswith('.'):continue
   target=posixpath.normpath(posixpath.join(posixpath.dirname(name),specifier))
   require(not target.startswith('../') and not target.startswith('/'),'Sunucu modülü sürüm dışına çıkıyor: '+name+' → '+specifier)
   require(target in plan['files'] or (root/target).is_file(),'Sunucu modülü bulunamadı: '+name+' → '+specifier)
   checked+=1
 return checked
