"""Validate reachable same-release JS/CSS imports before services are stopped."""
import re,posixpath
from storage import require
from inplace_stage import checked_path

REFERENCES=re.compile(r'''["'`]((?:\./|/?assets/)[^"'`\s\\<>]*\.(?:js|css))["'`]''')

def validate(live,plan,updates):
 prefix='http-runtime/dist-vds/client/assets/'+plan['namespace']+'/'
 assets={name[len(prefix):]:(meta,data) for name,meta,data in updates if name.startswith(prefix)}
 pending=[plan[k] for k in ('portal','game','admin')];seen=set();edges=0
 while pending:
  name=pending.pop()
  if name in seen:continue
  require(name in assets,'İstemci dosyası eksik: '+name)
  meta,data=assets[name]
  if data is None:data=checked_path(live.root,meta['linkSource']).read_bytes()
  seen.add(name)
  if not name.endswith(('.js','.css')):continue
  references=REFERENCES.findall(data.decode('utf-8'))
  if name==plan['portal']:
   games={posixpath.basename(p) for p in references if posixpath.basename(p).startswith('game-client-') and p.endswith('.js')}
   require(games=={plan['game']},'Giriş dosyası güncel oyun sürümüne bağlı değil')
  for reference in references:
   if reference.startswith('./'):
    target=posixpath.normpath(posixpath.join(posixpath.dirname(name),reference))
   else:
    absolute='/'+reference.lstrip('/');expected='/assets/'+plan['namespace']+'/'
    require(absolute.startswith(expected),'İstemci sürümü dışında dosya bağlantısı: '+name+' -> '+reference)
    target=absolute[len(expected):]
   require(not target.startswith('../') and target in assets,'İstemci dosyası eksik: '+name+' -> '+target)
   pending.append(target);edges+=1
 return {'files':len(seen),'edges':edges}
