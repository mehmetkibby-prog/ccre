// project/r109_latency_completion/working/core511-source/scripts/core511/admin-navigation-r66.mjs
var ADMIN_GROUPS_R66 = [
  { id: "management", label: "Genel yönetim", items: ["overview", "launch", "registrations", "players", "gm", "updates", "support"] },
  { id: "items", label: "Eşya ve gelişim", items: ["royal_r118", "enchants_r66", "loot", "enhancement491", "materials", "mount_r55", "status", "runes", "specialistSkills459"] },
  { id: "world", label: "Haritalar ve savaş", items: ["champions_r118", "zumrut_r93", "castle_r66", "world", "combat", "champion_r102", "battlefield_r102", "solo", "kadim_tower", "sis_mist", "runes_v2", "stone_boss"] },
  { id: "events", label: "Etkinlikler ve ödüller", items: ["events", "newyear_r102", "community", "eventIsland", "quests438", "battle_pass", "wheel483", "cauldron488", "brokenCore464"] },
  { id: "economy", label: "Ekonomi", items: ["economy", "market", "arenaMarket", "epins"] },
  { id: "security", label: "Güvenlik ve sunucu", items: ["security", "afk_suspects", "loadlab477"] }
];
var details = {
  royal_r118: "Kraliyet dönüşüm malzemeleri, Zümrüt Tozu ve tarifler",
  champions_r118: "Şampiyon haritası, dört canavar, tecrübe, öz ve ganimetler",
  champion_r102: "Giriş bedeli, tecrübe artışı ve on seviye ödülleri",
  battlefield_r102: "Savaş saatleri, oyuncu öldürme ve Zafer Sandığı",
  newyear_r102: "Çorap düşme oranı ve Yılbaşı Sandığı içeriği",
  zumrut_r93: "Balta, kazma, toplama ve şanslı üretim tezgâhı",
  overview: "Canlı oyuncular ve sunucu performansı",
  launch: "Ön kayıt, açılış saati ve bakım",
  registrations: "Hesaplar ve erken giriş izni",
  players: "Karakterler, eşya gönderme ve hesap işlemleri",
  gm: "GM yetkileri ve sunucu duyuruları",
  updates: "Yeni içerikleri önizleme ve açma",
  support: "Oyuncu destek talepleri",
  enchants_r66: "Efsun ihtimalleri ve dört kademe değerleri",
  loot: "Ganimet tabloları, sandıklar ve eşya gücü",
  enhancement491: "Artı basma oranları, malzemeler ve Kor Mührü",
  materials: "Geliştirme malzemelerinin düşme oranları",
  mount_r55: "Binek malzemeleri ve düşme haritaları",
  status: "Statü puanlarının verdiği bonuslar",
  runes: "Rün gelişimi ve bonuslar",
  specialistSkills459: "Uzmanlık becerilerinin gücü ve süreleri",
  castle_r66: "Savaş saati, test modu ve sandık ödülleri",
  world: "Dünya, haritalar, canavarlar ve kanallar",
  combat: "Seviye, deneyim, rütbe ve savaş dengesi",
  solo: "Solo zindan kademeleri ve ganimetleri",
  kadim_tower: "Kule katları, Azrail ve sandık içeriği",
  sis_mist: "Sis Yarığı portalları, düşmanları ve ödülleri",
  runes_v2: "Karanlık Rün Sahili ve boss ayarları",
  stone_boss: "Kara Taş Muhafızı gücü ve ganimetleri",
  events: "Etkinlik takvimi ve bonuslar",
  community: "Ortak hedefler ve kademe ödülleri",
  eventIsland: "Etkinlik Adası, boss planı ve duyurular",
  quests438: "Görev hedefleri ve ödülleri",
  battle_pass: "Savaş Bileti görevleri ve ödülleri",
  wheel483: "Çark ödülleri ve çıkma oranları",
  cauldron488: "Kazan tarifleri ve ödülleri",
  brokenCore464: "Bulmaca sıklığı ve ödüller",
  economy: "Balıkçılık, satış ve demirci ekonomisi",
  market: "Nesne Market fiyatları ve indirimleri",
  arenaMarket: "Arena Market ürünleri ve fiyatları",
  epins: "E-PIN oluşturma ve kod kayıtları",
  security: "Hesap güvenliği ve hile kayıtları",
  afk_suspects: "Şüpheli hareketler ve doğrulama kayıtları",
  loadlab477: "Ayrı test sunucusunda yük denemeleri"
};
var fold = (value) => String(value).toLocaleLowerCase("tr-TR").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replaceAll("ı", "i");
function adminSectionR66(group, fallback) {
  const keys = group.fields?.map((row) => row[0]) ?? [];
  if (keys.length && keys.every((key) => key.startsWith("enchant_"))) return "enchants_r66";
  if (fallback === "loot" && keys.some((key) => /^(?:afk_island_|(?:forest|frozen|black|ancient)_.*respawn|monster_rest_regen_|player_rest_regen_|ancient_boss_)/.test(key))) return "world";
  if (fallback === "loot" && keys.every((key) => key.startsWith("guild_create_"))) return "economy";
  return fallback;
}
var css = `
.admin-r66 .admin-page-enchants_r66 .settings-card{grid-column:1/-1}.admin-r66 .castle59-admin input,.admin-r66 .castle59-admin select{border:1px solid #526958;border-radius:7px;background:#102019;color:#f2ecda;min-height:42px;color-scheme:dark;font:inherit}.admin-r66 .castle59-admin button{border:1px solid #688064;border-radius:7px;background:#29422e;color:#f1dfb8;min-height:42px;font:inherit}.admin-r66 .castle59-admin button:hover:not(:disabled){background:#38583c;border-color:#ccb572}.admin-r66 .castle59-admin button:disabled{opacity:.45;cursor:default}.admin-r66 .castle59-admin :is(input,select,button):focus-visible{outline:2px solid #edcf86;outline-offset:2px}.admin-r66 .castle59-admin>label{margin:16px 0}.admin-r66 .castle59-admin>p{margin:12px 0}.admin-r66 .castle59-admin h2{color:#efd6a0}.admin-r66 .castle59-admin footer{align-items:center}
.admin-r66{--r66-line:#395147;--r66-gold:#e3c785}.admin-r66 *{box-sizing:border-box}.admin-r66 .admin-header{gap:16px;flex-wrap:wrap}.admin-r66 .admin-notice{overflow-wrap:anywhere}.admin-r66 .admin-stats{gap:10px}.r66-nav{margin:22px 0;padding:20px;border:1px solid var(--r66-line);border-radius:14px;background:linear-gradient(120deg,#152b23,#101d18);color:#f0eee4;min-width:0}.r66-nav button,.r66-nav input{font:inherit}.r66-nav button{cursor:pointer}.r66-top{display:flex;align-items:center;justify-content:space-between;gap:18px;margin-bottom:16px}.r66-top strong{font-size:18px;color:var(--r66-gold)}.r66-top p{margin:4px 0 0;color:#aabdb2;font-size:12px}.r66-search{display:flex;align-items:center;gap:10px;min-width:250px}.r66-search input{width:100%;min-width:0;padding:11px 13px;border:1px solid #527361;border-radius:8px;background:#0c1914;color:#f2f3ec;font-size:14px}.r66-search button{border:0;background:transparent;color:#e3c785;padding:10px}.r66-quick{display:flex;gap:8px;flex-wrap:wrap;padding-bottom:16px;margin-bottom:16px;border-bottom:1px solid var(--r66-line)}.r66-quick button{min-height:38px;padding:8px 12px;border:1px solid #445f50;border-radius:7px;background:#1a3127;color:#ecebdc;font-size:12px}.r66-quick button[aria-current=page]{border-color:var(--r66-gold);color:var(--r66-gold)}.r66-groups{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:16px}.r66-groups button{padding:10px 13px;min-height:42px;background:transparent;border:1px solid transparent;border-radius:8px;color:#b5c6bb;font-size:13px}.r66-groups button[aria-pressed=true]{background:#304a39;border-color:#668568;color:#fff4ce}.r66-options{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:9px}.r66-options button{display:flex;align-items:flex-start;gap:11px;min-height:78px;padding:14px 12px;border:1px solid #344b3c;border-radius:9px;background:#13271e;color:#eceddf;text-align:left;min-width:0}.r66-options button:hover,.r66-quick button:hover{background:#244732;border-color:#82a37f}.r66-options button[aria-current=page]{background:#274a32;border-color:var(--r66-gold);box-shadow:inset 3px 0 var(--r66-gold)}.r66-icon{display:flex;flex:0 0 22px;color:#dfc689;padding-top:2px}.r66-icon svg,.r66-icon img{max-width:22px;height:22px}.r66-options strong{display:block;font-size:13px;line-height:1.45}.r66-options small{display:block;color:#afc0b2;font-size:11px;line-height:1.5;margin-top:4px}.r66-options span{min-width:0;overflow-wrap:anywhere}.r66-nav button:focus-visible,.r66-nav input:focus-visible{outline:2px solid #edcf86;outline-offset:3px}.r66-result{font-size:12px;color:#b7c7ba;margin:0 0 12px}.r66-empty{padding:18px;color:#c5d2c6;border:1px dashed #536a59;border-radius:8px}.r66-breadcrumb{margin:20px 0 12px;padding-bottom:12px;border-bottom:1px solid #384d3e;color:#b1c3b4;font-size:12px}.r66-breadcrumb strong{font-size:17px;color:#eedbae;margin-left:10px}.admin-r66 .overview-links{display:none}.admin-r66 .admin-grid{min-width:0}.admin-r66 .admin-grid>*,.admin-r66 .settings-groups>*{min-width:0}.admin-r66 .admin-card h2,.admin-r66 legend{overflow-wrap:anywhere}
@media(max-width:1000px){.r66-options{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media(max-width:650px){.r66-nav{padding:14px;margin:14px 0}.r66-top{align-items:stretch;flex-direction:column;gap:12px}.r66-search{min-width:0;width:100%}.r66-options{grid-template-columns:repeat(2,minmax(0,1fr))}.r66-groups{gap:5px}.r66-groups button{flex:1 1 30%;padding:9px 5px;font-size:12px}.r66-options button{padding:12px 9px;gap:8px}.r66-quick{gap:6px}.r66-quick button{flex:1 1 auto}.r66-breadcrumb strong{display:block;margin:5px 0 0}.admin-r66 .admin-stats{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(prefers-reduced-motion:reduce){.r66-nav *{scroll-behavior:auto}}
`;
function createAdminNavigatorR66(React) {
  const h = React.createElement;
  return function AdminNavigator({ rows, selected, onSelect }) {
    const groupFor = (id) => ADMIN_GROUPS_R66.find((group2) => group2.items.includes(id)) ?? ADMIN_GROUPS_R66[0];
    const [group, setGroup] = React.useState(() => groupFor(selected).id), [query, setQuery] = React.useState("");
    React.useEffect(() => setGroup(groupFor(selected).id), [selected]);
    const available = new Map(rows.map((row) => [row.id, { ...row, note: details[row.id] ?? row.note, label: row.id === "afk_suspects" ? "Şüpheliler" : row.label }]));
    const ordered = [...ADMIN_GROUPS_R66.flatMap((g) => g.items).map((id) => available.get(id)).filter(Boolean), ...rows.filter((row) => !ADMIN_GROUPS_R66.some((g) => g.items.includes(row.id)))];
    const needle = fold(query.trim()), shown = ordered.filter((row) => needle ? fold(row.label + " " + row.note + " " + (row.id === "players" ? "küpe bilezik kemer hediye" : "")).includes(needle) : groupFor(row.id).id === group);
    const choose = (id) => {
      setQuery("");
      onSelect(id);
    }, active = available.get(selected), renderButton = (row, quick = false) => h("button", { key: row.id, type: "button", "data-section": row.id, "aria-current": selected === row.id ? "page" : void 0, onClick: () => choose(row.id) }, quick ? row.label : [h("span", { className: "r66-icon", "aria-hidden": true, key: "icon" }, row.icon), h("span", { key: "label" }, h("strong", null, row.label), h("small", null, row.note))]);
    return h(
      React.Fragment,
      null,
      h("style", null, css),
      h(
        "nav",
        { className: "r66-nav", "aria-label": "Yönetim bölümleri" },
        h("div", { className: "r66-top" }, h("div", null, h("strong", null, "Yönetim merkezi"), h("p", null, "Bölüm seç veya aradığın ayarı bul.")), h("label", { className: "r66-search" }, h("input", { type: "search", "aria-label": "Panelde bölüm ara", placeholder: "Efsun, kale, oyuncu…", value: query, onChange: (e) => setQuery(e.target.value) }), query && h("button", { type: "button", onClick: () => setQuery(""), "aria-label": "Aramayı temizle" }, "Temizle"))),
        h("div", { className: "r66-quick", "aria-label": "Sık kullanılanlar" }, ...["launch", "registrations", "players", "enchants_r66", "castle_r66"].map((id) => available.get(id)).filter(Boolean).map((row) => renderButton(row, true))),
        h("div", { className: "r66-groups", "aria-label": "Bölüm grupları" }, ...ADMIN_GROUPS_R66.map((g) => h("button", { key: g.id, type: "button", "aria-pressed": !needle && g.id === group, onClick: () => {
          setGroup(g.id);
          setQuery("");
        } }, g.label))),
        needle && h("p", { className: "r66-result", role: "status" }, shown.length + " bölüm bulundu"),
        shown.length ? h("div", { className: "r66-options" }, ...shown.map((row) => renderButton(row))) : h("p", { className: "r66-empty" }, "Bölüm bulunamadı. Daha kısa bir kelime deneyebilirsin.")
      ),
      h("div", { className: "r66-breadcrumb", "aria-live": "polite" }, groupFor(selected).label, h("strong", null, active?.label ?? "Yönetim"))
    );
  };
}
export {
  ADMIN_GROUPS_R66,
  adminSectionR66,
  createAdminNavigatorR66
};
