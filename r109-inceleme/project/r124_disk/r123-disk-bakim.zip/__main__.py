import os, subprocess, sys, tempfile
from pathlib import Path
from zipfile import ZipFile
os.umask(0o077)
with tempfile.TemporaryDirectory(prefix='col-r123-disk-') as directory:
    with ZipFile(sys.argv[0]) as archive:
        for name in archive.namelist():
            if name == '__main__.py':
                continue
            path = Path(name)
            if path.is_absolute() or '..' in path.parts:
                raise SystemExit('Invalid archive path')
            archive.extract(name, directory)
    raise SystemExit(subprocess.call([sys.executable, str(Path(directory) / 'runner.py'), *sys.argv[1:]]))
