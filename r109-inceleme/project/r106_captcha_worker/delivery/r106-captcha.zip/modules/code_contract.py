# Exact reviewed code-only delta.
PLAN_SHA256 = 'c2090ea020413644925db5fbe20f62795ffffb30f86e09c91854d5963e0566c4'
