# R106 captcha ve performans incelemesi — 11 Kasım 2026

Captcha çizimi artık veritabanı işlemi ve oyun koordinatörü dışında, sınırlı bir yardımcı iş parçacığında çalışıyor. İlk resmin veritabanı callback süresi bu ölçümde 28,32 ms → 0,60 ms. Bu değişiklik bütün GC/donma kaynaklarının giderildiği anlamına gelmez. **100 oyuncuda tick <20 ms ve sıfır >50 ms duraklama hedefi sağlanmadı.**

## Captcha karşılaştırması

Gerçek native LocalDatabase, WAL ve async fsync; eski/yeni aynı iş yükü, ayrı süreçler. İlk resim ardından üç kez 20 eşzamanlı kayıt resmi; toplam 61 challenge. Aynı sayıda geçerli kayıt, aynı güvenlik kuralları. Timer gecikmesi bu küçük testte 2 ms aralığının üzerindeki gecikmedir; oyun tablosundaki ham timer boşluğuyla birebir aynı metrik değildir.

| Sürüm / aşama | DB callback p95 / max ms | En uzun transaction ms | Ana timer gecikmesi max ms | Yanıt p95 ms | RSS bitiş MiB |
|---|---:|---:|---:|---:|---:|
| r105 / cold | 28.32 / 28.32 | 29.41 | 28.44 | 31.13 | 41.5 |
| r105 / warm-bursts | 7.46 / 10.30 | 10.56 | 9.95 | 127.43 | 53.3 |
| r106 / cold | 0.60 / 0.60 | 1.12 | 2.18 | 100.10 | 55.6 |
| r106 / warm-bursts | 0.15 / 0.22 | 0.48 | 1.50 | 160.83 | 68.5 |

İlk worker açılışı yanıtı yaklaşık 31 → 100 ms uzattı; sıcak 60 istekte toplam süreç CPU süresi 443 → 547 ms, bitiş RSS farkı yaklaşık 15 MiB. Amaç çizim işini oyun döngüsünden ayırmaktır; toplam CPU azalması iddiası yoktur. Worker tembel açılır, kuyruk 128 istekle ve istek ömrü 10 saniyeyle sınırlıdır. Worker başarısızlığında ana süreçte senkron çizime dönülmez.

## Botlar ayrı süreçte: sunucu ölçümü

Allocation bulgusu üzerine botlar ayrı Node sürecine/heap’e taşındı. Üretim kodu değişmeden aynı oyun, dört kanal ve native HTTP/WebSocket işlemleri kullanıldı. Sunucu tarafındaki yerel test bağlantı geçidi ölçüme dahildir. CPU kotası hâlâ aynı makinede paylaşılır; bu da canlı VDS kapasite garantisi değildir. Aşağıdaki sunucu RAM/CPU değerlerine ayrı bot süreci dahil değildir; onun RAM’i son sütundadır. Her koşu 10 saniye ısınma +60 saniye ölçümdür. 10 saniyelik harness ön kontrolü performans tablosuna alınmadı.

| Koşu | Tick p95 / p99 ms | >50 ms ana / kanallar | Ana max ms | Ana ELU | Sunucu CPU / 4 çekirdek | RAM ana / sunucular / bot MiB |
|---|---:|---:|---:|---:|---:|---:|
| r106-isolated-10 | 4.53 / 10.60 | 0 / 4 | 37.00 | 7.6% | 12.0% | 386 / 996 / 111 |
| r106-isolated-50 | 11.93 / 19.25 | 1 / 0 | 69.50 | 23.2% | 35.9% | 541 / 1226 / 122 |
| r105-isolated-100 | 26.45 / 43.42 | 2 / 5 | 54.26 | 44.5% | 63.8% | 662 / 1423 / 125 |
| r106-isolated-100 | 28.77 / 72.68 | 18 / 60 | 195.04 | 45.0% | 64.6% | 661 / 1409 / 126 |

Bu ayrım test istemcisinin GC’sini sunucudan ayırır. Oyuncu başına CPU yüzdesiyle doğrusal kapasite tahmini yapılmaz; bütün işlevsel koşular ve kalan gecikmeler birlikte raporlanır.

## İlk karşılaştırma: botlar aynı süreçte

200 oyuncu denenmedi. Efsane: dört gerçek kanal süreci, 25/kanal; 10 saniye ısınma ve 60 saniye ölçüm. Beşli kule grupları hareket eder, saldırır, ödül alır ve otomatik kat değiştirir. Yalnız test oyuncusu HP ve düşman HP/hasarı fixture değeridir. Botlar aynı makinede ve ana test sürecinde çalışır; CPU ve bellek bot maliyetini de içerir. Bunlar canlı VDS kapasite veya tarayıcı FPS ölçümleri değildir. Normal kule koşusu captcha üretmez; bu tablo captcha hızlanmasını ölçmek için kullanılmaz.

Dört çekirdek CPU kotası. CPU sütunu bütün izlenen süreçlerin toplam tüketiminin bu kotaya oranıdır; ELU ana olay döngüsünün meşguliyetidir. Tick p95/p99 sütunu dört kanalın en yüksek değeridir. RAM ana süreç RSS / izlenen süreçlerin tepe RSS toplamıdır; ikinci sayı eşzamanlı kesin tepe değildir. >50 ms sayıları ham timer gözlemidir; histogram ayrıca aynı olayı yakalayabildiğinden sayılar toplanmaz. En uzun duraklama timer/histogram maksimumudur.

| Deneme | Tick p95 / p99 ms | Tick max ms | >50 ms ana / kanallar | Ana max ms | ELU | CPU / 4 çekirdek | RAM ana / toplam MiB |
|---|---:|---:|---:|---:|---:|---:|---:|
| r105-10 | 5.29 / 10.78 | 52.22 | 3 / 8 | 87.75 | 9.8% | 13.4% | 387 / 1000 |
| r106-10 | 5.16 / 9.89 | 51.83 | 4 / 11 | 74.19 | 10.2% | 14.3% | 388 / 1001 |
| r105-50 | 14.81 / 28.03 | 128.34 | 1 / 5 | 79.10 | 31.6% | 41.4% | 609 / 1291 |
| r106-50 | 12.89 / 18.54 | 37.38 | 0 / 0 | 41.65 | 29.0% | 38.4% | 616 / 1300 |
| r105-100 | 24.67 / 44.42 | 96.13 | 5 / 0 | 61.47 | 55.3% | 67.1% | 716 / 1462 |
| r106-100 | 29.89 / 83.06 | 407.79 | 10 / 31 | 210.11 | 58.8% | 69.8% | 718 / 1469 |
| r106-academy-10 | 4.53 / 8.47 | 83.40 | 2 / 11 | 88.01 | 9.1% | 12.7% | 384 / 994 |

Her koşuda bütün hesaplar bağlı kaldı; komut/native hata ve bekleyen işlem görülmedi. Akademi 10/kanal kapasitesi korunarak 10 oyuncuyla ayrıca sınanır; 50/100 için kapasite koruması kaldırılmaz. İşlevsel başarı, performans hedefinin sağlandığı anlamına gelmez.

İlk R106 100 oyuncu denemesinde 182 ms Scavenge ve 210 ms ana gecikme görüldü. Eski sürümün GC kayıtlı tekrarında da 117,60 ms Scavenge ve 209,62 ms ana gecikme görüldü. Captcha üretilmeyen bu koşulda farkı captcha değişikliğine bağlamak doğru olmaz. Testleri yalnız iyi sonuçları seçmeden aşağıda koruduk. CPU kotası nedeniyle throttling de görüldü; herhangi bir gecikme sonuçtan çıkarılmadı.

## Son altı önerinin incelemesi

### 1. GC türü ve 32 MB denemesi

Yerel süreçler gerçek `--trace-gc` ile çalıştırıldı; ayrıca PerformanceObserver GC türü ve süresini ölçtü. Canlı VDS’ye kabuk erişimi olmadığı için **canlıda bir saatlik trace alınmadı**. Aşağıdaki ek koşular 100 oyuncu / 60 saniyedir. Allocation satırında inspector CPU ve allocation örneklemesi ek yük oluşturur; normal hız karşılaştırmasına katılmamalıdır.

| Koşu | Scavenge adet / max ms | Major GC max ms | Ana >50 ms | Ana max ms | Ana RSS MiB |
|---|---:|---:|---:|---:|---:|
| r105-trace | 432 / 117.60 | 15.90 | 13 | 209.62 | 715 |
| r106-trace | 440 / 26.26 | 30.09 | 10 | 113.64 | 725 |
| r106-semi32 | 220 / 31.07 | 28.94 | 3 | 100.20 | 749 |
| r106-allocation | 432 / 82.30 | 17.32 | 14 | 104.83 | 736 |

32 MB denemesinde küçük GC sayısı azaldı; en uzun küçük GC iyileşmedi, >50 ms gecikme devam etti ve bellek arttı. Bu tek çift koşu genel iyileşmeyi veya güvenli canlı kapasiteyi kanıtlamaz. Canlı Node ayarı değiştirilmedi. Uzun yerel örnekler Scavenge idi; Major GC kaynaklı büyüyen nesne/sızıntı kanıtı yok. Canlı heap snapshot alınmadı.

### 2. drainWrites allocation

100 oyuncuda 32 KiB örnekleme aralığıyla toplam yaklaşık 4.74 GiB tahmini kümülatif allocation örneklendi. Bu tutar tutulan heap/RAM değildir. drainWrites altındaki tahmini pay 16.0%. En büyük kalemler aşağıdadır; wrapper adı, alttaki native SQLite sonucunun nesne üretimini de gösterebilir.

| drainWrites altındaki kaynak | Tahmini kümülatif MiB |
|---|---:|
| (anonymous) — command-failure-scope.mjs:28 | 212.0 |
| createAttackWriterRules — attack-writer-rules.mjs:75 | 46.0 |
| (anonymous) — actor-checkpoint.mjs:36 | 43.8 |
| writeReceipt — compact-receipt.mjs:24 | 33.5 |
| assertCommandOutputSize — command-output-guard.mjs:11 | 31.2 |
| next — :0 | 29.5 |

Toplam örnekte ws.onMessage, istemci dünya birleştirme ve client-transport yüksek pay taşıyor: test botları ana süreçtedir. Bu nedenle bu allocation miktarları canlı sunucuya aynen taşınamaz. Dünya/market/lonca isimli koruma kapsamları diğer işlemleri de sarar; o isimlerin stack içinde olması bu kayıtların donmanın asıl kaynağı olduğunu kanıtlamaz. “Bütün GC donmaları drainWrites/world-market-guild yüzünden” sonucu doğrulanmadı. Atomik kayıt ve tekrar işleme korumaları kaldırılmadı.

### 3. SQLite ve COMMIT

İncelenen native yazıcı WAL kullanıyor. Async WAL senkronizasyonu açıkken synchronous=NORMAL (1); yanıt yine fsync sonucunu bekliyor. Hata durumunda FULL’a dönüş var. Focused gerçek LocalDatabase testinde WAL/NORMAL ve asyncWal=true okundu. Canlı bağlantının PRAGMA değeri uzaktan ayrıca okunmadı. drainWrites zaten en fazla 8 işi veya yaklaşık 3 ms iş bütçesini bir transaction içinde topluyor; her işin SAVEPOINT’i ayrı hata geri dönüşünü koruyor. Yeni COMMIT/ACK gevşetmesi yapılmadı.

### 4. Retaliation ve reward sorguları

nativeAtomicStatements bağlantı başına en fazla 512 SQL kalıbını, reward-sql-r531 ise sınırlı statement ve ödül tarifi önbelleğini zaten kullanıyor. Saldırı/ölüm/ödül işlemleri sahiplik, HP/ekipman güncelliği ve tek ödül garantisiyle sıralanıyor. “Her saldırıda aynı iki sorgu bağımsız COMMIT ediyor” varsayımı doğrulanmadı. Bunları tick sonuna ertelemek veya tek sorguya sıkıştırmak mevcut doğruluk kanıtını korumadan yapılmadı.

### 5. Prepare önbelleği

Son gönderilen 1 oyunculu CPU dosyasında native prepare örneklenmiş süresi yaklaşık 25,16 ms; 170 ms/dakika bu dosyada doğrulanmadı. 100 botlu ve inspector açık farklı yükte bu sayı doğal olarak daha yüksek; birebir canlı karşılaştırma değildir. actor-checkpoint bağlantı başına prepared handle ve değişen sütun kalıbı önbelleği kullanıyor. prepareCached477 256 giriş/512 KiB sınırına ve şema/rollback doğrulamasına sahip. bot-check temel sorguları baştan hazırlanıyor. NativeBotCheck.refresh içindeki iki ek okuma profilin başlıca sıcak noktası değil. Şema koruması kaldırılmadı, sonuç verisi cache’lenmedi.

### 6. Süreçler arası mesajlar

ProcessStream._writev mevcut yazı gruplarını tek pipe mesajına topluyor; R105 aynı yanıtın JSON metnini tekrar kullanıyor. Tick başına bütün kontrol/ACK mesajlarını bekletmek gecikme, sahiplik devri ve tekrar gönderim davranışını değiştirir. Bu değişiklik uygulanmadı; mevcut çerçeve, boyut, sıra ve idempotent tekrar kontrolleri korundu.

## Tek oyunculu canlı CPU dosyası

60,45 saniyelik dosyanın inspector başlangıcı çıkarıldığında örneklenmiş non-idle payı yaklaşık %2,88. Eski dosya 10 oyunculu olduğundan yüzdelik iyileşme veya oyuncu başına doğrusal kapasite hesabı yapılamaz. Yaklaşık 103 ms ardışık GC örneği görülüyor; CPU dosyası tek başına kesin event-loop duraklaması veya GC kökeni kanıtlamaz. Tick ve RAM bu dosyada yoktur. Ayrıntı: ../r105_postinstall_profile/RAPOR.md.

Ham kanıtlar evidence/ altında korunur: r105/r106-10/50/100.json, captcha-benchmark-*.json, GC trace logları, r106-allocation-100.heapprofile/.cpuprofile ve gc-allocation-audit.json. Dağıtılan oyun kodunda kalıcı profil/trace veya 32 MB bayrağı açılmaz.
