# R106 doğrulama kapsamı

- Captcha resmi üretilirken SQLite transaction ve oyun koordinatörü serbest.
- Kayıt: aynı IP'deki bağımsız formlar, CSRF/origin, deneme sınırı ve tek kullanım.
- Oyun: eşzamanlı istekler aynı resmi kullanır; çizim sırasında oturum bitmesi
  veya başka oturumdan doğrulama, eski challenge kurulmasına izin vermez.
- Kuyruk sınırlı; worker çökmesi/zaman aşımı ve tekrar açılışı sınanır. Ana
  süreçte senkron çizime geri düşülmez; yarım challenge kaydı bırakılmaz.
- Paket kaynak/hedef dosya hash'lerine bağlıdır. Kaynak R105_PERF1 zorunlu.
- Kurulum, yarım dosya yazımı, sağlık kontrolü hatası ve bağımsız geri dönüş
  oyuncu kayıtlarını değiştirmeden sınanır; yeni worker dosyaları geri alınır.
- İstemci değişmese de kurulu oyun/hesap JS-CSS grafiği doğrulanır. Eski oyun
  bağlantısı, eksik dosya ve dışarıya giden modül yolu kurulumdan önce reddedilir.
- Dağıtılan dosyalarla iki realm, sekiz gerçek kanal ve worker başlangıcı; PC
  Efsane ve mobil Akademi karakter seçimi/oyun girişi kontrol edilir.

Sonuç kanıtları ayrı sürüm doğrulama kaydında tutulur. Performans sonucu,
fonksiyonel testlerin geçmesinden ayrı değerlendirilir; test yükü canlı VDS
kapasite garantisi değildir. GC/CPU iddialarının sınırları raporda açıklanır.
