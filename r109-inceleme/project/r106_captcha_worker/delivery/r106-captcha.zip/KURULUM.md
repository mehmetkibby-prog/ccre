# R106 captcha düzeltmesi

Kaynak sürüm R105_PERF1; hedef R106_CAPTCHA1. Efsane, Akademi ve ortak kayıt
servisi birlikte güncellenir. Captcha resmi sınırlı bir yardımcı iş parçacığında
çizilir; resim hazırlanırken oyun ana döngüsü ve veritabanı işlemi bekletilmez.
Yanıt, tek kullanım, deneme sayısı, süre sonu ve oturum kontrolleri korunur.

Yalnız değişen kod dosyaları yedeklenir. Tam veritabanı taraması, sıkıştırma,
şema/veri geçişi veya site/arayüz değişikliği yoktur. Bir önceki sürüme dönüş
kaydı iki sunucunun sekiz kanalı doğrulandıktan sonra korunur. Akademi açılışı,
bakım tercihleri, oyuncu ilerlemesi ve IP başına oto atak kuralı korunur.

Ölçümler ve sınırlar PERFORMANS_RAPORU.md içindedir. Bu paket bütün donma
kaynaklarını giderdiği veya 100 oyuncuda gecikmesiz çalışma iddiası taşımaz.

ZIP'i Drive'a yükleyip bağlantısını gönderin; doğrulanmış SHA256 ile kısa
indirme komutu hazırlanır. İndirildikten sonra ön kontrol:

```bash
python3 /root/r106-captcha.zip --check
```

Ana admin panelinden bakım geri sayımı tamamlandıktan sonra:

```bash
python3 /root/r106-captcha.zip --apply
```

Sonuçta CAPTCHA DÜZELTMESİ TAMAMLANDI mesajı beklenir. Hata olursa çıktıyı
paylaşın; eski paketleri veya aynı kurulumu körlemesine tekrar çalıştırmayın.
Bu dosyanın hazırlanması canlıya kurulum yapıldığı anlamına gelmez.
