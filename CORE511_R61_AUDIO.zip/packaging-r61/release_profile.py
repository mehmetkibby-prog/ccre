"""Read a boolean Core511 release profile without shell/export semantics."""
import re

def read_flags(lines):
    flags={}
    for number,line in enumerate(lines,1):
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        if not re.fullmatch(r'CORE511_[A-Z0-9_]+=[01]',line):
            raise ValueError('Invalid boolean release flag at line '+str(number))
        key,value=line.split('=',1)
        if key in flags:
            raise ValueError('Duplicate release flag: '+key)
        flags[key]=value
    if not flags:
        raise ValueError('Empty release flag profile')
    return flags
