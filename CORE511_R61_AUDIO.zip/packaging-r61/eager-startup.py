"""Narrow installer adapter: owned game-service eager V8 startup, no game code."""
from pathlib import Path

POLICY = {'version': 1, 'flag': 'CORE511_R61_EAGER_REWARD', 'service': 'game',
          'nodeArgumentsWhenEnabled': ['--no-lazy'],
          'dropInName': '91-core511-r61-eager.conf', 'accountsChanged': False,
          'customExecStart': 'refuse-without-mutation'}

RUNTIME = r'''
# Installer-owned launch policy. No production module or accounts unit changes.
R61_SYSTEMD_ROOT = Path('/etc/systemd/system')
R61_EAGER_FLAG = 'CORE511_R61_EAGER_REWARD'
R61_EAGER_DROPIN = '91-core511-r61-eager.conf'

def startup_file(unit):
    require(re.fullmatch(r'coreoflife-[A-Za-z0-9_-]+\.service', unit) and unit != 'coreoflife-accounts.service', 'R61_oyun_servisi_kapsami')
    return R61_SYSTEMD_ROOT / (unit + '.d') / R61_EAGER_DROPIN

def startup_arguments(live, enabled):
    node, entry = str(live.node), str(live.root / (DELIVERY + 'runtime-entry.mjs'))
    require(all(re.fullmatch(r'/[A-Za-z0-9_./-]+', p) and '..' not in Path(p).parts for p in [node, entry]), 'R61_baslatma_yolu')
    return [node, *(['--no-lazy'] if enabled else []), entry]

def startup_bytes(live, enabled):
    if not enabled:
        return b'# Core511 R61 eager startup disabled; managed launch remains unchanged.\n'
    return ('# Owned by the Core511 R61 installer.\n[Service]\nExecStart=\nExecStart=' + ' '.join(startup_arguments(live, True)) + '\n').encode()

def startup_flag(live):
    env = read_json(live.config_file).get('environment', {})
    value = env.get(R61_EAGER_FLAG, '0')
    require(value in ('0', '1'), 'R61_baslatma_anahtari')
    return value == '1', R61_EAGER_FLAG in env

def startup_regular(file):
    require(file.is_absolute() and file.resolve() == file and not file.is_symlink(), 'R61_servis_dosyasi_yolu')
    st = regular(file)
    require(st.st_uid == 0 and not stat.S_IMODE(st.st_mode) & 0o022, 'R61_servis_dosyasi_sahibi')
    return st

def startup_directory(unit):
    target = startup_file(unit)
    for folder in (R61_SYSTEMD_ROOT, target.parent):
        st = folder.lstat()
        require(stat.S_ISDIR(st.st_mode) and not folder.is_symlink() and folder.resolve() == folder and st.st_uid == 0 and not stat.S_IMODE(st.st_mode) & 0o022, 'R61_servis_dizini_sahibi')
    return target

def startup_inspect(live, *, installed):
    """Refuse custom argv/prefixes; retain every other existing unit attribute."""
    target = startup_directory(live.unit)
    require(prop(live.unit, 'LoadState') == 'loaded', 'R61_servis_yuklu_olmali')
    require(prop(live.unit, 'NeedDaemonReload') == 'no', 'R61_servis_bekleyen_degisim_var')
    fragment = Path(prop(live.unit, 'FragmentPath'))
    require(fragment == R61_SYSTEMD_ROOT / live.unit, 'R61_servis_fragment_kapsami')
    startup_regular(fragment)
    paths = [Path(p) for p in prop(live.unit, 'DropInPaths').split()]
    require(len(paths) == len(set(paths)) and all(p.parent == target.parent and re.fullmatch(r'[A-Za-z0-9_.-]+\.conf', p.name) for p in paths), 'R61_servis_dropin_kapsami')
    managed = target.parent / '90-core511.conf'
    owner = next((r for r in live.state.get('prior', {}).get('changedUnits', []) if r.get('unit') == live.unit and r.get('file') == str(managed)), None)
    require(owner and managed in paths, 'R61_yonetilen_servis_kaniti_yok')
    for file in paths:
        startup_regular(file)
    require(digest(managed.read_bytes()) == owner.get('sha256'), 'R61_yonetilen_servis_degisti')
    expected_line = 'ExecStart=' + ' '.join(startup_arguments(live, False))
    lines = managed.read_text().splitlines()
    require(lines.count('ExecStart=') == 1 and lines.count(expected_line) == 1 and sum(line.startswith('ExecStart=') for line in lines) == 2, 'R61_yonetilen_baslatma_uyusmazligi')
    enabled, configured = startup_flag(live)
    if installed:
        require(configured and target in paths and target.read_bytes() == startup_bytes(live, enabled), 'R61_baslatma_dropin_uyusmazligi')
    else:
        require(not target.exists() and not target.is_symlink() and target not in paths, 'R61_baslatma_dropin_zaten_var')
        require(not configured, 'R61_baslatma_anahtari_kurulmadan_ayarlanmis')
    # ExecStartEx exposes executable prefixes/flags as well as argv. A plain
    # ExecStart property alone cannot prove that @, -, +, ! or : is absent.
    command = prop(live.unit, 'ExecStartEx')
    prefix = r'\{\s*path=' + re.escape(str(live.node)) + r'\s*;\s*argv\[\]=' + re.escape(' '.join(startup_arguments(live, enabled))) + r'\s*;\s*flags=\s*;\s*'
    tail = r'start_time=[^{};]*;\s*stop_time=[^{};]*;\s*pid=\d+\s*;\s*code=[^{};]*;\s*status=[^{};]*\s*\}'
    require(re.fullmatch(prefix + tail, command), 'R61_ozel_ExecStart_desteklenmiyor')
    return {str(p): digest(p.read_bytes()) for p in [fragment, *paths]}

def startup_prepare(live, spec):
    require(spec.get('nodeStartup') == R61_NODE_STARTUP_POLICY, 'R61_baslatma_paket_kaniti')
    startup_inspect(live, installed=False)
    return {startup_file(live.unit): startup_bytes(live, R61_INSTALL_FLAGS[R61_EAGER_FLAG] == '1')}

def startup_verify(live):
    enabled, configured = startup_flag(live)
    startup_inspect(live, installed=configured)

def startup_reload(live):
    command(['/usr/bin/systemctl', 'daemon-reload'])
    startup_verify(live)

def startup_running(live, argv):
    enabled, configured = startup_flag(live)
    if configured:
        require([os.fsdecode(a) for a in argv if a] == startup_arguments(live, enabled), 'R61_calisan_baslatma_argumanlari')

def startup_flag_change(live, record, next_config):
    startup_verify(live)
    file = startup_file(live.unit)
    row = next((r for r in record['files'] if r['file'] == str(file)), None)
    require(row is not None, 'R61_baslatma_yedegi_yok')
    before = file.read_bytes()
    require(digest(before) == row['after'], 'R61_baslatma_disaridan_degisti')
    after = startup_bytes(live, next_config['environment'].get(R61_EAGER_FLAG, '0') == '1')
    record['approvedStartupHashes'] = [digest(before), digest(after)]
    return file, row, before, after
'''

def adapt(source):
    def replace(old, new, count=1):
        nonlocal source
        assert source.count(old) == count, (old[:100], source.count(old), count)
        source = source.replace(old, new)
    replace('class Live:\n', 'R61_NODE_STARTUP_POLICY = ' + repr(POLICY) + '\n' + RUNTIME + '\n\nclass Live:\n')
    replace('    allowed.update((STATE, live.config_file))', '    allowed.update((STATE, live.config_file, startup_file(live.unit)))')
    replace("        entry = str(self.root / 'core511-source/scripts/delivery511/runtime-entry.mjs').encode()", "        startup_running(self, argv)\n        entry = str(self.root / 'core511-source/scripts/delivery511/runtime-entry.mjs').encode()")
    replace('        self.ready(revision)\n', '        self.ready(revision)\n        startup_verify(self)\n        self.active_binding()\n')
    replace('    updates[live.config_file] = encoded(next_config)\n    require_authorized_updates', '    updates[live.config_file] = encoded(next_config)\n    updates.update(startup_prepare(live, spec))\n    require_authorized_updates')
    replace("        if isinstance(data, HardLink):\n            row['hardlinkSource']", "        if file == startup_file(unit):\n            row.update(mode=0o644, uid=0, gid=0)\n        if isinstance(data, HardLink):\n            row['hardlinkSource']")
    replace('        if file in (STATE, LIVE_CONFIG_FILE):\n            continue', '        if file in (STATE, LIVE_CONFIG_FILE, startup_file(unit)):\n            continue')
    replace("    allowed.add(str(STATE))", "    allowed.add(str(STATE))\n    allowed.add(str(startup_directory(record['unit'])))")
    replace("        if file == LIVE_CONFIG_FILE:\n            accepted.extend(record.get('approvedConfigHashes', []))", "        if file == LIVE_CONFIG_FILE:\n            accepted.extend(record.get('approvedConfigHashes', []))\n        if file == startup_file(record['unit']):\n            accepted.extend(record.get('approvedStartupHashes', []))")
    replace('def verify_installed(live, spec):\n', 'def verify_installed(live, spec):\n    startup_verify(live)\n')
    replace('                    if file not in (STATE, LIVE_CONFIG_FILE):', '                    if file not in (STATE, LIVE_CONFIG_FILE, startup_file(live.unit)):')
    replace('                verify_installed(live, spec)\n                live.start_services', '                startup_reload(live)\n                verify_installed(live, spec)\n                live.start_services')
    replace('                restore(directory, record)\n                verify_restored', '                restore(directory, record)\n                startup_reload(live)\n                verify_restored')
    replace('                    restore(directory, record)\n                    verify_restored', '                    restore(directory, record)\n                    startup_reload(live)\n                    verify_restored')
    replace("        record['approvedConfigHashes'] = [digest(before),digest(after)]", "        startup_target, startup_row, startup_before, startup_after = startup_flag_change(live, record, json.loads(after))\n        record['approvedConfigHashes'] = [digest(before),digest(after)]")
    replace("            atomic(live.config_file,after,stat.S_IMODE(st.st_mode),st.st_uid,st.st_gid)\n            live.same_database()", "            require(startup_target.read_bytes() == startup_before, 'R61_baslatma_islem_sirasinda_degisti')\n            atomic(live.config_file,after,stat.S_IMODE(st.st_mode),st.st_uid,st.st_gid)\n            atomic(startup_target,startup_after,0o644,0,0)\n            startup_reload(live)\n            live.same_database()")
    replace("                atomic(live.config_file,before,stat.S_IMODE(st.st_mode),st.st_uid,st.st_gid)\n                live.same_database()", "                atomic(live.config_file,before,stat.S_IMODE(st.st_mode),st.st_uid,st.st_gid)\n                atomic(startup_target,startup_before,0o644,0,0)\n                startup_reload(live)\n                live.same_database()")
    replace("            record.pop('approvedConfigHashes',None)", "            record.pop('approvedConfigHashes',None)\n            record.pop('approvedStartupHashes',None)")
    replace("        row['after'] = digest(after)\n        record.pop('approvedConfigHashes',None)", "        row['after'] = digest(after)\n        startup_row['after'] = digest(startup_after)\n        record.pop('approvedConfigHashes',None)\n        record.pop('approvedStartupHashes',None)")
    compile(source, 'R61-eager-installer', 'exec')
    return source
