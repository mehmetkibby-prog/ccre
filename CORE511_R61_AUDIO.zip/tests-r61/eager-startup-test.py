"""Small real-file installer startup transactions; systemd manager is simulated."""
from pathlib import Path
from types import ModuleType, SimpleNamespace
import contextlib, hashlib, importlib.util, json, tempfile, unittest

R = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('eager_adapter', R/'packaging-r61/eager-startup.py')
adapter = importlib.util.module_from_spec(spec); spec.loader.exec_module(adapter)
source = (R/'package-r61/__main__.py').read_text()
ADAPTED_IN_MEMORY = 'R61_NODE_STARTUP_POLICY = ' not in source
if ADAPTED_IN_MEMORY:
    source = adapter.adapt(source)

class Startup(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='r61-startup-'); self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name); self.m = m = ModuleType('r61_startup_fixture')
        m.__file__ = str(R/'package-r61/__main__.py'); exec(compile(source,m.__file__,'exec'),m.__dict__)
        self.root = self.base/'release'; self.root.mkdir(); self.units = self.base/'systemd'; self.units.mkdir(mode=0o755)
        self.unit = 'coreoflife-r1.service'; self.dropins = self.units/(self.unit+'.d'); self.dropins.mkdir(mode=0o755)
        self.fragment = self.units/self.unit; self.fragment.write_text('[Service]\nUser=col-r1\nExecStart=/usr/bin/node old.mjs\n')
        self.node = self.root/'bin/node'; self.node.parent.mkdir(); self.node.write_bytes(b'fixture-node')
        self.entry = self.root/(m.DELIVERY+'runtime-entry.mjs')
        self.managed = self.dropins/'90-core511.conf'
        self.managed.write_text('[Service]\nExecStart=\nExecStart='+str(self.node)+' '+str(self.entry)+'\nMemoryMax=3G\nUser=col-r1\n')
        self.target = self.dropins/'91-core511-r61-eager.conf'
        self.accounts = self.units/'coreoflife-accounts.service'; self.accounts.write_bytes(b'unchanged accounts')
        self.config = self.base/'config.json'; self.config.write_text('{"environment":{}}\n')
        m.STATE = self.base/'state.json'; m.STATE.write_text('{}\n'); m.LIVE_CONFIG_FILE = self.config
        m.BACKUPS = self.base/'backups'; m.PATCH_FILES=[]; m.R61_SYSTEMD_ROOT=self.units
        coordinator=self.root/(m.CORE+'permanent-coordinator.mjs');coordinator.parent.mkdir(parents=True);coordinator.write_text('// fixture\n')
        m.R61_INSTALL_FLAGS={**m.R61_INSTALL_FLAGS,m.R61_EAGER_FLAG:'1'}
        m.BOOL_FLAGS=(*m.BOOL_FLAGS,m.R61_EAGER_FLAG)
        m.INSTALL_FLAGS={**m.INSTALL_FLAGS,m.R61_EAGER_FLAG:'1'}
        m.RUNTIME_FLAGS={**m.RUNTIME_FLAGS,m.R61_EAGER_FLAG:'0'}
        self.loaded=None; self.reloads=0; self.extra=''; self.prefix=''; self.starts=0; self.fail_start=False
        state={'prior':{'changedUnits':[{'unit':self.unit,'file':str(self.managed),'sha256':m.digest(self.managed.read_bytes())}]}}
        self.live=SimpleNamespace(root=self.root,node=self.node,unit=self.unit,config_file=self.config,state=state,
                                  active_binding=lambda:None,maintenance=lambda revision:None,
                                  stop_services=lambda:None,same_database=lambda:None)
        def start(revision):
            self.starts+=1
            if self.fail_start:self.fail_start=False;raise m.Refused('injected_start_failure')
            m.startup_verify(self.live)
        self.live.start_services=start
        def prop(unit,field):
            self.assertEqual(unit,self.unit)
            if field=='LoadState':return 'loaded'
            if field=='NeedDaemonReload':return 'no'
            if field=='FragmentPath':return str(self.fragment)
            if field=='DropInPaths':return ' '.join(map(str,[self.managed,*([self.target] if self.loaded is not None else [])]))
            if field=='ExecStartEx':
                args=[str(self.node),str(self.entry)]
                if self.loaded and b'--no-lazy' in self.loaded:args.insert(1,'--no-lazy')
                if self.extra:args.insert(1,self.extra)
                return '{ path='+str(self.node)+' ; argv[]='+' '.join(args)+' ; flags='+self.prefix+' ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }'
            raise AssertionError(field)
        def command(args,timeout=20):
            self.assertEqual(args,['/usr/bin/systemctl','daemon-reload']);self.reloads+=1
            self.loaded=self.target.read_bytes() if self.target.exists() else None
            return ''
        m.prop=prop;m.command=command;m.install_lock=lambda:contextlib.nullcontext();m.scheduled_backup_lock=lambda live:contextlib.nullcontext()
        self.original_units={p.relative_to(self.units).as_posix():p.read_bytes() for p in self.units.rglob('*') if p.is_file()}

    def install(self):
        m=self.m
        updates={self.config:m.encoded({'environment':{m.R61_EAGER_FLAG:'1'}}),**m.startup_prepare(self.live,{'nodeStartup':adapter.POLICY})}
        self.directory,self.record=m.backup(self.root,updates,self.unit,1)
        for row in self.record['files']:m.apply_update(Path(row['file']),updates[Path(row['file'])],row)
        m.startup_reload(self.live);self.record['status']='installed';m.atomic(self.directory/'journal.json',m.encoded(self.record))
        return updates

    def test_exact_owned_launch_and_accounts_unchanged(self):
        self.install();self.assertIn(b'--no-lazy',self.target.read_bytes())
        for name,data in self.original_units.items():self.assertEqual((self.units/name).read_bytes(),data)
        self.m.startup_running(self.live,[str(self.node).encode(),b'--no-lazy',str(self.entry).encode(),b''])
        with self.assertRaisesRegex(self.m.Refused,'calisan_baslatma'):self.m.startup_running(self.live,[str(self.node).encode(),str(self.entry).encode()])

    def test_custom_arguments_and_executable_prefixes_refused(self):
        for extra,prefix in [('--trace-gc',''),('','ignore-failure'),('--no-lazy','')]:
            self.extra,self.prefix=extra,prefix
            with self.assertRaisesRegex(self.m.Refused,'ozel_ExecStart'):self.m.startup_prepare(self.live,{'nodeStartup':adapter.POLICY})
            self.assertFalse(self.target.exists());self.assertEqual(self.reloads,0)

    def test_pending_unloaded_unit_changes_refused(self):
        original=self.m.prop
        self.m.prop=lambda unit,field:'yes' if field=='NeedDaemonReload' else original(unit,field)
        with self.assertRaisesRegex(self.m.Refused,'bekleyen_degisim'):
            self.m.startup_prepare(self.live,{'nodeStartup':adapter.POLICY})
        self.assertFalse(self.target.exists());self.assertEqual(self.reloads,0)

    def test_unowned_or_modified_dropins_refused(self):
        before=self.managed.read_bytes();self.managed.write_bytes(before+b'# changed\n')
        with self.assertRaisesRegex(self.m.Refused,'yonetilen_servis_degisti'):self.m.startup_prepare(self.live,{'nodeStartup':adapter.POLICY})
        self.managed.write_bytes(before);self.target.write_bytes(b'# not owned\n')
        with self.assertRaisesRegex(self.m.Refused,'dropin_zaten_var'):self.m.startup_prepare(self.live,{'nodeStartup':adapter.POLICY})
        self.assertEqual(self.target.read_bytes(),b'# not owned\n')

    def test_flag_off_on_and_current_config_restore(self):
        self.install();m=self.m
        for value in ['0','1']:
            m.set_flags(self.live,[m.R61_EAGER_FLAG+'='+value],1,None,{})
            self.assertEqual(b'--no-lazy' in self.target.read_bytes(),value=='1')
        record=m.read_json(self.directory/'journal.json');m.restore(self.directory,record,validate_only=True);m.restore(self.directory,record);m.startup_reload(self.live)
        self.assertFalse(self.target.exists());self.assertIsNone(self.loaded);self.assertEqual(m.read_json(self.config),{'environment':{}})
        self.assertGreaterEqual(self.reloads,4)

    def test_failed_flag_start_restores_previous_launch_and_config(self):
        self.install();before=self.target.read_bytes();config=self.config.read_bytes();self.fail_start=True
        with self.assertRaisesRegex(self.m.Refused,'injected_start_failure'):
            self.m.set_flags(self.live,[self.m.R61_EAGER_FLAG+'=0'],1,None,{})
        self.assertEqual(self.target.read_bytes(),before);self.assertEqual(self.config.read_bytes(),config);self.assertEqual(self.loaded,before)
        record=self.m.read_json(self.directory/'journal.json');self.assertNotIn('approvedStartupHashes',record)
        self.m.restore(self.directory,record,validate_only=True)

    def test_modified_installed_dropin_blocks_rollback_without_overwrite(self):
        self.install();self.target.write_bytes(b'# external edit\n')
        with self.assertRaisesRegex(self.m.Refused,'geri_donus_dosyasi_disaridan_degisti'):
            self.m.restore(self.directory,self.record,validate_only=True)
        self.assertEqual(self.target.read_bytes(),b'# external edit\n')

    def test_replaced_dropin_parent_blocks_restore(self):
        self.install();real=self.units/'moved';self.dropins.rename(real);self.dropins.symlink_to(real,target_is_directory=True)
        with self.assertRaisesRegex(self.m.Refused,'servis_dizini_sahibi'):
            self.m.restore(self.directory,self.record,validate_only=True)
        self.assertTrue((real/self.target.name).exists())

    def test_interrupted_flag_write_remains_reversible(self):
        self.install();m=self.m;record=m.read_json(self.directory/'journal.json')
        next_config={'environment':{m.R61_EAGER_FLAG:'0'}}
        target,row,before,after=m.startup_flag_change(self.live,record,next_config)
        config_before=self.config.read_bytes();config_after=m.encoded(next_config)
        record['approvedConfigHashes']=[m.digest(config_before),m.digest(config_after)]
        m.atomic(self.directory/'journal.json',m.encoded(record));m.atomic(self.config,config_after)
        # Simulate process death after config write and before drop-in write.
        m.restore(self.directory,record,validate_only=True);m.restore(self.directory,record);m.startup_reload(self.live)
        self.assertFalse(target.exists());self.assertEqual(m.read_json(self.config),{'environment':{}})

if __name__=='__main__':unittest.main(verbosity=2)
