"""Real ZIP/Node/SQLite/filesystem roundtrip; only root and services simulated.

Run under the pinned setup fakeroot. No /opt,/var/lib or real service is used.
The starting HTTP fixture was reconstructed with the original SHA-pinned
verifiers; its omitted native media limits this test, as in the R55 evidence.
"""
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
import contextlib,hashlib,importlib.util,io,json,os,re,shutil,sqlite3,stat,sys,tempfile,unittest,zipfile
R=Path(__file__).resolve().parents[1];B=R.parent/'r55_gameplay_work';E=R/'evidence-r61'
def module(name,path):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
m=module('r61_installer_test',R/'package-r61/__main__.py');old=module('r55_installer_fixture',B/'package/__main__.py')
sha=lambda b:hashlib.sha256(b).hexdigest()
def copy_links(a,b):
 seen={}
 def copy(source,dest):
  s=os.stat(source);k=(s.st_dev,s.st_ino)
  if k in seen:os.link(seen[k],dest)
  else:shutil.copy2(source,dest);seen[k]=dest
  return dest
 shutil.copytree(a,b,copy_function=copy,symlinks=True)
class Installer(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='r61-installer-');self.addCleanup(self.tmp.cleanup);self.dir=Path(self.tmp.name);self.root=self.dir/'release'
  cache=B/'fixture-cache-r54';copy_links(cache/'release',self.root)
  self.state=self.dir/'state.json';self.config_file=self.dir/'config.json';self.db=self.dir/'game.sqlite';self.node=R/'tooling/node-v22.22.0-linux-x64/bin/node'
  for name in ('state.json','config.json','game.sqlite'):shutil.copyfile(cache/name,self.dir/name)
  shutil.copyfile(R.parent/'r59_castle_work/evidence-r59/installer-native-v2.sqlite',self.db)
  c=json.loads(self.config_file.read_bytes());c['database']=str(self.db);self.config_file.write_bytes(m.encoded(c))
  shutil.copyfile(B/'input/CORE511_R46.zip',self.dir/'CORE511_R46.zip')
  self.archive=self.dir/'CORE511_R61_AUDIO.zip';shutil.copyfile(R/'candidate/CORE511_R61_AUDIO_TEST.zip',self.archive)
  with zipfile.ZipFile(self.archive) as z:self.spec=json.loads(z.read('patch.json'))
  daily=self.dir/'backups';daily.mkdir(mode=0o700);(daily/'daily.sqlite').write_bytes(b'preserve daily backup')
  self.backups=self.dir/'r61-audio-backups';self.actions=[];self.fail_start=False;self.enabled=True;self.checks={};outer=self
  self.dbbytes=self.db.read_bytes();self.dbst=self.db.stat()
  self.systemd=self.dir/'systemd';self.systemd.mkdir(mode=0o755)
  self.unit_dir=self.systemd/'coreoflife-r1.service.d';self.unit_dir.mkdir(mode=0o755)
  self.fragment=self.systemd/'coreoflife-r1.service';self.fragment.write_text('[Service]\nExecStart=/usr/bin/node original.mjs\nUser=col-r1\n')
  self.managed=self.unit_dir/'90-core511.conf';self.managed.write_text('[Service]\nExecStart=\nExecStart='+str(self.node)+' '+str(self.root/(m.DELIVERY+'runtime-entry.mjs'))+'\nWorkingDirectory='+str(self.root)+'\nMemoryMax=3G\n')
  self.managed_sha=sha(self.managed.read_bytes())
  self.startup=self.unit_dir/'91-core511-r61-eager.conf';self.loaded_startup=None;self.reloads=[];self.custom_exec_args='';self.exec_prefix=''
  self.accounts_unit_file=self.systemd/'coreoflife-accounts.service';self.accounts_unit_file.write_text('[Service]\nExecStart=/unchanged/accounts\n')
  def fake_prop(unit,field):
   if field=='ActiveState':return 'active'
   outer.assertEqual(unit,'coreoflife-r1.service')
   if field=='LoadState':return 'loaded'
   if field=='NeedDaemonReload':return 'no'
   if field=='FragmentPath':return str(outer.fragment)
   if field=='DropInPaths':return ' '.join(str(p) for p in [outer.managed,*([outer.startup] if outer.loaded_startup is not None else [])])
   if field=='ExecStartEx':
    args=[str(outer.node),str(outer.root/(m.DELIVERY+'runtime-entry.mjs'))]
    if outer.loaded_startup and b'--no-lazy' in outer.loaded_startup:args.insert(1,'--no-lazy')
    if outer.custom_exec_args:args.insert(1,outer.custom_exec_args)
    return '{ path='+str(outer.node)+' ; argv[]='+' '.join(args)+' ; flags='+outer.exec_prefix+' ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }'
   raise AssertionError(field)
  original_command=m.command
  def fake_command(args,timeout=20):
   if args and args[0]=='/usr/bin/systemctl':
    outer.assertEqual(args,['/usr/bin/systemctl','daemon-reload']);outer.reloads.append('reload');outer.loaded_startup=outer.startup.read_bytes() if outer.startup.exists() else None;return ''
   return original_command(args,timeout)
  for name,value in [('R61_SYSTEMD_ROOT',self.systemd),('prop',fake_prop),('command',fake_command)]:
   patcher=patch.object(m,name,value);patcher.start();self.addCleanup(patcher.stop)
  class Live:
   def __init__(live):
    live.root=outer.root;live.state=json.loads(outer.state.read_bytes());live.config_file=outer.config_file;live.config=json.loads(outer.config_file.read_bytes());live.database=outer.db;live.node=outer.node;live.unit='coreoflife-r1.service';live.accounts_unit='coreoflife-accounts.service'
    live.state.setdefault('prior',{})['changedUnits']=[{'unit':live.unit,'file':str(outer.managed),'sha256':outer.managed_sha}]
   def active_binding(live,**kwargs):pass
   def maintenance(live,revision=None):m.require(outer.enabled,'maintenance_required');live.same_database();return 119
   def same_database(live):
    outer.assertEqual(outer.db.stat().st_ino,outer.dbst.st_ino)
   def stop_services(live):outer.actions.append('stop')
   def start_services(live,revision):
    outer.actions.append('start');outer.assertEqual(revision,119);live.same_database()
    if outer.fail_start:outer.fail_start=False;raise m.Refused('injected_health_failure')
    m.startup_verify(live)
   def ready(live,revision):live.same_database()
   def central(live,revision):outer.assertEqual(revision,119)
   def empty(live):pass
  self.Live=Live
  for name,value in [('STATE',self.state),('BACKUPS',self.backups),('Live',Live)]:
   p=patch.object(m,name,value);p.start();self.addCleanup(p.stop)
 def run_main(self,*args):
  out=io.StringIO()
  try:
   with patch.object(sys,'argv',[str(self.archive),*args]),contextlib.redirect_stdout(out),contextlib.redirect_stderr(out):m.main()
  finally:
   with (E/'installer-r61.log').open('a') as f:f.write('\n$ '+' '.join(args)+'\n'+out.getvalue())
  return out.getvalue()
 def snapshot(self):
  result={p.relative_to(self.root).as_posix():sha(p.read_bytes()) for p in self.root.rglob('*') if p.is_file() and not p.is_symlink() and 'node_modules' not in p.parts}
  result['__state']=sha(self.state.read_bytes());result['__config']=sha(self.config_file.read_bytes())
  result['__unit_files']={p.relative_to(self.systemd).as_posix():sha(p.read_bytes()) for p in self.systemd.rglob('*') if p.is_file()}
  return result
 def build_r56_fixture(self):
  cache=R/'fixture-cache-r60'
  ready=(cache/'ready.json').exists()
  base=cache if ready else R.parent/'r60_mount_work/fixture-cache-r59'
  shutil.rmtree(self.root);copy_links(base/'release',self.root)
  for name in ('state.json','config.json'):shutil.copyfile(base/name,self.dir/name)
  config=json.loads(self.config_file.read_bytes());config['database']=str(self.db);self.config_file.write_bytes(m.encoded(config))
  if ready:return
  ref=module('r60_reference_fixture',R.parent/'r60_mount_work/package-r60/__main__.py')
  with zipfile.ZipFile(R.parent/'r60_mount_work/candidate/CORE511_R60_MOUNTS.zip') as z:
   spec=json.loads(z.read('patch.json'));live=self.Live()
   with patch.object(ref,'STATE',self.state),patch.object(ref,'PATCH_FILES',[r['path'] for r in spec['changes']]),patch.object(ref,'BASE_ARCHIVE',str(self.dir/'CORE511_R46.zip')):
    runtime=ref.runtime_activation(live,z,spec);selected=ref.select_base(live,spec,runtime);updates=ref.prepare(live,z,selected)
    default=ref.regular(self.root/(ref.CORE+'permanent-coordinator.mjs'))
    for file,data in updates.items():
     st=ref.regular(file,allow_hardlinks=True) if file.exists() else default
     file.parent.mkdir(parents=True,exist_ok=True);ref.apply_update(file,data,{'mode':stat.S_IMODE(st.st_mode),'uid':st.st_uid,'gid':st.st_gid})
    ref.verify_installed(live,selected)
  cache.mkdir(exist_ok=True);copy_links(self.root,cache/'release')
  for name in ('state.json','config.json'):shutil.copyfile(self.dir/name,cache/name)
  (cache/'ready.json').write_text('{}')
 def test_roundtrip_failure_recovery_flags_and_current_database(self):
  startup_tests=module('r61_startup_safety',R/'tests-r61/eager-startup-test.py');self.assertFalse(startup_tests.ADAPTED_IN_MEMORY)
  result=unittest.TestResult();unittest.defaultTestLoader.loadTestsFromTestCase(startup_tests.Startup).run(result);self.assertTrue(result.wasSuccessful(),str(result.errors+result.failures));self.assertEqual(result.testsRun,9);self.checks['startupSafetyUnitTests']=True
  # R54 is not silently promoted by the embedded read-only R55 verifier.
  with self.assertRaisesRegex(Exception,'R61_kurulu_istemci_kaniti'):self.run_main('--check')
  self.assertEqual(self.actions,[]);self.checks['r54RefusedWithoutWrites']=True
  self.build_r56_fixture();(E/'installer-index-before.js').write_bytes((self.root/m.HTTP_ROOT/'server/index.js').read_bytes());before=self.snapshot();config_before=self.config_file.read_bytes();db_inode=self.db.stat().st_ino
  http={p.relative_to(self.root).as_posix():(sha(p.read_bytes()),p.stat().st_ino) for p in (self.root/m.HTTP_ASSETS/self.spec['runtimeActivation']['baselineNamespace']).rglob('*') if p.is_file()}
  self.assertIn('"taban": "R60"',self.run_main('--check'));self.assertEqual(self.snapshot(),before);self.assertEqual(self.actions,[]);self.checks['checkReadOnly']=True
  self.assertEqual(self.reloads,[])
  self.custom_exec_args='--trace-gc'
  with self.assertRaisesRegex(Exception,'R61_ozel_ExecStart'):self.run_main('--check')
  self.custom_exec_args='';self.exec_prefix='ignore-failure'
  with self.assertRaisesRegex(Exception,'R61_ozel_ExecStart'):self.run_main('--check')
  self.exec_prefix='';self.assertEqual(self.snapshot(),before);self.assertEqual(self.actions,[]);self.checks['customExecStartAndPrefixesRefusedWithoutWrites']=True
  self.enabled=False
  with self.assertRaisesRegex(Exception,'maintenance_required'):self.run_main('--apply')
  self.enabled=True;self.assertEqual(self.actions,[]);self.checks['maintenanceRequired']=True
  drift=self.root/(m.CORE+'channel-runtime.mjs');saved=drift.read_bytes();drift.write_bytes(saved+b'\n// unauthorized\n')
  with self.assertRaisesRegex(Exception,'kod_dogrulanmis_R60'):self.run_main('--apply')
  drift.write_bytes(saved);self.assertEqual(self.actions,[]);self.checks['sourceTamperRefusedBeforeStop']=True
  with zipfile.ZipFile(self.archive) as z:entries={n:z.read(n) for n in z.namelist()}
  changed=next('payload/'+r['path'] for r in self.spec['changes'] if r['beforeByBase']['R60'] is not None)
  with zipfile.ZipFile(self.archive,'w',zipfile.ZIP_DEFLATED) as z:
   for n,b in entries.items():z.writestr(n,b+b'\n// corrupt\n' if n==changed else b)
  with self.assertRaisesRegex(Exception,'paket_dosyasi_bozuk|R61_istemci_kaniti_SHA256'):self.run_main('--apply')
  shutil.copyfile(R/'candidate/CORE511_R61_AUDIO_TEST.zip',self.archive);self.assertEqual(self.actions,[]);self.checks['payloadTamperRefusedBeforeStop']=True
  self.fail_start=True
  with self.assertRaisesRegex(Exception,'injected_health_failure'):self.run_main('--apply')
  self.assertEqual(self.snapshot(),before);self.assertIsNone(self.loaded_startup);self.assertGreaterEqual(len(self.reloads),2);self.actions.clear();self.checks['automaticRollbackOnFailedHealth']=True
  self.checks['startupAutomaticRollbackOnFailedHealth']=True
  self.run_main('--apply');self.assertEqual(self.actions,['stop','start']);self.actions.clear();self.checks['applyWithRealNodeManifestVerification']=True
  with contextlib.closing(sqlite3.connect(self.db)) as db:
   db.execute("INSERT INTO mount_receipts_r49 VALUES('system:r61-material-migration','v1','bootstrap','{}',1)");db.commit()
  installed=self.snapshot();self.run_main('--check');self.run_main('--apply');self.assertEqual(self.snapshot(),installed);self.assertEqual(self.actions,[]);self.checks['repeatedApplyIdempotent']=True
  for v in ('0','1'):
   self.run_main(*sum((['--set-flag',key+'='+v] for key in self.spec['newFlags']),[]))
   self.assertEqual(b'--no-lazy' in self.startup.read_bytes(),v=='1')
  self.checks['allNewFlagsOffAndOn']=True
  self.assertIn(b'--no-lazy',self.startup.read_bytes());self.assertEqual(sha(self.managed.read_bytes()),self.managed_sha)
  self.checks['eagerStartupFlagOffAndOnWithDaemonReload']=len(self.reloads)>=4
  self.checks['managedLaunchAndAccountsUnitUnchanged']=self.snapshot()['__unit_files']['coreoflife-accounts.service']==before['__unit_files']['coreoflife-accounts.service']
  # Restore the selected experimental-zero settings before the final --check.
  self.run_main(*sum((['--set-flag',k+'='+v] for k,v in self.spec['flags'].items() if k in self.spec['newFlags']),[]))
  prior_env=json.loads(config_before)['environment'];env=json.loads(self.config_file.read_bytes())['environment'];self.assertTrue(all(env[k]==v for k,v in prior_env.items() if k not in self.spec['newFlags']))
  self.assertEqual({p.relative_to(self.root).as_posix():(sha(p.read_bytes()),p.stat().st_ino) for p in (self.root/m.HTTP_ASSETS/self.spec['runtimeActivation']['baselineNamespace']).rglob('*') if p.is_file()},http);self.checks['oldClientNamespaceBytesAndInodesUnchanged']=True
  asset=next(p for p in (self.root/m.HTTP_ASSETS).rglob('*.js'));saved=asset.read_bytes();asset.write_bytes(saved+b'\n// tamper\n')
  with self.assertRaises(Exception):self.run_main('--check')
  asset.write_bytes(saved);self.checks['immutableClientTamperRefused']=True
  with contextlib.closing(sqlite3.connect(self.db)) as db:
   with db:
    db.execute("INSERT INTO dungeon_materials VALUES('real-1','saddle_leather',109)")
    db.execute("UPDATE players SET gems=gems+5555,area='guild_castle',channel=4,hp=0 WHERE id='real-1'")
    db.execute("INSERT INTO castle_entries_r59 VALUES('real-1',1,1)")
    db.execute("INSERT INTO castle_chests_r59 VALUES('2026-10-25','real-1','{\"ok\":true}',1)")
  self.dbbytes=self.db.read_bytes();self.dbst=self.db.stat()
  with contextlib.closing(sqlite3.connect(self.db)) as db: earned=db.execute("SELECT gems FROM players WHERE id='real-1'").fetchone()[0]
  self.run_main('--rollback-latest','--base-package',str(self.dir/'absent.zip'))
  self.assertFalse(self.startup.exists());self.assertIsNone(self.loaded_startup);self.checks['startupDropInRemovedAndManagerRestored']=True
  self.assertEqual(self.snapshot(),before);self.assertEqual(self.db.stat().st_ino,db_inode)
  with contextlib.closing(sqlite3.connect(self.db)) as db:
   self.assertEqual(db.execute('PRAGMA quick_check').fetchone()[0],'ok');self.assertEqual(db.execute("SELECT gems FROM players WHERE id='real-1'").fetchone()[0],earned)
   self.assertEqual(db.execute("SELECT area,hp=max_hp FROM players WHERE id='real-1'").fetchone(),('guild_castle',0))
   self.assertEqual(db.execute("SELECT count(*) FROM castle_chests_r59 WHERE player_id='real-1'").fetchone()[0],1)
   self.assertEqual(db.execute("SELECT count(*) FROM castle_entries_r59").fetchone()[0],1)
  self.assertEqual(self.db.read_bytes(),self.dbbytes)
  with contextlib.closing(sqlite3.connect(self.db)) as db:
   self.assertEqual(db.execute("SELECT amount FROM dungeon_materials WHERE player_id='real-1' AND kind='saddle_leather'").fetchone()[0],109)
  self.checks['castleAndCurrentMaterialBalancesPreserved']=True
  self.checks['rollbackRetainsCurrentDbAndNewData']=True;self.checks['rollbackDoesNotNeedProofArchive']=True
  self.assertEqual((self.dir/'backups/daily.sqlite').read_bytes(),b'preserve daily backup');self.checks['dailyBackupPreserved']=True
  self.assertFalse(list(self.backups.glob('*/game.sqlite')));self.checks['ownTemporaryDbBackupCleaned']=True
  (E/'installer-r61.json').write_bytes(m.encoded({'status':'PASS','afterCore':self.spec['afterCore'],'installerSha256':sha((R/'package-r61/__main__.py').read_bytes()),'installerTestSha256':sha(Path(__file__).read_bytes()),'startupTestSha256':sha((R/'tests-r61/eager-startup-test.py').read_bytes()),'testArchiveSha256':sha((R/'candidate/CORE511_R61_AUDIO_TEST.zip').read_bytes()),'checks':self.checks,'serviceHealthMocked':True,'rootSimulatedByFakeroot':True,'actualZipNodeSQLiteBackupAndRollback':True,'nativeMediaOmittedFromFixture':True,'liveDeployment':False}))
if __name__=='__main__':unittest.main(verbosity=2)
