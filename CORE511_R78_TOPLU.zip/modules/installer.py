"""R78: unnecessary market/reward freezes and focused server timing overhead corrections."""
import argparse,contextlib,hashlib,json,os,re,sqlite3,stat,subprocess,sys,time,zipfile
from pathlib import Path
import r63_support as old
from storage import atomic,clone_release,descriptor,digest,encoded,journal,lock,member,overlay,read,release_stats,require,sync_dir

STATE=Path('/var/lib/core511/state.json')
ROOT=Path('/var/lib/core511/r64-updates')
ACTIVE=ROOT/'active.json'
SYSTEMD=Path('/etc/systemd/system')
RELEASES=Path('/opt/core511/releases')
RESET_ACTIVE=Path('/var/lib/core511/launch-reset-r63/active.json')
SELF=Path(__file__).resolve().parent
VERSION='R78_GAMEPLAY'
NATIVE_TIMING='native510-bb3a6cc689c6/vds-server/src/writer-sql-timing477.mjs'
def say(message):print(message,flush=True)
def command(args,timeout=90):
 result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=timeout)
 require(result.returncode==0,'Komut tamamlanamadı: '+Path(args[0]).name)
 return result.stdout.strip()
def prop(unit,field):return command(['/usr/bin/systemctl','show',unit,'--property='+field,'--value'])
def service(unit,action):
 require(unit!='coreoflife-accounts.service' and re.fullmatch(r'coreoflife-(r\d+|rt-r\d+)\.service',unit),'Hesap servisi bu kurucuda durdurulamaz')
 return command(['/usr/bin/systemctl',action,unit])
def reload_units():command(['/usr/bin/systemctl','daemon-reload'])
def unit_path(unit):return SYSTEMD/(unit+'.d')/'92-core511-r64.conf'
def guard_path(unit):return SYSTEMD/(unit+'.d')/'96-core511-r64-guard.conf'
def file_record(file):
 file=Path(file)
 if not file.exists():return {'path':str(file),'exists':False}
 s=file.lstat();require(stat.S_ISREG(s.st_mode) and not file.is_symlink(),'Yedeklenecek dosya geçersiz')
 return {'path':str(file),'exists':True,'data':file.read_bytes().hex(),'sha256':digest(file),'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid}
def restore_file(saved):
 file=Path(saved['path'])
 if saved['exists']:atomic(file,bytes.fromhex(saved['data']),saved['mode'],(saved['uid'],saved['gid']))
 elif file.exists():file.unlink();sync_dir(file.parent)
def saved_matches(saved):
 p=Path(saved['path'])
 return p.is_file() and digest(p)==saved['sha256'] if saved['exists'] else not p.exists()
def write_record(directory,record,phase):
 record['phase']=phase;journal(directory/'journal.json',record);journal(ACTIVE,{'directory':str(directory),'phase':phase})
def clear_active():
 ACTIVE.unlink(missing_ok=True);sync_dir(ROOT)
def guards(record,enable):
 body=('[Unit]\nConditionPathExists=!'+str(ACTIVE)+'\n').encode()
 for unit in record['units']:
  p=guard_path(unit)
  if p.exists():require(p.read_bytes()==body,'Başka kurulum koruması bulundu')
  if enable:atomic(p,body,0o644)
  elif p.exists():p.unlink();sync_dir(p.parent)
 reload_units()
def process_identity(pid):
 raw=Path('/proc',str(pid),'stat').read_text()
 return {'pid':pid,'start':raw.rsplit(')',1)[1].split()[19]}

class Live:
 def __init__(self):
  self.state=read(STATE);require(self.state.get('installed') is True,'Kurulu oyun bulunamadı')
  self.root=Path(self.state['releaseRoot']).resolve();require(self.root.parent==RELEASES,'Sürüm dizini kapsamı geçersiz')
  prior=self.state['prior'];self.unit=prior['gameUnit'];self.accounts_unit=prior['accountsUnit']
  require(self.accounts_unit=='coreoflife-accounts.service' and re.fullmatch(r'coreoflife-r\d+\.service',self.unit),'Servis kapsamı geçersiz')
  self.config_file=Path(prior['newGameConfigFile']).resolve();self.config=read(self.config_file)
  self.accounts_file=Path(prior.get('newAccountsConfigFile') or prior['accountsConfigFile']).resolve();self.accounts_config=read(self.accounts_file)
  self.database=Path(self.config['database']).resolve();self.accounts_database=Path(self.accounts_config['database']).resolve()
  require(str(self.root)==self.config['delivery511']['releaseRoot'] and self.database==Path(prior['database']).resolve(),'Oyun yapılandırması eşleşmiyor')
  self.realm=self.config['realm']['id'];self.manifest=read(self.config['realm']['manifestFile'])
  require(self.realm==self.manifest['primaryRealmId'],'Yalnız birincil sunucu destekleniyor')
  require(self.accounts_database==Path(self.manifest['accountsDatabase']).resolve(),'Hesap veritabanı eşleşmiyor')
  require(self.database==Path(next(r['database'] for r in self.manifest['realms'] if r['id']==self.realm)).resolve(),'Sunucu veritabanı eşleşmiyor')
  self.db_identity=descriptor(self.database);self.account_db_identity=descriptor(self.accounts_database)
  expected=prior['databaseIdentity'];require((self.db_identity['device'],self.db_identity['inode'])==(expected['dev'],expected['ino']),'Oyun veritabanı kimliği değişmiş')
  self.accounts_root=Path(self.state.get('r64Deployment',{}).get('accountsRoot',self.root)).resolve()
  require(self.accounts_root.parent==RELEASES,'Hesap sürüm dizini geçersiz')
  self.port=self.config['delivery511']['appPort'];self.node=self.root/'bin/node'
  self.rt_unit='coreoflife-rt-'+self.realm+'.service'
 def accounts_identity(self):
  require(prop(self.accounts_unit,'ActiveState')=='active','Kayıt servisi çalışmıyor')
  pid=int(prop(self.accounts_unit,'MainPID'));require(pid>1,'Hesap servisi PID geçersiz');process=process_identity(pid)
  argv=Path('/proc',str(pid),'cmdline').read_bytes().split(b'\0')
  require(str(self.accounts_root/'core511-source/scripts/delivery511/generated/accounts-entry.mjs').encode() in argv,'Hesap servisi kaynak sürümü eşleşmiyor')
  env=dict(x.split(b'=',1) for x in Path('/proc',str(pid),'environ').read_bytes().split(b'\0') if b'=' in x)
  require(env.get(b'CORE_CONFIG_FILE')==str(self.accounts_file).encode(),'Hesap servisi yapılandırma yolu değişmiş')
  require(process_identity(pid)==process,'Hesap servisi kontrol sırasında değişti')
  unit_files=[prop(self.accounts_unit,'FragmentPath'),*prop(self.accounts_unit,'DropInPaths').split()]
  return {**process,'root':str(self.accounts_root),'configSHA256':digest(self.accounts_file),
          'database':descriptor(self.accounts_database),'unitFiles':{p:digest(p) for p in unit_files if p}}
 def account_stable(self,expected):require(self.accounts_identity()==expected,'Hesap servisi kimliği değişti; yeni kayıtlara dokunulmadı')
 def active_binding(self):
  require(prop(self.unit,'ActiveState')=='active','Oyun servisi çalışıyor olmalı')
  pid=int(prop(self.unit,'MainPID'));require(pid>1,'Oyun PID geçersiz')
  args=Path('/proc',str(pid),'cmdline').read_bytes().split(b'\0')
  entry=self.root/'core511-source/scripts/delivery511/runtime-entry.mjs'
  require(str(entry).encode() in args,'Çalışan oyun sürümü uyuşmuyor')
  env=dict(x.split(b'=',1) for x in Path('/proc',str(pid),'environ').read_bytes().split(b'\0') if b'=' in x)
  require(env.get(b'CORE_CONFIG_FILE')==str(self.config_file).encode(),'Çalışan oyun ayarı uyuşmuyor')
  if 'r64Deployment' in self.state:
   require(unit_path(self.unit).is_file() and digest(unit_path(self.unit))==self.state['r64Deployment']['dropinSHA256'],'R64 başlatma dosyası değişmiş')
  else:old.startup_verify(self)
  require(descriptor(self.database)==self.db_identity,'Oyun veritabanı değişmiş')
 def central(self,operation='snapshot',expected=None):
  raw=command([str(self.accounts_root/'bin/node'),str(SELF/'central.mjs'),str(self.accounts_root),str(self.config_file),str(self.accounts_file),operation,json.dumps(expected) if expected else ''],timeout=30)
  return json.loads(raw)
 def empty(self):
  with contextlib.closing(sqlite3.connect(self.database.as_uri()+'?mode=ro',uri=True,timeout=5)) as db:
   counts=[db.execute('SELECT COUNT(*) FROM game_presence WHERE expires_at_ms>?',(int(time.time()*1000),)).fetchone()[0],db.execute('SELECT COUNT(*) FROM players WHERE last_seen>?',(int(time.time())-40,)).fetchone()[0],db.execute('SELECT COUNT(*) FROM kernel511_admissions').fetchone()[0]]
  require(counts==[0,0,0],'Oyuncu veya admin oyunda. Çıkıp 45 saniye bekleyin.')
 def health(self,empty=True):
  h=old.local(self.port,'/api/vds-health');rows=h.get('channelProcesses',{}).get('channels',[])
  require(h.get('kernel511',{}).get('ready') is True and h.get('durable') is True and h.get('realm',{}).get('dbIdentity')==self.config['realm']['dbIdentity'],'Oyun sağlık kontrolü başarısız')
  require(len(rows)==4 and all(r.get('channel')==i+1 and r.get('ready') is True and r.get('capacity')==25 and (not empty or r.get('online')==0) for i,r in enumerate(rows)),'Dört kanal hazır değil')
  if empty:self.empty()
 def ready(self,record):
  deadline=time.monotonic()+90;last=0
  while time.monotonic()<deadline:
   self.account_stable(record['accounts'])
   try:self.health();self.active_binding();return
   except (OSError,RuntimeError,ValueError):
    if time.monotonic()-last>5:say('Oyun kanalları hazırlanıyor; ön kayıt servisi açık.');last=time.monotonic()
    time.sleep(.5)
  raise RuntimeError('Dört kanalın açılması tamamlanamadı')

def allowed_policy(p):
 if p['phase']=='maintenance':return p['mode']=='maintenance' and p['deadlineMs']<=int(time.time()*1000)
 return p['phase']=='waiting' and p['mode'] in ('closed','scheduled') and p['enabled']==1 and p['registrationOpen'] is True
def same_policy(a,b):return all(a[k]==b[k] for k in ('phase','mode','enabled','revision'))
def assert_frame(live,record,held=True):
 live.account_stable(record['accounts']);current=live.central()
 require(same_policy(current,record['policy']),'Oyun durumu kurulum sırasında değişti')
 expected={**record['policy']['realm'],'status':'maintenance'} if held else record['policy']['realm']
 require(current['realm']==expected,'Sunucu giriş ayarı kurulum sırasında değişti')
 require(descriptor(live.database)==record['database'],'Oyun veritabanı kimliği değişmiş')
 return current
def verify_release(root,expected_core):
 require(old.core_identity(root/old.CORE)==expected_core,'Oyun kaynak kimliği eşleşmiyor')
 manifest=read(root/'release-manifest.json');require(manifest.get('runtimeSha256')==expected_core,'Sürüm manifest kimliği eşleşmiyor')
 script="import{pathToFileURL}from'node:url';const r=process.argv[1];const{verifyPackage}=await import(pathToFileURL(r+'/core511-source/scripts/delivery511/install-operations.mjs'));verifyPackage(r);"
 say('Sürüm dosyaları doğrulanıyor; ön kayıt servisi çalışmaya devam ediyor.')
 old.verify_command([str(root/'bin/node'),'--input-type=module','-e',script,str(root)],old.verification_budget(manifest))
def initial_core(live,plan):
 require(plan['version']==VERSION,'Paket sürümü geçersiz')
 installed=live.state.get('r64Deployment',{}).get('version')
 require(installed in ('R77_GAMEPLAY',VERSION),'Bu güncelleme kurulu R77 üzerine uygulanır')
 manifest=read(live.root/'release-manifest.json')
 require(manifest.get('baselineSha256')==plan['nativeBaseline'],'Oyun tabanı farklı')
 rows={r['path']:dict(r) for r in plan['baseCoreRows']}
 require(len(rows)==len(plan['baseCoreRows']) and old.identity_from_rows(rows.values())==plan['baseCoreSHA256'],'Paket kaynak listesi bozuk')
 # The historical source-only export omitted exactly this benchmark C file.
 # Preserve only its verified live manifest row; do not waive any game source.
 extra_name=old.CORE+'benchmark/no-network.c'
 extras=[r for r in manifest['files'] if r['path']==extra_name]
 require(len(extras)<=1,'Tekrarlanan kaynak kaydı')
 extra=member(live.root,extra_name)
 if extras:
  row=extras[0];require(extra.is_file() and not extra.is_symlink() and extra.stat().st_size==row['bytes'] and digest(extra)==row['sha256'],'Benchmark kaynak kaydı değişmiş')
  rows['benchmark/no-network.c']={**row,'path':'benchmark/no-network.c'}
 else:require(not extra.exists(),'Manifest dışı benchmark kaynağı var')
 before=old.identity_from_rows(rows.values())
 after_rows=dict(rows)
 for name,meta in plan['files'].items():
  if name.startswith(old.CORE):
   short=name[len(old.CORE):];after_rows[short]={'path':short,'bytes':meta['bytes'],'sha256':meta['after']}
 after=old.identity_from_rows(after_rows.values())
 expected=after if installed==VERSION else before
 require(live.state.get('candidate')==expected and manifest.get('runtimeSha256')==expected and old.core_identity(live.root/old.CORE)==expected,'Kurulu oyun doğrulanmış R77/R78 kaynaklarıyla eşleşmiyor')
 entry=member(live.root,'http-runtime/dist-vds/server/index.js')
 require(digest(entry)==plan['httpEntrySHA256'],'Kurulu HTTP oyun dosyası farklı')
 for name,meta in plan['files'].items():
  require(name.startswith(old.CORE) or name==NATIVE_TIMING,'R78 sunucu dosya kapsamı farklı')
  if name==NATIVE_TIMING:
   require(meta['before']=='0d6eddf2dfad5f04da6b9f7153b76126a6bbf5627ead18f80cf3c5ed4adbf240','SQL ölçüm başlangıç kimliği farklı')
   require(digest(member(live.root,name))==meta['after' if installed==VERSION else 'before'],'Kurulu SQL ölçüm dosyası farklı')
 ops=member(live.root,old.OPS).read_text()
 match=re.search(r"export const CANDIDATE='([0-9a-f]{64})';",ops)
 require(match is not None and match[1]==expected,'Kurucu kaynak kimliği farklı')
 canonical=ops.replace(match[0],"export const CANDIDATE='R66_BASE_CORE';")
 require(hashlib.sha256(canonical.encode()).hexdigest()==plan['operationsCanonicalSHA256'],'Kurucu kaynak dosyası değişmiş')
 plan['targetCore']=after
 return expected

def prepare_updates(live,plan,updates):
 """Bind metadata to the already verified live release, including its C file."""
 for name,meta,data in updates:
  p=member(live.root,name)
  require(not p.is_symlink() and (digest(p) if p.exists() else None)==meta['before'],'Paket başlangıç dosyası değişmiş: '+name)
 manifest=read(live.root/'release-manifest.json');by_name={r['path']:r for r in manifest['files']}
 require(len(by_name)==len(manifest['files']),'Tekrarlanan manifest dosyası')
 require(plan.get('clientChanges') is False,'R78 istemci kapsamı farklı')
 result=list(updates)
 operations=member(live.root,old.OPS);source=operations.read_text()
 replacement=re.sub(r"export const CANDIDATE='[0-9a-f]{64}';","export const CANDIDATE='"+plan['targetCore']+"';",source,count=1).encode()
 result.append((old.OPS,{'before':digest(operations),'after':hashlib.sha256(replacement).hexdigest(),'bytes':len(replacement)},replacement))
 for name,meta,data in result:by_name[name]={**by_name.get(name,{}),'path':name,'bytes':len(data),'sha256':meta['after']}
 manifest['files']=[by_name[n] for n in sorted(by_name)];manifest['runtimeSha256']=plan['targetCore']
 data=encoded(manifest)
 result.append(('release-manifest.json',{'before':digest(live.root/'release-manifest.json'),'after':hashlib.sha256(data).hexdigest(),'bytes':len(data)},data))
 return result
def retain_releases(live,apply=False):
 from retention import cleanup
 try:return cleanup(live,RELEASES,STATE.parent,apply=apply,updates_root=ROOT)
 except (Exception,KeyboardInterrupt) as e:
  say('Sürüm temizliği durduruldu: '+str(e));return None

def preflight(live,plan,prune=False):
 require(not RESET_ACTIVE.exists(),'Hesap sıfırlaması sürüyor. Tamamlanmasını bekleyin.')
 require(plan.get('databaseChanges') is False and plan.get('databaseScope')=='none' and plan.get('accountsChanges') is False and 'schemaMigration' not in plan,'Bu kurucu yalnız oyun kodunu değiştirir; mevcut veritabanı şemaları korunur')
 live.active_binding();accounts=live.accounts_identity();policy=live.central()
 require(allowed_policy(policy),'Ön kayıt veya tamamlanmış bakım modu gerekli')
 require(policy['realm']['status'] in ('open','maintenance'),'Sunucu giriş durumu uygun değil')
 live.empty();core=initial_core(live,plan);verify_release(live.root,core);live.account_stable(accounts)
 require(same_policy(live.central(),policy),'Hazırlıkta oyun durumu değişti')
 stats=release_stats(live.root)
 if prune:retain_releases(live,True)
 live.account_stable(accounts);live.active_binding()
 require(same_policy(live.central(),policy),'Hazırlıkta oyun durumu değişti')
 space=os.statvfs(RELEASES);free=space.f_bavail*space.f_frsize
 needed=0 if live.state.get('r64Deployment',{}).get('version')==plan['version'] else stats['copyBytes']+128*1024*1024
 say('Disk: boş '+str(round(free/1024**3,2))+' GiB; bu kurulum için gereken '+str(round(needed/1024**3,2))+' GiB.')
 require(free>needed,'Ayrı oyun sürümü için boş disk alanı yetersiz. --disk-report ile alan dağılımını görün.')
 return accounts,policy,core,stats
def new_config(live,root,directory):
 config=json.loads(json.dumps(live.config));config['delivery511']['releaseRoot']=str(root)
 path=live.config_file.with_name('r64-'+directory.name+'-'+live.realm+'.json')
 return path,config
def startup_body(live,root,config_file):
 for p in (root,config_file):require(re.fullmatch(r'/[A-Za-z0-9_./-]+',str(p)) and '..' not in p.parts,'Başlatma yolu geçersiz')
 eager=live.config.get('environment',{}).get(old.R61_EAGER_FLAG,'0')=='1'
 return ('# Core of Life R64: isolated game, original accounts service.\n[Service]\nExecStart=\nExecStart='+str(root/'bin/node')+(' --no-lazy' if eager else '')+' '+str(root/'core511-source/scripts/delivery511/runtime-entry.mjs')+'\nWorkingDirectory='+str(root/'native510-bb3a6cc689c6')+'\nEnvironment=CORE_CONFIG_FILE='+str(config_file)+'\nEnvironment=PATH='+str(root/'bin')+':/usr/bin:/bin\nReadOnlyPaths='+str(root)+' '+str(config_file.parent)+'\n').encode()
def stop_game(record):
 for unit in reversed(record['units']):
  service(unit,'stop');require(prop(unit,'ActiveState') in ('inactive','failed'),'Oyun servisi durmadı: '+unit)
def start_game(record):
 for unit in record['units']:service(unit,'start')
def ensure_quiet(record):
 identity=(record['database']['device'],record['database']['inode'])
 for process in Path('/proc').iterdir():
  if not process.name.isdigit():continue
  try:fds=list((process/'fd').iterdir())
  except (FileNotFoundError,PermissionError,ProcessLookupError):continue
  for fd in fds:
   try:s=fd.stat()
   except (FileNotFoundError,PermissionError,ProcessLookupError):continue
   require((s.st_dev,s.st_ino)!=identity,'Oyun veritabanını açık tutan süreç var: '+process.name)
def complete(live,directory,record):
 live.account_stable(record['accounts']);live.central('restore',record['policy'])
 write_record(directory,record,'complete');clear_active()
 retain_releases(live,True)
 say('R78 TAMAMLANDI. Pazar/ödül işlerinde gereksiz durdurmalar ve sunucu ölçüm yükü düzeltildi. Dört kanal hazır; hesaplar korundu.')

def rollback(live,directory,record):
 require(record.get('version')==VERSION,'Bu kurtarma kaydı farklı sürüme ait; ilgili sürümün paketiyle kurtarın')
 # No accounts or game DB snapshot is ever restored: registrations made during
 # staging and rollback remain on the original FULL-durable accounts connection.
 require(digest(STATE) in (record['beforeState']['sha256'],record.get('afterStateSHA256')),'Kurulum kaydı başka bir işlemle değişmiş')
 current_dropin=digest(unit_path(live.unit)) if unit_path(live.unit).exists() else None
 require(current_dropin in (record['beforeDropin'].get('sha256'),record.get('afterDropinSHA256')),'Oyun başlatma dosyası başka bir işlemle değişmiş')
 current_accounts=live.accounts_identity()
 require({k:v for k,v in current_accounts.items() if k not in ('pid','start')}=={k:v for k,v in record['accounts'].items() if k not in ('pid','start')},'Hesap hizmetinin kaynak/ayar/veritabanı kimliği değişmiş')
 record['accounts']=current_accounts
 guards(record,True);stop_game(record);ensure_quiet(record)
 restore_file(record['beforeDropin']);restore_file(record['beforeState']);reload_units()
 previous=Live();previous.account_stable(record['accounts'])
 verify_release(previous.root,record['beforeCore']);guards(record,False);start_game(record);previous.ready(record)
 previous.central('restore',record['policy']);write_record(directory,record,'rolled_back');clear_active()
 say('Önceki oyun sürümü geri geldi. Bu sırada oluşturulan hesaplar korundu.')
def deploy(live,plan,updates):
 accounts,policy,core,stats=preflight(live,plan,prune=True)
 if live.state.get('r64Deployment',{}).get('version')==plan['version']:
  say('R78 oyun düzeltmeleri zaten kurulu.');return False
 updates=prepare_updates(live,plan,updates)
 token=time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'-'+os.urandom(4).hex();directory=ROOT/token;directory.mkdir(mode=0o700)
 destination=RELEASES/('core511-'+plan['version'].lower().replace('_','-')+'-'+token)
 config_file,config=new_config(live,destination,directory);body=startup_body(live,destination,config_file)
 units=[live.unit]
 if prop(live.rt_unit,'LoadState')!='not-found' and prop(live.rt_unit,'ActiveState')=='active':units.append(live.rt_unit)
 record={'version':plan['version'],'phase':'staging','accounts':accounts,'policy':policy,'database':live.db_identity,'units':units,
  'beforeCore':core,'targetCore':plan.get('targetCore') or core,'beforeState':file_record(STATE),'beforeDropin':file_record(unit_path(live.unit)),
  'source':str(live.root),'destination':str(destination),'configFile':str(config_file),'copy':stats}
 write_record(directory,record,'staging')
 try:
  previous_mask=os.umask(0o022)
  try:
   clone_release(live.root,destination)
   overlay(destination,updates)
  finally:os.umask(previous_mask)
  verify_release(destination,record['targetCore'])
  require(saved_matches(record['beforeState']) and saved_matches(record['beforeDropin']),'Hazırlık sırasında kurulum ayarı değişti')
  live.empty();assert_frame(live,record,False);write_record(directory,record,'gating');live.central('gate',policy)
  guards(record,True);write_record(directory,record,'stopping');stop_game(record);ensure_quiet(record);live.empty();assert_frame(live,record)
  state=json.loads(json.dumps(live.state));state['releaseRoot']=str(destination);state['candidate']=record['targetCore'];state['prior']['newGameConfigFile']=str(config_file)
  state['r64Deployment']={'version':plan['version'],'accountsRoot':str(live.accounts_root),'journal':str(directory/'journal.json'),'dropinSHA256':hashlib.sha256(body).hexdigest(),'protocol':1}
  record['afterStateSHA256']=hashlib.sha256(encoded(state)).hexdigest();record['afterDropinSHA256']=hashlib.sha256(body).hexdigest()
  write_record(directory,record,'selecting')
  st=live.config_file.stat();atomic(config_file,encoded(config),stat.S_IMODE(st.st_mode),(st.st_uid,st.st_gid))
  atomic(unit_path(live.unit),body,0o644)
  atomic(STATE,encoded(state));reload_units();write_record(directory,record,'selected')
  assert_frame(live,record);guards(record,False);write_record(directory,record,'starting');start_game(record)
  selected=Live();selected.ready(record);assert_frame(selected,record);write_record(directory,record,'validated')
  complete(selected,directory,record);return True
 except BaseException:
  say('Kurulum tamamlanamadı. Kayıt servisi açık tutularak önceki sürüme dönülüyor.')
  try:
   if record['phase']=='staging':write_record(directory,record,'cancelled');clear_active()
   else:rollback(live,directory,record)
  except BaseException:
   say('Oyun için kurtarma gerekli: aynı R78 paketiyle --recover çalıştırın. Hesap verileri geri alınmadı.')
  raise

def load_package(path):
 with zipfile.ZipFile(path) as z:
  plan=json.loads(z.read('update.json'));updates=[]
  require(plan.get('protocol')==1 and re.fullmatch(r'R\d+_[A-Z_]+',plan.get('version','')),'Güncelleme protokolü geçersiz')
  for name,meta in plan.get('files',{}).items():
   require(name not in ('node_modules',) and not name.startswith(('/','.')) and '..' not in Path(name).parts,'Paket dosya yolu geçersiz')
   data=z.read('payload/'+name);require(len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['after'],'Paket bütünlüğü bozuk')
   updates.append((name,meta,data))
 return plan,updates
def main(argv=None,archive=None):
 p=argparse.ArgumentParser(description=__doc__);actions=p.add_mutually_exclusive_group(required=True)
 for flag in ('check','apply','recover','rollback-latest','disk-report'):actions.add_argument('--'+flag,action='store_true')
 p.add_argument('--archive',default=archive);a=p.parse_args(argv)
 require(os.geteuid()==0,'Root olarak çalıştırın');require(a.archive,'Güncelleme paketi gerekli')
 plan,updates=load_package(a.archive)
 require(not RESET_ACTIVE.exists(),'Hesap sıfırlaması sürüyor. SIFIRLAMA TAMAMLANDI mesajını bekleyin.')
 live=Live()
 if a.disk_report:
  say('Disk alanı dağılımı (yalnız okuma):')
  r=subprocess.run(['/usr/bin/du','-x','-h','-d','2',str(RELEASES),str(STATE.parent),'/var/lib/coreoflife-realms-417','/var/tmp','/var/log'],capture_output=True,text=True,timeout=120)
  say(r.stdout);retain_releases(live,False);return
 if a.check:
  require(not ACTIVE.exists(),'Yarım R64 kurulumu var; --recover kullanın')
  accounts,policy,core,stats=preflight(live,plan)
  if live.state.get('r64Deployment',{}).get('version')!=plan['version']:prepare_updates(live,plan,updates)
  say(json.dumps({'uygun':True,'surum':plan['version'],'onKayit':policy['phase']=='waiting','hesapServisiYenidenBaslatilacak':False,'hesapVeritabaniGeriAlinacak':False,'ayriOyunSurumu':True,**stats},ensure_ascii=False));return
 ROOT.mkdir(parents=True,exist_ok=True,mode=0o700);require(not ROOT.is_symlink() and ROOT.stat().st_uid==0 and stat.S_IMODE(ROOT.stat().st_mode)==0o700,'R64 işlem dizini izinleri geçersiz')
 with lock(STATE.parent/'r23-backups/install.lock'):
  require(not RESET_ACTIVE.exists(),'Sıfırlama sürüyor')
  if a.recover or a.rollback_latest:
   if a.recover:
    require(ACTIVE.exists(),'Yarım R64 işlemi yok');directory=Path(read(ACTIVE)['directory'])
   else:
    require(not ACTIVE.exists(),'Önce --recover çalıştırın');directory=Path(live.state.get('r64Deployment',{}).get('journal','')).parent
   require(directory.parent==ROOT,'Kurtarma kaydı kapsamı geçersiz');record=read(directory/'journal.json')
   require(record.get('version')==VERSION,'Bu kurtarma kaydı farklı sürüme ait; ilgili sürümün paketiyle kurtarın')
   require(descriptor(live.database)==record['database'],'Kurtarma veritabanı uyuşmuyor')
   if not (a.recover and record['phase'] in ('validated','complete')):live.empty()
   if a.rollback_latest:
    fresh=live.central();require(allowed_policy(fresh),'Geri almak için ön kayıt veya bakım modu gerekli')
    record['policy']=fresh;record['accounts']=live.accounts_identity();write_record(directory,record,'gating-rollback');live.central('gate',fresh)
   if a.recover and record['phase']=='staging':write_record(directory,record,'cancelled');clear_active();say('Yarım hazırlık iptal edildi; oyun ve hesaplar değişmedi.');return
   if a.recover and record['phase'] in ('validated','complete'):
    current=live.accounts_identity()
    require({k:v for k,v in current.items() if k not in ('pid','start')}=={k:v for k,v in record['accounts'].items() if k not in ('pid','start')},'Kurtarmada hesap hizmeti değişmiş')
    record['accounts']=current
    live.health(empty=False);live.active_binding();complete(live,directory,record);return
   write_record(directory,record,'recovering');rollback(live,directory,record);return
  require(not ACTIVE.exists(),'Yarım R64 kurulumu var; --recover kullanın');deploy(live,plan,updates)

if __name__=='__main__':
 try:main()
 except (Exception,KeyboardInterrupt) as error:
  say('DURDU: '+(str(error) if isinstance(error,RuntimeError) else type(error).__name__));sys.exit(1)
