import {WalCheckpoint,supportsConcurrentCheckpoint} from '../../../native510-bb3a6cc689c6/vds-server/src/wal-checkpoint.mjs';
import {demand} from './contract.mjs';

// Only the trusted parent and its one reward writer share this flag. It never
// contains gameplay state or credentials. A failed/stopped supervisor restores
// automatic checkpoints; the reward writer checks it before every COMMIT too.
export class CheckpointRuntimeR79 {
 constructor(database,file,{enabled=process.env.CORE_WAL_CHECKPOINT_WORKER!=='0',options={},report=event=>console.warn(JSON.stringify(event))}={}){
  this.database=database;this.listeners=new Set();this.state=new Int32Array(new SharedArrayBuffer(4));this.closed=false;this.report=report;
  demand(!database.sqlite.isTransaction&&!database.core511CheckpointR79,'checkpoint_runtime_binding');
  database.core511CheckpointR79=this;
  if(!enabled){this.fallback('disabled');this.ready=Promise.resolve(false);return;}
  // Never accept a caller-supplied SQLite version: the native worker must
  // validate the actual runtime on both sides of its existing safety gate.
  const {sqliteVersion:_ignored,onFallback:_ignoredFallback,...workerOptions}=options;
  this.worker=new WalCheckpoint(file,{...workerOptions,onFallback:reason=>this.fallback(reason)});
  database.walCheckpoint=this.worker;
  try{this.unregister=this.worker.register(database.sqlite,{externallyDurable:Boolean(database.walSync)});}catch(error){this.ready=this.worker.close().then(()=>{throw error;});return;}
  this.ready=this.worker.ready.then(ready=>{
   if(ready&&!this.closed&&this.worker.snapshot().ready){this.publish(true);this.emit({state:'ready'});return true;}
   if(!this.closed)this.fallback(this.worker.snapshot().fallback??'not-ready');
   return false;
  });
 }
 get buffer(){return this.state.buffer;}
 publish(active){Atomics.store(this.state,0,active?1:0);for(const listener of this.listeners)try{listener();}catch{/* The shared flag still fences every reward COMMIT. */}}
 subscribe(listener){demand(typeof listener==='function','checkpoint_listener');this.listeners.add(listener);return()=>this.listeners.delete(listener);}
 emit(detail){try{this.report({event:'core511_checkpoint',sqliteVersion:process.versions.sqlite,...detail});}catch{}}
 fallback(reason){this.publish(false);if(this.reason===reason)return;this.reason=reason;this.emit({state:'fallback',reason});}
 snapshot(){return this.worker?.snapshot()??{protocol:'passive-wal-worker-v1',ready:false,fallback:this.reason??'disabled',connections:0,running:false};}
 async close(){if(this.closing)return this.closing;this.closed=true;this.publish(false);this.closing=(async()=>{await this.worker?.close();this.listeners.clear();})();return this.closing;}
}

// This connection has FULL synchronous commits. Disabling its automatic
// checkpoint changes only who copies WAL pages, never the durable ACK boundary.
export function installRewardCheckpointR79(database,buffer){
 if(buffer===undefined||buffer===null)return {sync:()=>false,close:()=>{},snapshot:()=>({active:false,supervised:false})};
 demand(buffer instanceof SharedArrayBuffer&&buffer.byteLength===4,'reward_checkpoint_buffer');
 const state=new Int32Array(buffer),sql=database.sqlite;
 const original=Number(sql.prepare('PRAGMA wal_autocheckpoint').get().wal_autocheckpoint);
 demand(Number.isSafeInteger(original)&&original>0&&Number(sql.prepare('PRAGMA synchronous').get().synchronous)>=2,'reward_checkpoint_durability');
 const supported=supportsConcurrentCheckpoint(process.versions.sqlite);let active=false,closed=false;
 const sync=()=>{const next=!closed&&supported&&Atomics.load(state,0)===1;if(next!==active){sql.exec('PRAGMA wal_autocheckpoint='+(next?0:original));active=next;}return active;};
 const commit=database.commitWrites;database.commitWrites=function(...args){sync();return Reflect.apply(commit,this,args);};
 sync();
 return {sync,close:()=>{closed=true;sync();},snapshot:()=>({active,supervised:true,original,supported})};
}
