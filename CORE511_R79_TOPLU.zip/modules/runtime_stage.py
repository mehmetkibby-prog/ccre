"""Pin and select the game-only Node runtime inside an isolated candidate."""
import json,os,stat,subprocess,uuid
from pathlib import Path
from storage import digest,member,require,sync_dir

NODE='runtime/node-v22.23.4-linux-x64/bin/node'
LICENSE='runtime/node-v22.23.4-linux-x64/LICENSE'
NODE_SHA256='94efd062ed066c1a0b332e18249859c905e920eeada5df55d24c99b919629a90'
NODE_BYTES=124902584
ARCHIVE_SHA256='1805bcd35e6815559bd2eb97db438d3fdb0eb3a5e6a977b7c1badca76337e9ce'
LICENSE_SHA256='c738ae413cf561f174e34f6961f8ca458aae2369a73640dda6234c629b98bcc4'
LICENSE_BYTES=145485
VERSIONS={'node':'v22.23.4','sqlite':'3.53.4','modules':'127','arch':'x64','platform':'linux'}
LINK='../'+NODE

def validate_plan(plan):
 r=plan.get('runtime',{})
 require(r.get('path')==NODE and r.get('licensePath')==LICENSE and r.get('sha256')==NODE_SHA256 and r.get('bytes')==NODE_BYTES and r.get('versions')==VERSIONS and r.get('linkPath')=='bin/node' and r.get('linkTarget')==LINK and r.get('archiveSHA256')==ARCHIVE_SHA256,'R79 Node çalışma zamanı kimliği farklı')
 require(set(n for n in plan['files'] if n.startswith('runtime/'))=={NODE,LICENSE},'R79 çalışma zamanı dosya kapsamı farklı')
 meta=plan['files'][NODE]
 require(meta.get('after')==NODE_SHA256 and meta.get('bytes')==NODE_BYTES and meta.get('before') is None and meta.get('executable') is True,'R79 Node dosyası farklı')
 lic=plan['files'][LICENSE]
 require(lic.get('before') is None and lic.get('executable') is False and lic.get('after')==LICENSE_SHA256 and lic.get('bytes')==LICENSE_BYTES,'R79 lisans dosyası farklı')
 return r

def binding(root):
 p=member(root,'bin/node');s=p.lstat()
 if stat.S_ISLNK(s.st_mode):
  target=os.readlink(p)
  require(not Path(target).is_absolute() and p.resolve().is_relative_to(root.resolve()) and p.is_file(),'Node bağı sürüm dışında')
  return {'kind':'symlink','target':target}
 require(stat.S_ISREG(s.st_mode) and bool(s.st_mode&0o111),'Node başlatıcısı normal çalıştırılabilir dosya olmalı')
 return {'kind':'file','sha256':digest(p),'bytes':s.st_size}

def prepare_manifest(root,manifest,plan):
 validate_plan(plan);before=binding(root);rows=[row for row in manifest['files'] if row['path']=='bin/node'];links=[row for row in manifest.get('symlinks',[]) if row['path']=='bin/node']
 if before['kind']=='file':require(len(rows)==1 and not links and rows[0]['sha256']==before['sha256'] and rows[0]['bytes']==before['bytes'],'Önceki Node dosyası manifestle eşleşmiyor')
 else:require(len(links)==1 and not rows and links[0]['target']==before['target'],'Önceki Node bağı manifestle eşleşmiyor')
 plan['runtimeBefore']=before
 manifest['files']=[row for row in manifest['files'] if row['path']!='bin/node']
 manifest['symlinks']=[row for row in manifest.get('symlinks',[]) if row['path']!='bin/node']+[{'path':'bin/node','target':LINK}]

def stage_runtime(root,plan):
 validate_plan(plan);node=member(root,NODE)
 require(not node.is_symlink() and node.is_file() and node.stat().st_size==NODE_BYTES and digest(node)==NODE_SHA256 and bool(node.stat().st_mode&0o111),'Yeni Node doğrulanamadı')
 require(binding(root)==plan.get('runtimeBefore'),'Node başlatıcısı hazırlık sırasında değişti')
 target=member(root,'bin/node');temp=target.parent/('.r79-node-'+uuid.uuid4().hex)
 try:
  os.symlink(LINK,temp);os.replace(temp,target);sync_dir(target.parent)
 finally:temp.unlink(missing_ok=True)
 assert_runtime(root,plan)

def assert_runtime(root,plan):
 validate_plan(plan);node=member(root,NODE);link=member(root,'bin/node')
 require(not node.is_symlink() and node.is_file() and node.stat().st_size==NODE_BYTES and digest(node)==NODE_SHA256 and bool(node.stat().st_mode&0o111),'Yeni Node kimliği farklı')
 require(link.is_symlink() and os.readlink(link)==LINK and link.resolve()==node.resolve(),'Yeni Node bağı farklı')
 result=subprocess.run([str(link),'-p','JSON.stringify({node:process.version,sqlite:process.versions.sqlite,modules:process.versions.modules,arch:process.arch,platform:process.platform})'],capture_output=True,text=True,timeout=20)
 require(result.returncode==0,'Yeni Node başlatılamadı')
 require(json.loads(result.stdout)==VERSIONS,'Yeni Node/SQLite sürümü farklı')
 return VERSIONS
