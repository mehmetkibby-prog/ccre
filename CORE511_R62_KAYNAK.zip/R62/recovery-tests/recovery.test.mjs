import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {HeartbeatMaintenanceReader} from '../working/core511-source/scripts/core511/heartbeat-maintenance-reader.mjs';
import {HeartbeatJobs} from '../working/core511-source/scripts/core511/heartbeat-jobs.mjs';
import {SharedWorldJobs} from '../working/core511-source/scripts/core511/shared-world-jobs.mjs';
import {AbandonedNormal} from '../working/core511-source/scripts/core511/abandoned-normal.mjs';
import {nextRewardTargetsR52} from '../working/core511-source/scripts/core511/reward-recovery-r52.mjs';

function fixture(t){
 const sql=new DatabaseSync(':memory:');t.after(()=>sql.close());sql.exec(`
 CREATE TABLE world_state(id PRIMARY KEY,cycle);INSERT INTO world_state VALUES(1,1);
 CREATE TABLE normal_defeats(monster_id,spawn_round,defeated_at,rewards_completed_at DEFAULT 0,loot_source_key DEFAULT 'normal.catalog');
 CREATE TABLE monsters(id PRIMARY KEY,channel DEFAULT 1,is_boss DEFAULT 0,is_stone DEFAULT 0);
 CREATE TABLE monster_participants(monster_id,spawn_round,player_id);
 CREATE TABLE normal_reward_claims(monster_id,spawn_round,player_id);
 CREATE TABLE monster_xp_claims(monster_id,spawn_round,player_id);
 CREATE TABLE sinsi_reward_claims(monster_id,spawn_round,player_id);
 CREATE TABLE boss_reward_claims(boss_round,player_id);
 CREATE TABLE loadlab_boss_rounds_v1(monster_id,boss_round);
 CREATE TABLE party_members(player_id,party_id);
 CREATE TABLE players(id PRIMARY KEY,hp DEFAULT 100,last_seen DEFAULT 1000,movement_checked_at_ms DEFAULT 1000000,last_monster_hit_at DEFAULT 1000000,area DEFAULT 'forest',channel DEFAULT 1,arena_match_id DEFAULT '',x DEFAULT 0,y DEFAULT 0);
 INSERT INTO players(id) VALUES('p');
 CREATE TABLE game_settings(id PRIMARY KEY);INSERT INTO game_settings VALUES(1);
 CREATE TABLE combat_settings(id PRIMARY KEY);INSERT INTO combat_settings VALUES(1);
 CREATE TABLE kernel511_channel_owners(player_id,epoch,channel,state);
 CREATE TABLE kernel511_admissions(player_id,epoch,channel);
 INSERT INTO kernel511_channel_owners VALUES('p',1,1,'active');INSERT INTO kernel511_admissions VALUES('p',1,1);
 `);
 const seed=(id,{age=60,channel=1,source='normal.catalog',boss=0,stone=0}={})=>{
  sql.prepare('INSERT INTO monsters VALUES(?,?,?,?)').run(id,channel,boss,stone);
  sql.prepare('INSERT INTO normal_defeats(monster_id,spawn_round,defeated_at,loot_source_key) VALUES(?,1,?,?)').run(id,1000-age,source);
  sql.prepare('INSERT INTO monster_participants VALUES(?,1,?)').run(id,'p');
 };return {sql,seed};
}

test('durable discovery works with no heartbeat/admission, stays bounded and wraps past fenced recipients',t=>{
 const {sql,seed}=fixture(t);for(let n=0;n<22;n++)seed('m'+String(n).padStart(2,'0'),{channel:n<20?1:2});
 for(const [id,args]of [['special',{source:'adventure.catalog'}],['event',{source:'event.catalog'}],['boss',{boss:1}],['stone',{stone:1}],['world',{channel:0}],['fresh',{age:3}]])seed(id,args);
 sql.exec('DELETE FROM kernel511_channel_owners;DELETE FROM kernel511_admissions');
 const reader=new HeartbeatMaintenanceReader(sql),get=()=>reader.recoveryDueR62({cycle:1,nowMs:1000000});
 assert.equal(reader.recoveryDueR62({cycle:2,nowMs:1000000}),null);
 const a=get(),b=get(),c=get(),d=get();assert.deepEqual([a.normalTargets.length,b.normalTargets.length,c.normalTargets.length,d.normalTargets.length],[16,4,2,16]);
 assert.equal(a.normalTarget.id,'m00');assert.equal(c.normalTarget.id,'m20');assert.equal(d.normalTarget.id,'m00');
 sql.exec("INSERT INTO normal_reward_claims SELECT monster_id,spawn_round,'p' FROM normal_defeats");assert.equal(get(),null);
 assert.throws(()=>nextRewardTargetsR52(sql,{nowMs:1000000,grace:20,limit:1000}),/target_limit/);
});

test('ordinary background scan preserves special catalog global recovery',t=>{
 const {sql,seed}=fixture(t);seed('a-ordinary',{age:80});seed('z-special',{source:'adventure.catalog',age:60});
 const reader=new HeartbeatMaintenanceReader(sql);
 reader.rules={colLabIsPlayer:()=>false,readPendingBoss511:()=>null,readPendingSinsi511:()=>null,readPendingDrops511:()=>[],readPendingNormal511:(_db,_settings,_now,preferred)=>sql.prepare('SELECT * FROM normal_defeats WHERE monster_id=?').get(preferred?.id??'a-ordinary')};
 const entry={actor:'p',epoch:1,cycle:1,nowMs:1000000};
 const due=reader.due([entry],{cycle:1,nowMs:1000000,skipOrdinaryR62:true});
 assert.equal(due.maintenanceReason,'abandoned_normal');assert.equal(due.normalTarget,undefined);
 // If the special target is paid, ordinary targets belong only to the bounded background scan.
 sql.exec("INSERT INTO normal_reward_claims VALUES('z-special',1,'p')");assert.equal(reader.due([entry],{cycle:1,nowMs:1000000,skipOrdinaryR62:true}),null);
});

function jobs(){const world={row:{peer:{incarnation:'world'}},core:{clock:()=>1000000,writer:{owners:new Map()},reader:{query:null}}};return {world,jobs:new HeartbeatJobs(world)};}
test('empty heartbeat queue still retries deferred durable jobs and finishes after reconnect',async()=>{
 const f=jobs(),entry={cycle:1,nowMs:1000000,recoveryR62:true,normalTarget:{id:'m',spawnRound:1}},calls=[];
 f.world.core.reader.query=async(name)=>{calls.push(name);return {rows:entry};};let deferred=true;
 f.jobs.abandoned.run=async()=>deferred?{handled:true,deferred:true}:true;
 assert.deepEqual(await f.jobs.due(f.world.row.peer,{cycle:1,nowMs:1000000}),{recoveryOnlyR62:true,retryAfterMs:250});
 deferred=false;assert.deepEqual(await f.jobs.due(f.world.row.peer,{cycle:1,nowMs:1000000}),{recoveryOnlyR62:true,retryAfterMs:50});
 assert.deepEqual(calls,['kernel511_normal_recovery_r62','kernel511_normal_recovery_r62']);assert.equal(f.jobs.held,null);
});

test('background recovery preserves independent arena descriptors and newer heartbeats',async()=>{
 const f=jobs(),peer={channel:1,incarnation:'channel'},make=(actor,counter=1)=>({actor,counter,epoch:1,nowMs:1000000,cycle:1,heartbeat:{channel:1,area:'arena',arena_match_id:'match'}});
 for(const id of ['a','b']){f.world.core.writer.owners.set(id,{...peer,admitted:true,epoch:1});f.jobs.schedule(peer,make(id));}
 f.jobs.abandoned.run=async()=>true;
 f.world.core.reader.query=async(name,params)=>{if(name==='kernel511_normal_recovery_r62')return {rows:{normalTarget:{id:'m',spawnRound:1}}};assert.equal(params.skipOrdinaryR62,true);f.jobs.schedule(peer,make('b',2));return {rows:params.entries[0]};};
 const a=await f.jobs.due(f.world.row.peer,{cycle:1,nowMs:1000000});assert.equal(a.actor,'a');assert.equal(f.jobs.pending.get('b').counter,2);f.jobs.complete(a);
});

test('aged rewards use draining freeze without bypassing retained ownership fences',async t=>{
 const {sql,seed}=fixture(t);seed('m',{age:30});const calls=[],world={row:{peer:{incarnation:'world'}},core:{database:{sqlite:sql},clock:()=>1000000,writer:{},serial:fn=>fn(),transitions:new Map(),entryReads:new Map(),permanent:{entries:new Map(),assertAvailable:()=>{},durablePlayersWhenIdle:async()=>{calls.push('idle');return {deferred:true,code:'reward_recovery_busy'};},durablePlayers:async()=>{calls.push('drain');return {result:{awarded:true}};}}}},jobs=new AbandonedNormal(world),entry={cycle:1,recoveryR62:true,normalTarget:{id:'m',spawnRound:1}};
 await jobs.run(world.row.peer,entry);assert.deepEqual(calls,['idle']);
 sql.exec('UPDATE normal_defeats SET defeated_at=940');seed('younger',{age:25});entry.normalTargets=[entry.normalTarget,{id:'younger',spawnRound:1}];await jobs.run(world.row.peer,entry);assert.deepEqual(calls,['idle','drain']);
 world.core.transitions.set('p',{});const deferred=await jobs.run(world.row.peer,entry);assert.equal(deferred.deferred,true);assert.deepEqual(calls,['idle','drain']);
 world.core.transitions.clear();world.core.permanent.assertAvailable=()=>{throw Object.assign(Error('retained'),{code:'player_permanent_fenced'});};
 assert.equal((await jobs.run(world.row.peer,entry)).deferred,true);assert.equal(jobs.trace.at(-1).code,'player_permanent_fenced');assert.deepEqual(calls,['idle','drain']);
});

test('recovery retry never starts a global world transition or creates an unbounded loop',async()=>{
 const requests=[],now=Date.now(),runtime={initial:{world:{cycle:1,reset_at:0,guardian_reward_at:Math.floor(now/1000)+10000}},writer:{submit:async()=>({result:{worldPoint:{}}})},setWorld:()=>{},request:async(name)=>{requests.push(name);return name==='heartbeat_due'?{recoveryOnlyR62:true,retryAfterMs:50}:{due:false,deferred:false};},fail:error=>{throw error;}};
 const jobs=new SharedWorldJobs(runtime);jobs.enabled=true;jobs.tick(now);await jobs.pending;
 assert.equal(jobs.transition,null);assert.equal(jobs.blocked,false);assert.ok(!requests.includes('world_transition_prepare'));assert.ok(jobs.nextAt>=now+50&&jobs.nextAt<=now+1000);
 const n=requests.length;jobs.tick(now+1);assert.equal(requests.length,n);
});
