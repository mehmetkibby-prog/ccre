#!/usr/bin/env python3
"""V2 presentation correction; all game policy is controlled by the admin.

No game processes, databases, or launch settings are changed by this installer.
Unchanged, verified V2 media is reused to keep this correction small.
"""
import argparse,copy,fcntl,hashlib,json,os,re,shutil,subprocess,sys,tempfile,time,urllib.request,urllib.error,zipfile
from pathlib import Path

HOSTS={'coreoflife.net','www.coreoflife.net'}
ACCOUNT_HOST='accounts.coreoflife.net'
LEGACY_IDS={'col-marketing-assets-v1','col-marketing-pages-v1'}
ROUTE_IDS={'col-marketing-assets-v2','col-marketing-pages-v2','col-prereg-pages-v2','col-prereg-redirect-v2','col-launch-status-v2'}
ALL_ROUTE_IDS=ROUTE_IDS|LEGACY_IDS
BASE_RELEASE='20261026-4385eb249bd8'
V2_IDS=ROUTE_IDS.copy()
ROUTE_IDS=ROUTE_IDS|{'col-admin-status-v3'}
ALL_ROUTE_IDS=ROUTE_IDS|LEGACY_IDS
CSP="default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self'; font-src 'self'; media-src 'self'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'; object-src 'none'"
PREREG_CSP=CSP.replace("img-src 'self'", "img-src 'self' data:")

def require(condition,message):
    if not condition:raise RuntimeError(message)
def sha(data):return hashlib.sha256(data).hexdigest()
def read_json(path):return json.loads(Path(path).read_bytes())
def atomic(path,data,mode=0o600):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    previous=path.stat() if path.exists() else None
    fd,tmp=tempfile.mkstemp(prefix='.col-site-',dir=path.parent)
    try:
        os.fchmod(fd,mode)
        if previous:os.fchown(fd,previous.st_uid,previous.st_gid)
        with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
def json_bytes(value):return (json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode()
def api(admin,path='',data=None):
    # Local Caddy admin traffic must never go through an external HTTP proxy.
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    request=urllib.request.Request(admin+path,data=None if data is None else json_bytes(data),headers={'Content-Type':'application/json'})
    with opener.open(request,timeout=20) as response:
        body=response.read(16*1024*1024)
        return json.loads(body) if body else None
def host_redirect(route):
    matches=route.get('match',[])
    if len(matches)!=1 or set(matches[0])!={'host'}:return False
    if set(matches[0]['host'])!=HOSTS:return False
    def responses(obj):
        if isinstance(obj,dict):
            if obj.get('handler')=='static_response':yield obj
            for value in obj.values():yield from responses(value)
        elif isinstance(obj,list):
            for value in obj:yield from responses(value)
    for response in responses(route):
        location=response.get('headers',{}).get('Location',[])
        if str(response.get('status_code')) in {'302','307','308','301'} and any(re.match(r'^https://accounts\.coreoflife\.net(?:$|/|\?|\{http\.request\.uri\})',str(s)) for s in location):return True
    return False
def legacy_routes(root):
    common={'X-Content-Type-Options':['nosniff'],'Referrer-Policy':['strict-origin-when-cross-origin'],'Permissions-Policy':['camera=(), microphone=(), geolocation=()']}
    def route(name,paths,cache,html):
        headers={**common,'Cache-Control':[cache]}
        if html:headers['Content-Security-Policy']=[CSP]
        return {'@id':name,'match':[{'host':sorted(HOSTS),'path':paths,'method':['GET','HEAD']}],'handle':[{'handler':'headers','response':{'set':headers}},{'handler':'encode','encodings':{'gzip':{}},'prefer':['gzip']},{'handler':'file_server','root':str(root),'index_names':['index.html']}],'terminal':True}
    return [route('col-marketing-assets-v1',['/col-site/*'],'public, max-age=31536000, immutable',False),route('col-marketing-pages-v1',['/','/index.html','/favicon.svg','/robots.txt','/sitemap.xml'],'no-cache',True)]
def account_proxy(config):
    found=[]
    for server in config.get('apps',{}).get('http',{}).get('servers',{}).values():
        for route in server.get('routes',[]):
            if route.get('@id') in ALL_ROUTE_IDS:continue
            if any(m.get('host')==[ACCOUNT_HOST] and set(m)=={'host'} for m in route.get('match',[])):
                def walk(value):
                    if isinstance(value,dict):
                        if value.get('handler')=='reverse_proxy':found.append(copy.deepcopy(value))
                        else:
                            for v in value.values():walk(v)
                    elif isinstance(value,list):
                        for v in value:walk(v)
                walk(route.get('handle',[]))
    require(len(found)==1,'Expected one existing accounts reverse proxy; refusing to guess the account service address.')
    proxy=found[0]
    require(proxy.get('upstreams'),'Account proxy has no configured upstream.')
    request=proxy.setdefault('headers',{}).setdefault('request',{})
    request.setdefault('set',{})['Host']=[ACCOUNT_HOST]
    request['delete']=list(dict.fromkeys(request.get('delete',[])+['Cookie','Authorization']))
    return proxy
def v2_routes(root,proxy):
    common={'X-Content-Type-Options':['nosniff'],'Referrer-Policy':['strict-origin-when-cross-origin'],'Permissions-Policy':['camera=(), microphone=(), geolocation=()']}
    def static(name,hosts,paths,cache,html=False,rewrite=None,extra=None):
        headers={**common,'Cache-Control':[cache]}
        if html:headers['Content-Security-Policy']=[CSP]
        match={'host':hosts,'path':paths,'method':['GET','HEAD'],**(extra or {})}
        handlers=[{'handler':'headers','response':{'set':headers}},{'handler':'encode','encodings':{'gzip':{}},'prefer':['gzip']}]
        if rewrite:handlers.append({'handler':'rewrite','uri':rewrite})
        handlers.append({'handler':'file_server','root':str(root),'index_names':['index.html']})
        return {'@id':name,'match':[match],'handle':handlers,'terminal':True}
    assets=static('col-marketing-assets-v2',sorted(HOSTS|{ACCOUNT_HOST}),['/col-site/*'],'public, max-age=31536000, immutable')
    pages=static('col-marketing-pages-v2',sorted(HOSTS),['/','/index.html','/favicon.svg','/robots.txt','/sitemap.xml'],'no-cache',True)
    prereg=static('col-prereg-pages-v2',[ACCOUNT_HOST],['/on-kayit','/on-kayit/'],'no-store',True,'/prereg.html')
    prereg['handle'][0]['response']['set']['Content-Security-Policy']=[PREREG_CSP]
    # Root query requests belong to the native SSO/logout/admin portal.
    prereg['match'].append({'host':[ACCOUNT_HOST],'path':['/'],'method':['GET','HEAD'],'expression':"{http.request.uri.query} == ''"})
    redirect={'@id':'col-prereg-redirect-v2','match':[{'host':sorted(HOSTS),'path':['/on-kayit','/on-kayit/'],'method':['GET','HEAD']}],'handle':[{'handler':'static_response','status_code':302,'headers':{'Location':['https://accounts.coreoflife.net/on-kayit'],'Cache-Control':['no-store']}}],'terminal':True}
    status={'@id':'col-launch-status-v2','match':[{'host':sorted(HOSTS|{ACCOUNT_HOST}),'path':['/api/site-launch'],'method':['GET','HEAD']}],'handle':[{'handler':'headers','response':{'set':{'Cache-Control':['no-store'],'X-Content-Type-Options':['nosniff']}}},{'handler':'rewrite','uri':'/api/launch'},proxy],'terminal':True}
    return [assets,pages,prereg,redirect,status]
def new_routes(root,proxy):
    routes=v2_routes(root,proxy)
    # The existing dedicated game-status URL keeps the same authenticated API.
    # No game/SSO/native admin assets or backend services are replaced.
    routes[0]['match'][0]['host']=sorted(HOSTS|{ACCOUNT_HOST,'r1.coreoflife.net'})
    admin={'@id':'col-admin-status-v3','match':[{'host':['r1.coreoflife.net'],'path':['/admin/oyun-durumu','/admin/oyun-durumu/'],'method':['GET','HEAD']}],
           'handle':[{'handler':'headers','response':{'set':{'Cache-Control':['no-store'],'Content-Security-Policy':[CSP],'X-Content-Type-Options':['nosniff'],'Referrer-Policy':['same-origin'],'X-Robots-Tag':['noindex, nofollow']}}},
                     {'handler':'rewrite','uri':'/admin-status.html'},{'handler':'file_server','root':str(root)}],'terminal':True}
    return [*routes,admin]
def transform(config,root):
    result=copy.deepcopy(config);targets=[];proxy=account_proxy(config)
    servers=result.get('apps',{}).get('http',{}).get('servers',{})
    for key,server in servers.items():
        routes=server.get('routes',[])
        old=[r for r in routes if r.get('@id') in ALL_ROUTE_IDS]
        if old:
            ids={r.get('@id') for r in old}
            expected=legacy_routes(root) if ids==LEGACY_IDS else v2_routes(root,proxy) if ids==V2_IDS else new_routes(root,proxy)
            require(old==expected,'Existing site routes were modified; refusing to overwrite unknown changes.')
            routes[:]=[r for r in routes if r.get('@id') not in ALL_ROUTE_IDS]
        indexes=[i for i,r in enumerate(routes) if host_redirect(r)]
        if indexes:
            require(len(indexes)==1,'Multiple apex redirect routes; no changes made.')
            require(any(any(m.get('host')==[ACCOUNT_HOST] for m in r.get('match',[])) for r in routes),'Account and apex routes must share the same server.')
            routes[0:0]=new_routes(root,proxy);targets.append(key)
    require(len(targets)==1,'Expected exactly one existing apex redirect to accounts.coreoflife.net; no changes made.')
    # Removal of our routes must preserve every unrelated configuration value.
    check=copy.deepcopy(result)
    original=copy.deepcopy(config)
    for snapshot in [check,original]:
        for server in snapshot['apps']['http']['servers'].values():server['routes']=[r for r in server.get('routes',[]) if r.get('@id') not in ALL_ROUTE_IDS]
    require(check==original,'Unrelated Caddy configuration would change.')
    return result,targets[0]
def select_link(path,target):
    path=Path(path)
    require(not path.exists() or path.is_symlink(),'Current site path is not a symlink; refusing to replace it.')
    next_path=path.with_name('.current-'+str(os.getpid()))
    if next_path.is_symlink():next_path.unlink()
    os.symlink(str(target),next_path);os.replace(next_path,path)
def validate(caddy,config):
    run=subprocess.run([caddy,'validate','--config',str(config)],capture_output=True,text=True)
    require(run.returncode==0,'Caddy configuration validation failed; live configuration was not changed.')
def safe_file(root,name):
    require(isinstance(name,str) and name and not name.startswith('/') and all(part not in ('','.','..') for part in name.split('/')),'Invalid file path.')
    root=Path(root);target=root/name
    require(target.resolve().is_relative_to(root.resolve()),'File is outside the managed directory.')
    for parent in [target,*target.parents]:
        if parent==root.parent:break
        require(not parent.is_symlink(),'Symlink in a managed release: '+name)
    return target
def verify(file,meta):
    require(file.is_file() and not file.is_symlink() and file.stat().st_size==meta['bytes'] and sha(file.read_bytes())==meta['sha256'],'File integrity failure: '+file.name)
def payload(zip_path,root):
    with zipfile.ZipFile(zip_path) as z:
        manifest=json.loads(z.read('BUILD.json'))
        require(re.fullmatch(r'20261026-[0-9a-f]{12}',manifest['release']) is not None,'Invalid release identifier.')
        require(manifest.get('baseRelease')==BASE_RELEASE,'This correction requires Site V2.')
        require(manifest['assetPrefix']=='/col-site/'+manifest['release']+'/','Invalid asset prefix.')
        require({'index.html','prereg.html','admin-status.html'}<=manifest['files'].keys(),'Required page is missing.')
        base=root/'releases'/BASE_RELEASE
        require(base.is_dir() and not base.is_symlink(),'Site V2 must be installed before this small correction.')
        for name,meta in manifest['files'].items():
            safe_file(root/'releases'/manifest['release'],name)
            if 'basePath' in meta:verify(safe_file(base,meta['basePath']),meta)
            else:
                data=z.read('site/'+name)
                require(len(data)==meta['bytes'] and sha(data)==meta['sha256'],'Archive integrity failure: '+name)
        return manifest
def installed_files(manifest,destination):
    require(destination.is_dir() and not destination.is_symlink(),'Release destination is not a managed directory.')
    for name,meta in manifest['files'].items():verify(safe_file(destination,name),meta)
def retain_assets(previous,destination,root):
    source=Path(previous)
    require(source.is_relative_to(root/'releases') and source.is_dir() and not source.is_symlink(),'Previous site release is outside the managed directory.')
    old=source/'col-site'
    require(old.is_dir() and not old.is_symlink(),'Previous assets are missing.')
    for file in old.rglob('*'):
        require(not file.is_symlink(),'Symlink in previous assets.')
        target=destination/'col-site'/file.relative_to(old)
        if file.is_dir():target.mkdir(parents=True,exist_ok=True,mode=0o755)
        elif not target.exists():
            require(file.is_file(),'Unexpected previous asset.')
            target.parent.mkdir(parents=True,exist_ok=True,mode=0o755);os.link(file,target)
def extract(zip_path,manifest,destination,previous,root):
    if destination.exists():
        installed_files(manifest,destination);return
    destination.parent.mkdir(parents=True,exist_ok=True,mode=0o755)
    stage=Path(tempfile.mkdtemp(prefix='.staging-',dir=destination.parent));os.chmod(stage,0o755)
    try:
        with zipfile.ZipFile(zip_path) as z:
            for name,meta in manifest['files'].items():
                file=stage/name;file.parent.mkdir(parents=True,exist_ok=True,mode=0o755)
                if 'basePath' in meta:
                    source=safe_file(root/'releases'/BASE_RELEASE,meta['basePath']);verify(source,meta);os.link(source,file)
                else:atomic(file,z.read('site/'+name),0o644)
        retain_assets(previous,stage,root);installed_files(manifest,stage);os.rename(stage,destination)
    finally:
        if stage.exists():shutil.rmtree(stage)
def current_admin(args):
    require(re.fullmatch(r'http://127\.0\.0\.1:\d+',args.admin) is not None,'Admin endpoint must be loopback HTTP.')
    return api(args.admin,'/config/')
def main(argv=None,archive=None):
    p=argparse.ArgumentParser(description='Core of Life Site V2: admin-controlled preregistration correction')
    actions=p.add_mutually_exclusive_group(required=True)
    for flag in ['check','apply','rollback-latest','status']:actions.add_argument('--'+flag,action='store_true')
    p.add_argument('--config',default='/etc/caddy/coreoflife-realms-417.json')
    p.add_argument('--site-root',default='/opt/coreoflife-site')
    p.add_argument('--state-root',default='/var/lib/coreoflife-site/r62-rewards')
    p.add_argument('--admin',default='http://127.0.0.1:2019')
    p.add_argument('--caddy',default='caddy')
    p.add_argument('--archive',default=archive)
    args=p.parse_args(argv);config=Path(args.config).resolve();root=Path(args.site_root).resolve();state=Path(args.state_root).resolve()
    require(root!=Path('/') and state!=Path('/') and root!=state and config not in (root,state),'Unsafe output path.')
    active=current_admin(args);disk=config.read_bytes()
    require(active==json.loads(disk),'Active Caddy configuration differs from disk; pending changes were preserved.')
    latest=state/'latest.json';link=root/'current'
    if args.status:
        receipt=read_json(latest) if latest.is_file() else {}
        print(json.dumps({'installed':receipt.get('status')=='applied' and link.is_symlink() and link.resolve()==root/'releases'/receipt.get('release',''),
                          'status':receipt.get('status','not_installed'),'release':receipt.get('release'),'launchSettings':'not read or changed','adminUrl':'https://r1.coreoflife.net/admin/oyun-durumu'},ensure_ascii=False));return
    if args.check or args.apply:
        require(args.archive,'Installer archive is required.');manifest=payload(args.archive,root)
        require(link.is_symlink(),'Existing Site V2 current link is required.')
        require(link.resolve() in (root/'releases'/BASE_RELEASE,root/'releases'/manifest['release']),'An unrecognized site release is active; it was preserved.')
        require(any(any('r1.coreoflife.net' in match.get('host',[]) for match in route.get('match',[])) for server in active.get('apps',{}).get('http',{}).get('servers',{}).values() for route in server.get('routes',[])),'The existing r1 host route is required.')
        planned,server_name=transform(active,root/'current')
        with tempfile.TemporaryDirectory(prefix='col-admin-check-') as temp:
            path=Path(temp)/'caddy.json';path.write_bytes(json_bytes(planned));validate(args.caddy,path)
        print('CHECK OK: '+manifest['release']+'; admin controls preregistration and opening. No game settings will be changed.')
        if args.check:return
    require(os.geteuid()==0 or os.environ.get('COL_SITE_LOCAL_TEST')=='1','Run installation/rollback as root.')
    state.mkdir(parents=True,exist_ok=True,mode=0o700);os.chmod(state,0o700)
    # Share V2's lock; keep its receipt and original schedule backup untouched.
    with open(state.parent/'install.lock','a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        require(current_admin(args)==active and config.read_bytes()==disk,'Configuration changed during preparation; retry.')
        if args.rollback_latest:
            receipt=read_json(latest)
            require(receipt.get('kind')=='r62-rewards' and receipt.get('status') in ('applied','prepared','failed_recovery_required'),'No correction is available for rollback.')
            require(receipt.get('siteRoot')==str(root) and receipt.get('configFile')==str(config),'Rollback path mismatch.')
            backup=Path(receipt['backup']);require(backup.parent==state/'backups' and not backup.is_symlink(),'Invalid backup path.')
            before=read_json(backup/'before.json');after=read_json(backup/'after.json')
            require(active in (before,after),'Caddy changed after this correction; later changes were preserved.')
            require(link.is_symlink() and str(link.resolve()) in (receipt['previousLink'],str(root/'releases'/receipt['release'])),'The current site changed after installation.')
            require(Path(receipt['previousLink']).parent==root/'releases','Invalid previous release.')
            validate(args.caddy,backup/'before.json')
            rollback_current=str(link.resolve())
            try:
                if active!=before:api(args.admin,'/load',before)
                atomic(config,(backup/'before-file.json').read_bytes(),receipt['configMode'])
                select_link(link,receipt['previousLink'])
                require(current_admin(args)==before,'Rollback verification failed.')
            except Exception:
                if current_admin(args)!=active:api(args.admin,'/load',active)
                atomic(config,disk,receipt['configMode']);select_link(link,rollback_current);raise
            receipt['status']='rolled_back';atomic(latest,json_bytes(receipt));print('ROLLBACK OK: previous website restored. Admin settings and game data unchanged.');return
        if latest.exists():
            last=read_json(latest)
            require(last.get('status') not in ('prepared','failed_recovery_required'),'An unfinished correction requires --rollback-latest first.')
            if last.get('status')=='applied' and last.get('release')==manifest['release']:
                require(link.resolve()==root/'releases'/manifest['release'] and active==planned,'Installed site or routes differ.')
                installed_files(manifest,link.resolve());print('APPLY OK: correction already installed; admin settings unchanged.');return
        previous=str(link.resolve());release=root/'releases'/manifest['release']
        require(previous==str(root/'releases'/BASE_RELEASE),'New installation must start from Site V2.')
        extract(args.archive,manifest,release,previous,root)
        require(current_admin(args)==active and config.read_bytes()==disk and str(link.resolve())==previous,'Configuration changed while staging; no live change was made.')
        (state/'backups').mkdir(exist_ok=True,mode=0o700)
        backup=Path(tempfile.mkdtemp(prefix=time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'-',dir=state/'backups'))
        atomic(backup/'before.json',json_bytes(active));atomic(backup/'before-file.json',disk);atomic(backup/'after.json',json_bytes(planned))
        mode=config.stat().st_mode&0o777
        receipt={'kind':'r62-rewards','status':'prepared','release':manifest['release'],'siteRoot':str(root),'configFile':str(config),'configMode':mode,'backup':str(backup),'previousLink':previous,'server':server_name}
        atomic(latest,json_bytes(receipt))
        try:
            select_link(link,release)
            if planned!=active:api(args.admin,'/load',planned);atomic(config,json_bytes(planned),mode)
            require(current_admin(args)==planned,'Caddy verification failed.')
            receipt['status']='applied';atomic(latest,json_bytes(receipt))
        except BaseException as original:
            failures=[]
            try:
                if current_admin(args)!=active:api(args.admin,'/load',active)
                atomic(config,disk,mode);select_link(link,previous)
            except Exception as error:failures.append(str(error))
            receipt['status']='failed_recovery_required' if failures else 'failed_reverted';atomic(latest,json_bytes(receipt))
            if failures:raise RuntimeError(str(original)+'; recovery required: '+'; '.join(failures)) from original
            raise
        print('APPLY OK: admin-controlled preregistration installed. Admin: https://r1.coreoflife.net/admin/oyun-durumu . Game processes, accounts, launch settings and databases unchanged.')

if __name__=='__main__':
    try:main()
    except (RuntimeError,OSError,ValueError,KeyError,zipfile.BadZipFile) as error:
        print('STOP: '+str(error),file=sys.stderr);sys.exit(1)
