import {azrailLinesR62} from '../working/core511-source/scripts/core511/azrail-r62.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {BASE,SHA} from '../working/core511-source/scripts/core511/tests/helpers.mjs';
import {NativeGameServices} from '../working/core511-source/scripts/core511/game-services.mjs';
import {createTowerSchema,TOWER_DEFAULTS,TOWER_CHEST,TOWER_MATERIALS,TOWER_CATALOG} from '../working/core511-source/scripts/core511/tower-config.mjs';
import {createAdventureSchema} from '../working/core511-source/scripts/core511/adventure-schema.mjs';
process.env.COL_NATIVE_TEST_ROOT=BASE;process.env.COL_NATIVE_TEST_MANIFEST_SHA256=SHA;
const {fixture}=await import('../working/core511-source/scripts/perf-r11/tests/reward/fixture.mjs');
async function scene(t){
 const f=await fixture();t.after(()=>f.close());const sql=f.database.sqlite;createTowerSchema(sql);createAdventureSchema(sql);
 const now=Date.now(),services=new NativeGameServices(sql,{clock:()=>now}),adventure=services.globals.__colAdventure;
 sql.prepare("UPDATE players SET hp=2000,max_hp=2000,level=30,area='bazaar',x=1200,y=390,channel=1,combat_lock_until_ms=0,arena_match_id='' WHERE id='real-1'").run();
 const mutate=fn=>f.database.atomic(()=>services.run({nowMs:now,seed:'a'.repeat(64)},fn));
 return {f,sql,services,adventure,mutate,command:(action,extra={})=>mutate(()=>adventure.command('real-1',{action,requestId:randomUUID(),...extra})),amount:kind=>sql.prepare('SELECT amount FROM dungeon_materials WHERE player_id=? AND kind=?').get('real-1',kind)?.amount??0};
}

for(const flag of ['0','1'])test('Azrail actual writer: atomic contents, announcement, replay and rollback flag='+flag,async t=>{
 process.env.CORE511_R62_AZRAIL=flag;
 const s=await scene(t);s.adventure.material('real-1',TOWER_CHEST.kind,2);
 const input={requestId:randomUUID()},before=s.sql.prepare('SELECT count(*) n FROM messages').get().n;
 const result=await s.command('adventure_tower_chest',input);assert.equal(result.ok,true);assert.equal(s.amount(TOWER_CHEST.kind),1);
 assert.deepEqual(await s.command('adventure_tower_chest',input),result);assert.equal(s.amount(TOWER_CHEST.kind),1);
 const rows=s.sql.prepare("SELECT * FROM messages WHERE player_name='Sunucu' ORDER BY id").all();
 assert.equal(s.sql.prepare('SELECT count(*) n FROM messages').get().n,before+(flag==='1'?1:0));
 if(flag==='1'){const row=rows.at(-1);assert.equal(row.scope,'world');assert.equal(row.recipient_id,null);for(const reward of result.rewards)assert(row.body.includes(reward.name+' ×'+reward.amount));}
 const bag=s.services.globals.__colDungeon.materials('real-1');
 s.sql.exec("CREATE TRIGGER r62_chest_abort BEFORE INSERT ON kadim_tower_receipts BEGIN SELECT RAISE(ABORT,'r62_chest_abort'); END;");
 await assert.rejects(s.command('adventure_tower_chest'),/r62_chest_abort/);assert.deepEqual(s.services.globals.__colDungeon.materials('real-1'),bag);
 assert.equal(s.sql.prepare('SELECT count(*) n FROM messages').get().n,before+(flag==='1'?1:0));
});

test('longest valid chest contents keep every reward and fit native 140-character world chat',()=>{
 const items=[...TOWER_CATALOG].filter(x=>x.type!=='towerChest').sort((a,b)=>b.name.length-a.name.length).slice(0,16).map(x=>({name:x.name,amount:1000}));
 const lines=azrailLinesR62({name:'MuhafızMuhafızUzunA'},items);assert(lines.length>1&&lines.length<=16);assert(lines.every(x=>x.length<=140));for(const item of items)assert(lines.some(x=>x.includes(item.name+' ×1000')));
});
