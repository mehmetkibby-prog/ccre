import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash,randomUUID} from 'node:crypto';
import {nativeHttpHost} from '../working/core511-source/scripts/core511/tests/native-http-host-fixture.mjs';
import {stageNativeHttp} from '../working/core511-source/scripts/core511/tests/native-http-bundle-fixture.mjs';
import {httpActionFixture} from '../working/core511-source/scripts/core511/tests/native-http-action-fixture.mjs';
import {patchNativeBotCheck} from '../working/core511-source/scripts/core511/patch-native-bot-check.mjs';
import {BASE,until} from '../working/core511-source/scripts/core511/tests/helpers.mjs';
import {put} from '../working/core511-source/scripts/core511/tests/pvp-fixture.mjs';

const due=s=>s.f.sql.prepare('SELECT due_ms FROM bot_due WHERE account_id=?').get(s.f.account.id).due_ms;
const challenge=(s,id)=>s.f.sql.prepare('SELECT * FROM bot_challenges WHERE id=?').get(id);
async function seed(s,deadline=Date.now()+60000){
 const id=randomUUID(),answer='123456';await s.host.database.atomic(()=>{s.f.sql.prepare('UPDATE bot_due SET due_ms=? WHERE account_id=?').run(deadline,s.f.account.id);put(s.f.sql,'bot_challenges',{id,owner:s.f.account.id,purpose:'game',hash:createHash('sha256').update(id+':'+answer).digest('hex'),image:'isolated-test-challenge',expires_ms:Date.now()+60000,attempts:0});});return {id,answer};
}
const call=(s,body,headers={})=>s.module.default(s.f.request({path:'/api/bot-check',body,headers}));


for(const flag of ['0','1'])test('verification response avoids second unrelated queue wait, flag='+flag,{timeout:40000},async t=>{
 process.env.CORE511_R62_VERIFICATION=flag;
 const s=await httpActionFixture(t),input=await seed(s),check=s.core.nativeBotCheck,original=check.call.bind(check);let calls=0,release,done=false,blocking;
 const gate=new Promise(r=>release=r);
 check.call=async(...args)=>{calls++;const result=await original(...args);if(calls===1)blocking=s.core.serial(()=>gate);return result;};
 try{const result=call(s,input).finally(()=>done=true);await until(()=>!!blocking,5000);await new Promise(r=>setTimeout(r,30));assert.equal(done,flag==='1','Only flag0 waits again behind an unrelated queued operation');release();assert.equal((await result).status,200);assert.equal(calls,flag==='1'?1:2);assert.equal(challenge(s,input.id),undefined);}
 finally{release();check.call=original;await blocking;}
});
