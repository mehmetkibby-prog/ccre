import test from 'node:test';import assert from 'node:assert/strict';import {randomUUID} from 'node:crypto';
import {httpActionFixture} from '../working/core511-source/scripts/core511/tests/native-http-action-fixture.mjs';
import {extraPlayer} from '../working/core511-source/scripts/core511/tests/process-fixture.mjs';
const MOUNT_RECIPE=[{kind:'tower_azrail_chest'}];
import {applyWorldDelta} from '../working/native510-bb3a6cc689c6/lib/world-push.mjs';
import {until} from '../working/core511-source/scripts/core511/tests/helpers.mjs';
test('real native market: list, cancel, buy and replay preserve Azrail chest balances',async t=>{
 const s=await httpActionFixture(t),{f,core}=s,buyer=extraPlayer(s,60);
 await s.host.database.atomic(()=>globalThis.__colLaunch.grant('shared-account-60',true));
 let ticket=await buyer.http();assert.equal(ticket.status,200,JSON.stringify(ticket));if(ticket.channel!==1)ticket=await buyer.http('transfer',{channel:1});assert.equal(ticket.channel,1);const buyerLive=await s.connect(ticket);
 const token='shared-native-session-'+String(60).repeat(40).slice(0,80),csrf='shared-native-csrf-'+String(60).repeat(40).slice(0,80);
 const instance=f.sql.prepare("SELECT instance_id FROM game_presence WHERE account_id='shared-account-60'").get().instance_id;
 const call=async(body,other=false,expected=200)=>{
  const headers=other?{Cookie:'__Host-yasam-session='+token+'; __Host-yasam-csrf='+csrf,'X-CSRF-Token':csrf,'X-Game-Instance':instance}:{};
  const response=await s.module.default(f.request({path:'/api/action',body,headers})),value=await response.json();if(response.status!==expected)console.log('market_failure',JSON.stringify({body,other,value,players:f.sql.prepare('SELECT id,area,channel,hp,gems,x,y FROM players WHERE id IN(?,?)').all(f.id,buyer.id),shops:f.sql.prepare('SELECT id,channel,active FROM market_shops').all(),listings:f.sql.prepare('SELECT id,seller_id,item_id,amount,price_gems FROM market_listings').all(),settlements:f.sql.prepare('SELECT id,listing_id,settlement_type,buyer_id,applied_at_ms FROM market_settlements').all()}));assert.equal(response.status,expected,JSON.stringify(value));return value;
 };
 await core.permanentPlayers([f.id,buyer.id],()=>{
  f.sql.prepare("UPDATE players SET area='bazaar',hp=max_hp,gems=10000,level=40,combat_lock_until_ms=0,x=650,y=1060 WHERE id IN(?,?)").run(f.id,buyer.id);
  for(const r of MOUNT_RECIPE)f.sql.prepare('INSERT INTO dungeon_materials VALUES(?,?,100)').run(f.id,r.kind);
 });
 await call({action:'create_shop',shopName:'R60 materials'});
 const amount=(id,kind)=>f.sql.prepare('SELECT amount FROM dungeon_materials WHERE player_id=? AND kind=?').get(id,kind)?.amount??0;
 for(const {kind} of MOUNT_RECIPE){
  await call({action:'create_shop',shopName:'R60 materials'});
  const body={action:'create_listing',listingKind:'dungeon_material',materialKind:kind,amount:20,price:30,requestId:randomUUID()},listed=await call(body);
  assert.equal(amount(f.id,kind),80);assert.equal((await call(body)).listingId,listed.listingId);assert.equal(amount(f.id,kind),80);
  const cancelled={action:'cancel_listing',listingId:listed.listingId,requestId:randomUUID()};await call(cancelled);await call(cancelled);assert.equal(amount(f.id,kind),100);
  await call({action:'create_shop',shopName:'R60 materials'});
  const sale=await call({...body,requestId:randomUUID()});
  const buy={action:'buy_listing',listingId:sale.listingId,requestId:randomUUID()};await call(buy,true);await call(buy,true);
  assert.equal(amount(f.id,kind),80);assert.equal(amount(buyer.id,kind),20);
  assert.equal(f.sql.prepare('SELECT count(*) n FROM market_settlements WHERE listing_id=?').get(sale.listingId).n,1);
 }
 let applied=0,bag=null;const current=()=>{for(const packet of s.live.packets.slice(applied)){if(packet.world?.type==='world_snapshot')bag=packet.world.data;else if(packet.world?.type==='world_delta')bag=applyWorldDelta(bag,packet.world);}applied=s.live.packets.length;return bag;};
 await until(()=>MOUNT_RECIPE.every(({kind})=>current()?.dungeonMaterials?.find(r=>r.kind===kind)?.amount===80),5000);
 for(const {kind} of MOUNT_RECIPE)assert.equal(bag.dungeonMaterials.find(r=>r.kind===kind).amount,80);
 assert.equal(f.sql.prepare('SELECT gems FROM players WHERE id=?').get(buyer.id).gems,9970);
 assert.equal(f.sql.prepare('SELECT gems FROM players WHERE id=?').get(f.id).gems,10030);
 // A committed chest message must reach an idle second player via the native world-chat outbox.
 s.live.ws.send(JSON.stringify({type:'input',sequence:1,payload:{action:'adventure_tower_chest',requestId:randomUUID()}}));
 const isChest=p=>p.type==='event'&&p.payload?.event?.type==='chat_message'&&p.payload.event.message.player_name==='Sunucu'&&p.payload.event.message.body.includes('Azrail Sandığı');
 await until(()=>buyerLive.packets.some(isChest)&&s.live.packets.some(isChest),7000);
 const events=buyerLive.packets.filter(isChest);assert(events.length>=1);for(const e of events)assert(e.payload.event.message.body.length<=140);
 assert.equal(core.permanent.entries.size,0);assert.deepEqual(s.faults,[]);
});
