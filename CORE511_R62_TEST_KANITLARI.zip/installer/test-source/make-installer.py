from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[1];P=R.parent/'r62_polish_work';A=R/'artifacts';sha=lambda b:hashlib.sha256(b).hexdigest()
s=(P/'packaging-r62/combined.py').read_text().replace('CORE_OF_LIFE_R62.zip','CORE511_R62.zip')
s=s.replace("(('game','GAME_R62.zip'),('site','SITE_R62.zip'))", "(('game','GAME_R62.zip'),('site','SITE_R62.zip'),('proof','CORE511_R46.zip'))")
a="  prior=Path(archive or sys.argv[0]).resolve().with_name('CORE511_R46.zip')\n  if prior.is_file() and '--base-package' not in args:paths['game'].extend(['--base-package',str(prior)])"
b="  if '--base-package' not in args:paths['game'].extend(['--base-package',paths['proof'][1]])"
assert a in s;s=s.replace(a,b);assert "('proof','CORE511_R46.zip')" in s
(R/'build/combined.py').write_text(s)
entries={'__main__.py':s.encode(),'GAME_R62.zip':(P/'candidate/CORE511_R62_POLISH_TEST.zip').read_bytes(),'SITE_R62.zip':(P/'site/CORE_OF_LIFE_ONKAYIT_DUZELTME.zip').read_bytes(),'CORE511_R46.zip':(R.parent/'r55_gameplay_work/input/CORE511_R46.zip').read_bytes()}
assert sha(entries['CORE511_R46.zip'])=='183db8524aa9e17714e9d7bf8331f5f33eaf546af070380f49402cc7b1caa80f'
for name in ['KURULUM.md','TESLIM.md','TEST_SONUCLARI.md','DEGISIKLIKLER.md']:
 if (A/name).exists():entries[name]=(A/name).read_bytes()
meta={'version':'R62','kind':'standalone-review-handoff','sourceCore':'1957760ba0a499db494d7a06daee6cedd925c77704cca6baedbf837c35b7def4','baseGame':'R61','baseSite':'20261026-4385eb249bd8','embeddedReadOnlyProof':'CORE511_R46.zip','liveDeployment':False,'acceptance':'See TEST_SONUCLARI.md; review package is not a claim that all load acceptance tests passed.','files':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in entries.items()}}
entries['BUNDLE.json']=(json.dumps(meta,indent=2,ensure_ascii=False)+'\n').encode()
out=A/'CORE511_R62.zip'
with zipfile.ZipFile(out,'w') as z:
 for name,data in sorted(entries.items()):
  info=zipfile.ZipInfo(name,date_time=(2026,10,26,0,0,0));info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_STORED if name.endswith('.zip') else zipfile.ZIP_DEFLATED;z.writestr(info,data)
with zipfile.ZipFile(out) as z:assert z.testzip() is None
out.with_suffix('.zip.sha256').write_text(sha(out.read_bytes())+'  '+out.name+'\n');print(out, out.stat().st_size,sha(out.read_bytes()))
