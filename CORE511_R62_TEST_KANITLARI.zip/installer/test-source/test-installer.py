from pathlib import Path
import importlib.util,unittest,json,zipfile,hashlib,tempfile,sys,io,contextlib,subprocess
from unittest.mock import patch
R=Path(__file__).resolve().parents[1];P=R.parent/'r62_polish_work';E=R/'installer-evidence';E.mkdir(exist_ok=True)
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
wrapper=module('handoff_wrapper',R/'build/combined.py');base=module('r62_prior_installer',P/'tests-r62/installer-test.py')
# Reuse the previously verified fixture definition; keep this run's logs separate.
base.E=E
class Standalone(base.Installer):
 def run_main(self,*args):
  if '--base-package' in args:raise AssertionError('test must not supply an external base archive')
  outer=self;out=io.StringIO();original=wrapper.workflow
  def dispatch(game,site,argv):
   def run(command):
    outer.assertIn('--base-package',command)
    proof=Path(command[command.index('--base-package')+1]);outer.assertTrue(proof.is_file());outer.assertNotEqual(proof.parent,outer.dir)
    with zipfile.ZipFile(R/'artifacts/CORE511_R62.zip') as z:outer.assertEqual(proof.read_bytes(),z.read('CORE511_R46.zip'))
    with patch.object(sys,'argv',command[1:]):base.m.main()
    return ''
   return original(game,site,argv,run=run)
  with patch.object(wrapper,'workflow',side_effect=dispatch),contextlib.redirect_stdout(out),contextlib.redirect_stderr(out):wrapper.main(R/'artifacts/CORE511_R62.zip',['--game-only',*args])
  with (E/'standalone-installer.log').open('a') as f:f.write('\n$ '+' '.join(args)+'\n'+out.getvalue())
  return out.getvalue()
 def test_roundtrip_failure_recovery_flags_and_current_database(self):
  self.build_r56_fixture();(self.dir/'CORE511_R46.zip').unlink();before=self.snapshot();db_inode=self.db.stat().st_ino;startup=self.loaded_startup
  self.run_main('--check');self.assertEqual(self.snapshot(),before);self.assertEqual(self.actions,[])
  self.run_main('--apply');self.assertEqual(self.actions,['stop','start']);self.actions.clear()
  self.run_main('--check');self.assertEqual(self.actions,[])
  self.assertIn('CORE511_R62_AZRAIL',self.run_main('--flags'))
  for value in ('0','1'):
   self.run_main(*sum((['--set-flag',flag+'='+value] for flag in self.spec['newFlags']),[]))
  self.assertEqual(self.startup.read_bytes(),startup)
  import sqlite3
  with contextlib.closing(sqlite3.connect(self.db)) as db:
   db.execute("UPDATE players SET gems=gems+123 WHERE id='real-1'");db.commit()
  current=self.db.read_bytes();self.run_main('--rollback-latest');self.assertEqual(self.snapshot(),before);self.assertEqual(self.db.stat().st_ino,db_inode);self.assertEqual(self.db.read_bytes(),current)
  with zipfile.ZipFile(R/'artifacts/CORE511_R62.zip') as z:hashes={n:hashlib.sha256(z.read(n)).hexdigest() for n in ['__main__.py','GAME_R62.zip','SITE_R62.zip','CORE511_R46.zip']}
  (E/'standalone-installer.json').write_text(json.dumps({'status':'PASS','componentHashes':hashes,'sourceCore':self.spec['afterCore'],'checks':['no external proof archive present','bundled proof passed through wrapper','real game check/apply','flags/all four off/on','existing R61 startup preserved','rollback preserves current SQLite bytes and inode'],'rootSimulatedByFakeroot':True,'serviceHealthMocked':True,'websiteInstaller':'previous unchanged component tests; wrapper game-only exercised here','liveDeployment':False},indent=2)+'\n')
class Integrity(unittest.TestCase):
 def test_all_three_inner_payloads_verified_before_workflow(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'test.zip';payload={'GAME_R62.zip':b'game','SITE_R62.zip':b'site','CORE511_R46.zip':b'proof'};meta={'files':{n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in payload.items()}}
   for corrupt in [None,*payload]:
    with zipfile.ZipFile(p,'w') as z:
     z.writestr('BUNDLE.json',json.dumps(meta))
     for n,b in payload.items():z.writestr(n,b+b'bad' if n==corrupt else b)
    def inspect(game,site,args):
     self.assertEqual(Path(game[1]).read_bytes(),b'game');self.assertEqual(Path(site[1]).read_bytes(),b'site');self.assertEqual(game[-2],'--base-package');self.assertEqual(Path(game[-1]).read_bytes(),b'proof')
    with patch.object(wrapper,'workflow',side_effect=inspect) as call:
     if corrupt:
      with self.assertRaisesRegex(ValueError,'bütünlüğü'):wrapper.main(p,['--apply'])
      call.assert_not_called()
     else:wrapper.main(p,['--check']);call.assert_called_once()
if __name__=='__main__':unittest.main(verbosity=2)
