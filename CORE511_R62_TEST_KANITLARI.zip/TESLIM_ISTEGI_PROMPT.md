TESLİM İSTEĞİ — Claude bağımsız doğrulama yapacak (canlıda R61 kurulu)

Kurulum/geri alma/anahtar kontrollerini bitirince paketi şu şekilde teslim et. Claude’da R57–R61 paketleri yok;
eski sürümleri ayrıca istemiyoruz. Bu yüzden teslim TEK BAŞINA çalıştırılabilir olmalı:

1) KURULUM PAKETİ
   - CORE511_R62.zip (canlıdaki R61 üzerine --check / --apply / --flags / --set-flag / --rollback-latest) + .sha256.
   - KURULUM.md: canlıda R61 olduğuna göre adım adım komutlar (bakım, --check, --apply, oyunu açma, geri alma).

2) TAM KAYNAK AĞACI (en önemlisi)
   - Yeni sürümün TAMAMI, delta değil: core511-source/ ve native510 ağacı, package.json/kilitli bağımlılık bilgisi,
     testlerin kullandığı fixture'lar ve sürücü dahil. Claude bu zip'i boş bir klasöre açıp R61 olmadan
     yük testini çalıştırabilmeli.
   - Ayrıca aynı içerikte R61 kaynak ağacı da (yalnız R61, daha eskisi değil) — Claude R61 ile yeni sürümü
     aynı makinede yan yana ölçecek. Boyut büyükse iki ayrı zip olabilir.
   - Her iki ağacın kaynak SHA'sı (sourceCore) ve R61→yeni diff.

3) TEST SÜRÜCÜSÜ VE KOMUTLAR
   - Kullandığın my-load-real.mjs sürümü ve 30/50/70/100 oyuncu koşularının BİREBİR komutları
     (bütün CORE_* ve CORE511_* ortam değişkenleri, anahtar profili .env dosyası, süre, CORE_MONSTER_POOL vb.).
   - Bu komutların ham sonuç dosyaları (result.json) ve özet tablo: hareket, ilk saldırı, iksir, ödül talebi,
     ganimet, kalıcı ölüm/ödül p50/p95/p99; kopma, cevapsız istek, yarım ödül, çift anahtar.

4) ÇÖKME TESTİ (geçmişte 4 kanalı kapatan senaryo — teslimden önce 3 koşu çalıştır ve sonucu ekle)
   CORE_SCENARIO=real CORE_PARTY=1 CORE_AOE=1 CORE_COLLECT=1 CORE_BAGFILL=35 CORE_COLLECT_RETRY=1 RC_SHARED=1
   CORE_PER=20 CORE_MS=50000 CORE_MON_HP=500 CORE_CLAIM_CAP=1 CORE_GEAR_AT=15000 CORE_POKE_AT=25000 CORE_HIT_N=3
   CORE_RELOGIN=1 CORE_RELOGIN_RETRY=60000
   Kabul: CHILD_EXIT 0, dört kanal incarnation sabit, 24/24 tekrar giriş + hareket, yarım ödül 0, çift anahtar 0.
   Ayrıca aynı komut GEAR/POKE/RELOGIN olmadan (düz yoğun öldürme) 2 koşu.

5) DEĞİŞİKLİK ÖZETİ
   - R61→yeni: değişen dosyalar, yeni anahtarlar ve varsayılanları (kaynakta ve kurulum profilinde ayrı ayrı),
     kapatınca hangi davranışa dönüldüğü, bilinen sınırlar.

Canlıya kurma; Claude test edip karar verecek.
