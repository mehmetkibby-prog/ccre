from pathlib import Path
import importlib.util,os,json,subprocess,hashlib,datetime,signal,argparse,shutil
R=Path(__file__).resolve().parents[1];parser=argparse.ArgumentParser();parser.add_argument('--tree',type=Path);parser.add_argument('--out',type=Path);args=parser.parse_args();tree=(args.tree or Path((R/'extracted-root.txt').read_text().strip())/'R61').resolve();out=(args.out or R/'test-evidence/R61/plain-diagnostic').resolve()
spec=importlib.util.spec_from_file_location('source_runner',tree/'validation/run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
meta=m.read(tree/'SOURCE.json');assert m.core_identity()==meta['sourceCore'];out.mkdir(parents=True,exist_ok=False)
helper_dir=tree/'validation/extra-backlog-observer';helper_dir.mkdir(exist_ok=True)
for name in ('register.mjs','backlog-loader.mjs'):shutil.copy2(Path(__file__).parent/name,helper_dir/name)
settings={**m.assignments(tree/'profiles/features.env'),**m.assignments(tree/'profiles/plain.env'),'COL_CLOUD_ISOLATED_FIXTURE':'1','R35_CORE_REGRESSION':'1','CORE511_R40_BAG_LIMIT':'1','COL_TEST_ACORN_MODULE':str(tree/'working/deps/build/node_modules/acorn/dist/acorn.mjs'),'COL_CORE511_SCOPE_MODULE':str(tree/'working/deps/build/node_modules/eslint-scope'),'CORE511_LOCAL_REPRO_AUTHORIZED':'1','COL_HANDOFF_PLAYERS':'80','CORE_PER':'20','CORE_MS':'50000','CORE_OUT':str(out/'result.json'),'NODE_OPTIONS':'--no-warnings --import '+str(tree/'validation/register.mjs')+' --import '+str(tree/'tests-r57/observe-full-rewards.mjs')+' --import '+str(helper_dir/'register.mjs')}
env={k:v for k,v in os.environ.items() if not k.startswith(('CORE_','CORE511_','COL_','R35_','R43_','R47_','R51_','R57_','R61_')) and k!='NODE_OPTIONS'};env.update(settings)
command=[str(tree/'runtime/node-v22.22.0-linux-x64/bin/node'),'--no-lazy',str(tree/'working/core511-source/scripts/core511/benchmark/my-load-real.mjs')]
proof={'sourceCore':meta['sourceCore'],'version':'R61','purpose':'Same plain case as R62, plus additional post-result observation and draining already queued client claims. Standard raw acceptance remains unchanged.','environment':settings,'command':command,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'helperSHA256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.iterdir() if p.is_file()}}
(out/'source.json').write_text(json.dumps(proof,indent=2)+'\n');print('START R61 additional backlog diagnostic',flush=True)
with (out/'run.log').open('w') as f:
 child=subprocess.Popen(command,cwd=tree,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=child.wait(timeout=300)
 except BaseException:os.killpg(child.pid,signal.SIGKILL);raise
proof.update(exitCode=code,sourceUnchanged=m.core_identity()==meta['sourceCore'],finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());(out/'source.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(m.read(out/'result.backlog-diagnostic.json')),flush=True)
