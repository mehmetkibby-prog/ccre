# Ek R61 ödül kuyruğu kontrolü

Bu kontrol, kullanıcının “önceki testlerde bu sorun yoktu, şimdi ne oldu?” sorusu üzerine eklendi. Zorunlu üç R62 crash ve iki R62 plain koşusunun yerine geçmez. O koşuların FAIL kayıtları aynen korunur.

R61'in aynı 80 oyuncu / 50 saniye / oyuncu başına 60 canavar plain senaryosunu çalıştırır. Standart result.json ve acceptance dosyası kaydedildikten SONRA:

1. Botların henüz gönderemediği c.claim / c.claimRest hedeflerini sayar, bitmemiş SQL kayıtlarıyla eşleştirir.
2. Yeni saldırı/talep göndermeden 15 saniye bekler ve yeniden sayar.
3. Yalnız bu mevcut kuyruktaki ödül taleplerini normal istemci protokolünden, 10 hedeflik gruplar halinde yollar. Doğrudan SQL yazmaz, ödülü idari olarak tamamlamaz, yeni saldırı oluşturmaz. Bu ek aşama için toplam üst sınır 75 saniyedir (15 saniye bekleme dahil).
4. Son sayımları result.backlog-diagnostic.json dosyasına yazar. Asıl koşunun sonucu değiştirilmez.

Kaynak ZIP'lerini açtıktan ve bu kanıt ZIP'indeki diagnostics klasörüne eriştikten sonra:

```bash
python3 diagnostics/run.py --tree /mutlak/yol/R61 --out /mutlak/yol/yeni-r61-tani
```

Dosyalarda test adaptörü ve tersine dönüş kanıtı bulunur. Kaynak oyun kodu değişmez. Bu tanı, bütün bekleyen ödüllerin mutlaka tamamlandığı varsayımıyla yazılmadı; önce/sonra sayıları gerçek sonuca göre değerlendirilmelidir. Standart p95 sonuçlarına bu ek bekleme/drain aşaması karıştırılmaz.
