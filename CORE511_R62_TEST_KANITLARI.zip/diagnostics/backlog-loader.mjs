// Additional diagnostic only, after the standard result has already been saved.
// Does not rewrite production modules or turn a failed standard case into PASS.
import fs from 'node:fs';import {createHash} from 'node:crypto';
const sha=s=>createHash('sha256').update(s).digest('hex');
export async function load(url,context,next){
 const result=await next(url,context);if(!url.endsWith('/benchmark/my-load-real.mjs'))return result;
 const original=String(result.source),anchor='fs.writeFileSync(OUT,JSON.stringify(out,null,1));';
 if(original.split(anchor).length!==2)throw Error('backlog_diagnostic_anchor');
 const extra=`
 ;try{
  const backlogStart=performance.now(),deadline=backlogStart+75000;
  const pendingQ=sql.prepare('SELECT COUNT(*) n FROM normal_defeats WHERE rewards_completed_at=0'),targetQ=sql.prepare('SELECT rewards_completed_at FROM normal_defeats WHERE monster_id=? AND spawn_round=?');
  const queues=clients.map(c=>({c,targets:[...(c.claim??[]),...(c.claimRest??[])]}));
  const snapshot=()=>({elapsedMs:performance.now()-backlogStart,unfinishedRewards:pendingQ.get().n,clientQueuedTargets:queues.reduce((n,q)=>n+q.targets.length,0),uniqueUnfinishedQueuedTargets:new Set(queues.flatMap(q=>q.targets.filter(t=>targetQ.get(t.id,t.spawnRound)?.rewards_completed_at===0).map(t=>t.id+':'+t.spawnRound))).size});
  const diagnostic={purpose:'Original plain-case acceptance is saved unchanged before this diagnostic. Observe idle drain, then send only client claims that the original timer left unsent; no attacks or SQL writes.',before:snapshot(),records:[],failures:[]};
  await pause(15000);diagnostic.afterIdle15s=snapshot();
  await Promise.all([1,2,3,4].map(async channel=>{
   for(const q of queues.filter(q=>q.c.p.channel===channel))while(q.targets.length&&performance.now()<deadline){
    if(q.c.ws.readyState!==1){diagnostic.failures.push({channel,actor:q.c.p.id,reason:'socket_closed'});break;}
    while(!q.c.protocol.canSend()&&performance.now()<deadline)await pause(10);if(performance.now()>=deadline)break;
    const targets=q.targets.splice(0,10);try{send(q.c,{action:'claim_rewards',rewardTargets:targets});await settled(q.c,10000);diagnostic.records.push({channel,actor:q.c.p.id,targets:targets.length});}
    catch(error){diagnostic.failures.push({channel,actor:q.c.p.id,reason:error.message});break;}
   }
  }));
  diagnostic.afterClientClaims=snapshot();diagnostic.claimFail=claimFail;diagnostic.claimProcessed=claimProcessed;diagnostic.noNewCombatInputs=true;
  fs.writeFileSync(OUT.replace(/\\.json$/,'.backlog-diagnostic.json'),JSON.stringify(diagnostic,null,2));
 }catch(error){fs.writeFileSync(OUT.replace(/\\.json$/,'.backlog-diagnostic.json'),JSON.stringify({diagnosticError:error.message}));}
 `;
 const changed=original.replace(anchor,anchor+extra);if(changed.replace(anchor+extra,anchor)!==original)throw Error('backlog_inverse');
 fs.writeFileSync(process.env.CORE_OUT+'.diagnostic-loader-proof.json',JSON.stringify({originalLoadedSHA256:sha(original),diagnosticLoadedSHA256:sha(changed),inverseEqual:true,edit:{from:anchor,to:anchor+extra}},null,2));return {...result,source:changed};
}
