import {register} from 'node:module';register(new URL('./backlog-loader.mjs',import.meta.url));
