# Bağımsız R61 / R62 yük testi

Gereken: Linux x86_64, glibc >= 2.28, Python 3.10+, yaklaşık 2 GB boş disk. Node 22.22.0 ve kilitli npm bağımlılıkları dahildir; npm install veya eski oyun paketi gerekmez. Testi canlı oyun sunucusunda çalıştırmayın. Test geçici SQLite veritabanını, hesapları ve dört kanal sürecini kendisi oluşturur.

ZIP'i boş bir klasöre açıp sürüm klasörüne girin:

```bash
python3 validation/run.py verify
python3 validation/run.py matrix --players 30
python3 validation/run.py matrix --players 50
python3 validation/run.py matrix --players 70
python3 validation/run.py matrix --players 100
```

Her komut ayrı ve sırayla çalıştırılır. Ölçüm 60 saniyedir; kurulum, hesap bağlantıları ve kapanış bu sürenin dışındadır. Tekrar için `--repeat 2` kullanın. Sonuçlar `evidence/matrix-30-1` gibi ayrı klasörlere yazılır; var olan kanıtın üzerine yazılmaz. `--dry-run` bütün ortam değişkenlerini içeren doğrudan Node komutunu gösterir. Her gerçek çalıştırmada `command.sh` ve `source.json` aynı komutu ve ortamı kaydeder. Kaydedilmiş komutlardaki mutlak yolu başka makineye taşırken runner kullanın; runner yeni yolu kendisi üretir ve dışarıdan gelen CORE_* ayarlarını temizler.

İstenen çökme ve düz yoğun öldürme testleri:

```bash
python3 validation/run.py crash --repeat 1
python3 validation/run.py crash --repeat 2
python3 validation/run.py crash --repeat 3
python3 validation/run.py plain --repeat 1
python3 validation/run.py plain --repeat 2
```

Bunlar 80 oyuncu (kanal başına 20), 50 saniye; çökme testinde 15. saniyede ekipman, 25. saniyede HP değişimi, ardından 24 hesabın yeniden girişi ve hareketidir. `profiles/crash.env`, `plain.env`, `matrix.env` iş yükünü; `profiles/features.env` tüm seçili oyun anahtarlarını içerir. Crash/plain için CORE_MONSTER_POOL TANIMLI DEĞİLDİR: sürücünün varsayılanı oyuncu başına 60 canavar, toplam 4.800'dür. Matrix için CORE_MONSTER_POOL=channel ve CORE_MONS=60: dört kanal toplam 240 canavar. Bu iki yükün gecikmeleri aynı iş yüküymüş gibi karşılaştırılamaz. Matrix'te tüm oyuncular savaşır; crash/plain sürücü varsayılanı %60'tır.

`working/core511-source/` ilgili sürümün bütün mevcut kaynak ağacıdır; `working/native510-bb3a6cc689c6/` mevcut native kaynak dışa aktarımıdır. İkisi delta değildir. SOURCE.json sourceCore kimliğini; FILES.sha256 paketlenen bütün dosyaları doğrular. Kök package.json/lock test geliştirme bağımlılıklarını, native içindeki package.json/lock native bağımlılıklarını gösterir. Çalışma zamanı node_modules dahil edilmiştir.

Önemli kapsam sınırı: eldeki native dışa aktarımı eski üretim manifestinin bütün medya/derlenmiş web dosyalarını içermiyor. NATIVE_EXPORT.json eksik her yolu/boyutu açıkça listeler. Bu bir sıfırdan canlı VDS kurulumu ya da bütün oyun medya arşivi değildir. Bağımsız yük testi için gereken kaynak, bağımlılık ve fixture dosyaları dahildir. Eksik derlenmiş lonca modülü yerine aynı native TypeScript kodunun test kopyası; eksik .d.mts bildirimleri ve güvenli, ayarsız /etc sahipliği için açık test adaptörleri kullanılır. Mevcut native dosyaların SHA kontrolleri korunur. Canlı DB, parola ve yapılandırma dahil değildir.

`validation/portable-loader.mjs` eski mutlak test bağımlılığı yollarını bu ZIP'in içine yönlendirir; 30/50/70 oyuncuyu dört kanala dengeli dağıtır, tam incarnation ve kapanış kanıtını ekler. Üretim oyun kaynaklarını değiştirmez. `result.json.driver-proof.json` yüklenen sürücü değişikliklerini ve tersine dönüş SHA kanıtını içerir. `benchmark/my-load-real.mjs` her iki sürümde kullanılan özgün dosyadır. Gözlemci `tests-r57/observe-full-rewards.mjs` bütün ödüllerin SQL ve durability onayını takip eder. Test-only native fixture zinciri de pakettedir. Eski kaynak ağacındaki her tarihsel testin taşınabilir olduğu iddia edilmez; bu belgede verilen runner taşınabilirdir.

Sonuç değerlendirmesi: p50/p95/p99 ms cinsindedir. İlk saldırı yanıtı geçici 202 olabilir; kalıcı ölüm veya bütün ödüllerin bitişi değildir. Kalıcı ölüm + tüm ödüller ayrı ölçülür. Örnek sayısı sıfırsa gecikme ölçülmemiştir. Testte süreç, SQL ve yerel WebSocket/IPC gerçek; internet/VDS gecikmesi ölçülmez. Crash testinde etkilenen eski oturumların kopması ham sayılır; kullanıcı kabulü CHILD_EXIT=0, dört tam incarnation sabit, 24/24 yeniden giriş+hareket, yarım ödül=0, çift anahtar=0'dır. Runner buna ek olarak hata, cevapsız istek ve temiz kapanışı da kontrol eder. FAIL çıktısı ve çıkış kodu 1 başarısızlığı gizlemez.
