from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent.parent
manifest=json.loads((ROOT/'BUILD.json').read_text())
out=ROOT/'CORE_OF_LIFE_ONKAYIT_DUZELTME.zip'
main='import os,sys\nfrom site_install import main\ntry:\n    main(archive=os.path.abspath(sys.argv[0]))\nexcept Exception as error:\n    print("STOP: "+str(error),file=sys.stderr)\n    sys.exit(1)\n'
entries={'__main__.py':main.encode(),'site_install.py':(ROOT/'package/site_install.py').read_bytes(),'BUILD.json':(ROOT/'BUILD.json').read_bytes()}
for name,meta in manifest['files'].items():
    if 'basePath' not in meta:entries['site/'+name]=(ROOT/'dist'/name).read_bytes()
for name in ['KURULUM.md','SONUC.md']:
    if (ROOT/name).is_file():entries[name]=(ROOT/name).read_bytes()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(entries.items()):
        info=zipfile.ZipInfo(name,date_time=(2026,10,26,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
digest=hashlib.sha256(out.read_bytes()).hexdigest()
(ROOT/'SHA256.txt').write_text(digest+'  '+out.name+'\n')
print(json.dumps({'file':str(out),'bytes':out.stat().st_size,'sha256':digest,'release':manifest['release']}))
