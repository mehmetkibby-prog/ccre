import test from 'node:test';import assert from 'node:assert/strict';
import {OperationRandom} from '../working/core511-source/scripts/core511/operation-random.mjs';
import {planSingleDeathsR57} from '../working/core511-source/scripts/core511/death-batch-single-r57.mjs';
import {AttackLoop} from '../working/core511-source/scripts/core511/attack-loop.mjs';
import {attackSeedR57,reserveAttackSeedR57} from '../working/core511-source/scripts/core511/planned-attack-seed-r57.mjs';
const enabled=process.env.CORE511_R57_DEATH_BATCH==='1';
test('a rejected lethal preview keeps its random rolls when retried and later executed alone',()=>{
 const original=OperationRandom.seed;let calls=0;OperationRandom.seed=()=>String(++calls).padStart(64,'0');
 try{
  const input={action:'attack',ability:0,targetId:'m1'},head={order:2,at:2,kind:'combat',sequence:1,receivedAtMs:1000,payload:input},players=new Map([['p0',{epoch:1,queue:[]}],['p1',{epoch:1,queue:[head]}]]),draws=[];
  const state={channel:1,assertOwner:()=>{}},kernel={players,state,metrics:{}},row=id=>({id,area:'forest',channel:1});
  const channel={kernel,state,view:{player:row},identities:new Map([['p1',{}]]),checkpoints:{overdueR53:()=>false},retaliationMemory:{due:()=>[]},ports:{guard:()=>true},frames:{attack:()=>({})},attackMemory:{plan:(_,rng)=>{draws.push([rng.random(),rng.random()]);return {durable:false};}}};
  const runtime={channel,forceSharedActors:new Map(),localResident:()=>true,localKill:()=>null},local={ids:['p0','p1'],targets:[{id:'m0',spawnRound:1}]};
  for(let i=0;i<2;i++)assert.equal(planSingleDeathsR57(runtime,{id:'p0',inputOrder:1,now:1000,kernel},local),null);
  assert.equal(players.get('p1').queue[0],head);
  const memory={step:(_,rng)=>{draws.push([rng.random(),rng.random()]);return {durable:false,events:[],result:{status:200}};}},noop=()=>{};
  const loop=new AttackLoop({memory,lanes:{busy:()=>false},submit:noop,frameFor:()=>({playerId:'p1',player:row('p1')}),affectedActors:noop,committed:noop,publish:noop});
  assert.equal(loop.attack({id:'p1',epoch:1,input,inputOrder:2,now:1000,kernel}).status,200);
  if(enabled){assert.equal(draws.length,3);assert.deepEqual(draws[1],draws[0]);assert.deepEqual(draws[2],draws[0]);assert.equal(calls,1);}
  else{assert.equal(draws.length,1);assert.equal(calls,1);}
 }finally{OperationRandom.seed=original;}
});
test('speculative seed binds input identity, actor, epoch and accepted order; client seed is ignored',()=>{
 const context={id:'p',epoch:1,inputOrder:1,input:{action:'attack',seed:'client-chosen'}};
 const seed=reserveAttackSeedR57(context);assert.match(seed,/^[a-f0-9]{64}$/);
 if(enabled)assert.equal(attackSeedR57(context),seed);else assert.notEqual(attackSeedR57(context),seed);
 for(const change of [{id:'q'},{epoch:2},{inputOrder:2},{inputOrder:NaN},{input:{...context.input}},{input:{action:'use_potion'}}])assert.notEqual(attackSeedR57({...context,...change}),seed);
 if(enabled)assert.equal(attackSeedR57(context),seed);
 const next={...context,inputOrder:2};const nextSeed=reserveAttackSeedR57(next);assert.notEqual(nextSeed,seed);if(enabled)assert.equal(attackSeedR57(next),nextSeed);
});
