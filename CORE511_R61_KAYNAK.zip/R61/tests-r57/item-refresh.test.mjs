import test from 'node:test';import assert from 'node:assert/strict';
import {refreshItemSectionsR57} from '../working/core511-source/scripts/core511/item-refresh-r57.mjs';
import {writeReceipt,replayValue} from '../working/core511-source/scripts/core511/compact-receipt.mjs';
function fixture(count=25){
 const rows=new Map(),owners=new Map(),players=new Map(),subscribers=new Map(),frames=new Map(),mutations=[];
 const result={result:{status:200},players:[],monsters:[],sharedRefresh:{version:1,all:false,tables:['players','world_drops'],actors:[]},actorSectionsR52:{version:1,cycle:1,readSections:true,readDrops:true,actor:'p0',actors:[]},engagement:null};
 for(let i=0;i<count;i++){
  const id='p'+i,row={id,area:'forest',channel:1,arena_match_id:'',hp:100,max_hp:100,hp_revision:1,level:40,xp:0,last_seen:1},owner={epoch:2,channel:1,incarnation:'boot'};
  rows.set(id,row);owners.set(id,owner);players.set(id,{epoch:2,barrier:{}});frames.set(id,{valid:true});
  subscribers.set(id,{ownerRow:{...row},data:{area:row.area,channel:1,players:[{...row}],inventory:[],drops:[]},revision:1});
  result.players.push({...row,xp:10});result.sharedRefresh.actors.push(id);result.actorSectionsR52.actors.push({id,owner:{...owner},engagementRef:{kind:i===0?'ack-attack':'resident'}});
 }
 const channel={world:{cycle:1},owners,kernel:{players},frames:{entries:frames},lanes:{busy:()=>true},state:{assertOwner:()=>{}},presence:{merge:row=>row},view:{player:id=>rows.get(id),engagements:new Map(),setPlayer:row=>{mutations.push(row.id);rows.set(row.id,row);},setEngagement:()=>{}},setMonster:m=>mutations.push(m.id)};
 const runtime={channel,world:{subscribers},dungeon:{locked:()=>false},slimReload:{forget:()=>{}}};
 const read=actors=>({version:1,complete:true,cycle:1,actors:actors.map(({actor})=>({id:actor,owner:{...owners.get(actor)},player:{...result.players.find(p=>p.id===actor)},engagement:null,drops:[]}))});
 return {runtime,result,rows,owners,players,subscribers,mutations,read};
}

function mixed(){
 const s=fixture(),c=s.runtime.channel,now=Date.now();s.runtime.clock=()=>now;c.peer={incarnation:'boot',channel:1};c.revision=0;
 s.result.sharedRefresh.tables.push('player_items');s.result.sharedRefresh.itemActorsR57=['p0'];
 const proof={...s.result.actorSectionsR52,actors:s.result.actorSectionsR52.actors.slice(1)};
 s.result.itemRefreshR57={version:1,cold:['p0'],actorSectionsR52:proof,actorCommitSectionsR57:{...s.read(s.result.players.slice(1).map(p=>({actor:p.id}))),readAtMs:now}};
 delete s.result.actorSectionsR52;
 s.reads=[];c.loadActor=async(id,epoch,revision)=>{s.reads.push(id);return {player:s.result.players.find(p=>p.id===id),owner:{...s.owners.get(id)},revision,combat:{revision},world:{cycle:1}};};c.applyBundle=b=>{s.mutations.push('cold:'+b.player.id);s.rows.set(b.player.id,b.player);};
 return s;
}
test('25 reward recipients: only changed equipment owner is read; all owners receive exact XP',async()=>{
 const s=mixed();assert.equal(await refreshItemSectionsR57(s.runtime,s.result,s.read),true);assert.deepEqual(s.reads,['p0']);assert.equal(s.mutations.length,25);assert.equal(s.mutations.at(-1),'cold:p0');for(const row of s.rows.values())assert.equal(row.xp,10);
});
test('missing item audit, unrelated cold table, level change, missing hold or bad cold bundle cannot partially refresh',async()=>{
 for(const change of [s=>delete s.result.sharedRefresh.itemActorsR57,s=>s.result.sharedRefresh.tables.push('guild_members'),s=>s.result.players[3].level++,s=>s.players.get('p2').barrier=null,s=>{const read=s.runtime.channel.loadActor;s.runtime.channel.loadActor=async(...args)=>({...await read(...args),world:{cycle:2}});},s=>{const read=s.runtime.channel.loadActor;s.runtime.channel.loadActor=async(...args)=>{const b=await read(...args);s.players.get('p2').barrier={};return b;};}]){
  const s=mixed();change(s);assert.equal(await refreshItemSectionsR57(s.runtime,s.result,s.read),false);assert.deepEqual(s.mutations,[]);
 }
});
test('item refresh evidence and nested snapshots never enter durable/replayed receipts',()=>{
 const s=mixed(),value={key:'a',result:s.result};assert.equal(JSON.parse(writeReceipt(value,'a').response).result.itemRefreshR57,undefined);assert.equal(replayValue(value).result.itemRefreshR57,undefined);assert(s.result.itemRefreshR57);
});
test('25 large native rows do not count the same nested counter snapshot twice or trigger an IPC reread',async()=>{
 const s=fixture(),c=s.runtime.channel,now=Date.now();s.runtime.clock=()=>now;c.revision=0;
 for(const row of s.rows.values())row.nativePadding='x'.repeat(7*1024);
 for(const row of s.result.players)row.nativePadding='x'.repeat(7*1024);
 s.result.sharedRefresh.tables.push('player_items');s.result.sharedRefresh.itemActorsR57=['p0'];
 const proof=s.result.actorSectionsR52;
 s.result.itemRefreshR57={version:1,mode:'counter',cold:['p0'],kills:1,items:[{id:'p0',inventory:[],combat:{actor:'p0',actorFrame:{id:'p0'},targetFrame:{id:'p0'},retaliationPlayer:{id:'p0'},armorItems:[],pets:[]}}],actorSectionsR52:proof,actorCommitSectionsR57:{...s.read(s.result.players.map(p=>({actor:p.id}))),readAtMs:now}};
 delete s.result.actorSectionsR52;let frames=0,reads=0;c.frames.hydrate=()=>{frames++;};
 assert(Buffer.byteLength(JSON.stringify(s.result))<512*1024,'real reply is within the existing cap');
 assert.equal(await refreshItemSectionsR57(s.runtime,s.result,actors=>{reads++;return s.read(actors);}),true);
 assert.equal(reads,0,'the single live snapshot is reused');assert.equal(frames,1);assert.equal(s.mutations.length,25);
 assert(s.result.itemRefreshR57,'caller-owned ACK is immutable');
});
