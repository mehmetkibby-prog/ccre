"""Run one isolated, source-sealed four-channel load case. No live VDS."""
from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,os,signal,subprocess
R=Path(__file__).resolve().parents[1]
sp=importlib.util.spec_from_file_location('identity',R.parent/'r55_gameplay_work/package/__main__.py')
m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
p=argparse.ArgumentParser();p.add_argument('case');p.add_argument('--seconds',type=int,default=90);p.add_argument('--fighters',default='0.6');p.add_argument('--baseline-r56',action='store_true');p.add_argument('--weapons',action='store_true');p.add_argument('--trace',action='store_true');p.add_argument('--timeline',action='store_true');p.add_argument('--profile',action='store_true');a=p.parse_args()
assert a.case.replace('-','').replace('_','').isalnum() and 5<=a.seconds<=1800
folder=R/'evidence-r57'/a.case;folder.mkdir(exist_ok=False)
flags=dict(line.split('=',1) for line in (R/'r57-candidate.env').read_text().splitlines() if line and not line.startswith('#'))
env={k:v for k,v in os.environ.items() if not k.startswith(('CORE_','CORE511_','COL_','R35_','R43_','R47_','R51_')) and k!='NODE_OPTIONS'}
env.update(flags)
env.update({k:v for k,v in os.environ.items() if k.startswith('CORE511_R57_')})
env.update({'NODE_OPTIONS':f'--no-warnings --import {R}/tests/native-fixture-support/register-cloud-fixture.mjs'+(f' --import {R}/tests-r57/trace-refresh.mjs' if a.trace else '')+(f' --import {R}/tests-r57/diagnostic-timeline.mjs' if a.timeline else ''),
'COL_CLOUD_ISOLATED_FIXTURE':'1','R35_CORE_REGRESSION':'1','COL_TEST_ACORN_MODULE':str(R/'working/deps/build/node_modules/acorn/dist/acorn.mjs'),'COL_CORE511_SCOPE_MODULE':str(R/'working/deps/build/node_modules/eslint-scope'),
'CORE_WEAPONS':'1' if a.weapons else '0','CORE_SCENARIO':'real','CORE_PARTY':'1','CORE_AOE':'1','CORE_COLLECT':'1','CORE_BAGFILL':'35','CORE_COLLECT_RETRY':'1','RC_SHARED':'1','CORE_PER':'25','CORE_MS':str(a.seconds*1000),'CORE_CLAIM_CAP':'1','CORE_MON_HP':'200','CORE_MONS':'60','CORE_MONSTER_POOL':'channel','CORE_FIGHTERS':a.fighters,'CORE511_LOCAL_REPRO_AUTHORIZED':'1','CORE511_STAGE_TIMING':'1','CORE_OUT':str(folder/'result.json')})
if a.baseline_r56:
 assert not a.trace and not a.profile and not a.timeline
 env['NODE_OPTIONS']+=f' --import {R}/tests-r57/register-r56-load.mjs'
 env.update({k:'0' for k in flags if k.startswith('CORE511_R57_')})
if a.profile:
 env.update(R56_PROFILE_DIR=str(folder),R56_PROFILE_FULL='1',R56_SQL_TRACE='1')
 env['NODE_OPTIONS']=f'--no-warnings --import {R}/tests-r57/register-worker-profile.mjs'
env['NODE_OPTIONS']+=f' --import {R}/tests-r57/observe-full-rewards.mjs'
env['R57_FULL_REWARD_BASELINE']='1' if a.baseline_r56 else '0'
sourceRoot=(R.parent/'r56_performance_work' if a.baseline_r56 else R)/'working/core511-source/scripts/core511'
source=m.core_identity(sourceRoot)
sha=lambda b:hashlib.sha256(b).hexdigest()
stamp=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
proof={'sourceCore':source,'immutableR56':a.baseline_r56,'harnessSha256':sha(Path(__file__).read_bytes()),'profileSha256':sha((R/'r57-candidate.env').read_bytes()),'flags':{k:v for k,v in env.items() if k.startswith('CORE511_')},'workload':{k:v for k,v in env.items() if k.startswith('CORE_')},'startedAtUtc':stamp(),'trace':a.trace or a.timeline,'timeline':a.timeline,'diagnosticWorkerProfile':a.profile,'completed':False,'liveDeployment':False,'performanceApproved':False,'cpuMax':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'memoryMax':Path('/sys/fs/cgroup/memory.max').read_text().strip()}
observerFiles=['tests-r57/observe-full-rewards.mjs','tests-r57/full-reward-tracker.mjs']
proof['observerSha256']={name:sha((R/name).read_bytes()) for name in observerFiles}
def save():(folder/'source.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
save();print('START '+a.case+' '+source,flush=True)
with (folder/'run.log').open('w') as log:
 proc=subprocess.Popen([str(R/'tooling/node-v22.22.0-linux-x64/bin/node'),str(R/'working/core511-source/scripts/core511/benchmark/my-load-real.mjs')],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=proc.wait(timeout=a.seconds+180)
 except BaseException:
  os.killpg(proc.pid,signal.SIGTERM)
  try:proc.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
  proof.update(interrupted=True,finishedAtUtc=stamp());save();raise
proof.update(exitCode=code,finishedAtUtc=stamp());save()
assert code==0,'Load failed; see '+str(folder/'run.log')
assert m.core_identity(sourceRoot)==source,'Source changed during run'
assert sha(Path(__file__).read_bytes())==proof['harnessSha256'] and sha((R/'r57-candidate.env').read_bytes())==proof['profileSha256'],'Harness/profile changed during run'
assert {name:sha((R/name).read_bytes()) for name in observerFiles}==proof['observerSha256'],'Reward observer changed during run'
d=json.loads((folder/'result.json').read_text());db=json.loads((folder/'result.acceptance.json').read_text())
assert d['completed'] is True and d['players']==100 and all(c['players']==25 for c in d['channels'])
assert all(d['r56Flags'][k]==(v=='1') for k,v in flags.items() if k.startswith('CORE511_R56_'))
proof.update(completed=True,evidenceSha256={name:sha((folder/name).read_bytes()) for name in ['result.json','result.drain.json','result.acceptance.json','run.log']});save()
print(json.dumps({'case':a.case,'players':d['players'],'durationS':d['durationS'],'p95Ms':{k:v['p95'] for k,v in d['latency'].items()},'durableDeath':d['rewardObservationR54']['durableDeathFromInputMs'],'fullRewardsR57':d['rewardObservationR54']['fullRewardsR57'],'faults':len(d['faults']),'disconnects':d['disconnects'],'unacked':d['unacked'],'unfinishedRewards':db['unfinishedRewards'],'duplicateKeys':db['duplicateKeys'],'resources':d['resources']},indent=2))
