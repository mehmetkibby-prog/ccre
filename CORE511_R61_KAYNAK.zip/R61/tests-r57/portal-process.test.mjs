import test from 'node:test';
import assert from 'node:assert/strict';
import {setup,extraPlayer} from '../working/core511-source/scripts/core511/tests/process-fixture.mjs';
import {put} from '../working/core511-source/scripts/core511/tests/pvp-fixture.mjs';
import {until} from '../working/core511-source/scripts/core511/tests/helpers.mjs';
import {portalSectionsR57,itemRefreshR57,weaponCounterR57} from '../working/core511-source/scripts/core511/r57-options.mjs';
import {adventureArea} from '../working/core511-source/scripts/core511/adventure-maps.mjs';

test('native death portal waits COMMIT, refreshes the party with bounded equipment refresh, and remains enterable',{timeout:40000},async t=>{
 const s=await setup(t,{shared:true,localCombat:{hp:1}});await s.world.stopJobs();
 assert.equal((await s.http('ticket')).status,200);const firstTicket=await s.http('transfer',{channel:4});assert.equal(firstTicket.status,200);const first=await s.connect(firstTicket);
 const other=extraPlayer(s,87,'r57-portal-peer');assert.equal((await other.http()).status,200);const otherTicket=await other.http('transfer',{channel:4});assert.equal(otherTicket.status,200);const second=await s.connect(otherTicket),ids=[s.f.id,other.id];
 await s.core.permanentPlayers(ids,()=>{
  for(const id of ids)s.f.sql.prepare("UPDATE players SET created_at=1,area='forest',x=2700,y=2025,hp=100000,max_hp=100000,level=40,xp=0,arena_match_id='',combat_lock_until_ms=0,attack_one_at=0,attack_two_at=0,attack_three_at=0,attack_four_at=0,stun_until_ms=0,root_until_ms=0,last_seen=? WHERE id=?").run(Math.floor(s.f.clock()/1000),id);
  for(const id of ids)put(s.f.sql,'monster_participants',{monster_id:'golge-local-terminal511',spawn_round:17,player_id:id,created_at:Math.floor(s.f.clock()/1000)});
  put(s.f.sql,'parties',{id:'r57-portal-party',leader_id:s.f.id,created_at:1});for(const id of ids)put(s.f.sql,'party_members',{party_id:'r57-portal-party',player_id:id,joined_at:1});
  const config=JSON.parse(s.f.sql.prepare('SELECT value FROM adventure_settings WHERE id=1').get().value);s.f.sql.prepare('UPDATE adventure_settings SET value=? WHERE id=1').run(JSON.stringify({...config,enabled:true,chancePercent:100,minLevel:1}));
 });
 const worker=s.writer.rewardWorkerR533;await worker.lane.idle();if(worker.slot){await worker.slot.worker.terminate();await worker.slot.exit;}
 const gate=new Int32Array(new SharedArrayBuffer(4)),release=()=>{Atomics.store(gate,0,1);Atomics.notify(gate,0);};t.after(release);
 worker.entry=new URL('../tests/reward-worker-fault-entry-r533.mjs',import.meta.url);worker.workerOptions={workerData:{stopAt:'before_commit',gate:gate.buffer}};await worker.prepare();
 let reached=false,ack,fullReads=0;worker.onTestHook=()=>{reached=true;};
 const command=s.writer.command.bind(s.writer);s.writer.command=async(peer,request)=>{const value=await command(peer,request);if(request.operation==='attack')ack=value;return value;};
 const route=s.core.route.bind(s.core);s.core.route=(peer,method,...args)=>{if(method==='read_actor')fullReads++;return route(peer,method,...args);};
 first.ws.send(JSON.stringify({type:'input',sequence:1,payload:{action:'attack',targetId:'golge-local-terminal511',spawnRound:17,ability:0,intentId:'r57-portal-death'}}));
 await until(()=>reached,12000);
 const shown=client=>client.packets.flatMap(p=>p.adventure?.portals??[]);
 assert.equal(s.f.sql.prepare('SELECT COUNT(*) n FROM adventure_portals').get().n,0);assert.equal(shown(first).length,0);assert.equal(shown(second).length,0);assert.equal(ack,undefined);
 release();await until(()=>ack&&shown(first).length&&shown(second).length,8000);
 const portal=s.f.sql.prepare('SELECT * FROM adventure_portals').get();assert(portal);assert.equal(shown(first).at(-1).id,portal.id);assert.equal(shown(second).at(-1).id,portal.id);
 const metrics=await s.core.processes.get(4).control.request('metrics',{});console.log(JSON.stringify({fullReads,mixed:ack.result.itemRefreshR57?.cold,portal:ack.result.portalCreationR57,proof:!!ack.result.actorSectionsR52,snapshot:!!ack.result.actorCommitSectionsR57,audit:ack.result.sharedRefresh,metrics:metrics.r52?.actorSections}));assert.equal(fullReads,portalSectionsR57&&itemRefreshR57?(weaponCounterR57?0:1):2);assert.equal(Boolean(ack.result.portalCreationR57),portalSectionsR57);
 assert.equal(s.f.sql.prepare('SELECT COUNT(*) n FROM monster_xp_claims').get().n,2);assert.equal(s.f.sql.prepare('SELECT COUNT(*) n FROM normal_reward_claims').get().n,2);
 second.ws.send(JSON.stringify({type:'input',sequence:1,payload:{action:'adventure_mist_enter',portalId:portal.id,requestId:'r57-portal-entry-0001'}}));
 await until(()=>second.packets.some(p=>p.results?.some(r=>r.sequence===1)),8000);
 const reply=second.packets.flatMap(p=>p.results??[]).find(r=>r.sequence===1);assert.equal(reply.status,200,JSON.stringify(reply));
 assert.equal(adventureArea(s.f.sql.prepare('SELECT area FROM players WHERE id=?').get(other.id).area)?.kind,'mist');assert.equal(s.f.sql.prepare('SELECT entered FROM adventure_portals WHERE id=?').get(portal.id).entered,1);
 assert.equal(s.faults.length,0,JSON.stringify(s.faults));await worker.close();
});
