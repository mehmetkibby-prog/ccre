import test from 'node:test';import assert from 'node:assert/strict';
import {fixture} from '../tests/checkpoint-fixture-r531.mjs';
import {ChannelOwnership as Previous} from '../../r56_performance_work/working/core511-source/scripts/core511/ownership.mjs';
test('grouped authority reads preserve R56 admission/simulation/process fencing across current SQL mutations',async t=>{
 const s=await fixture(t),sql=s.db.sqlite,old=Object.create(s.authority);old.assertAdmitted=Previous.prototype.assertAdmitted;old.assertSimulated=Previous.prototype.assertSimulated;
 const cases=[
  ['active',''],['draining',"UPDATE kernel511_channel_owners SET state='draining' WHERE player_id='p'"],['released',"UPDATE kernel511_channel_owners SET state='released' WHERE player_id='p'"],
  ['wrong owner epoch',"UPDATE kernel511_channel_owners SET epoch=epoch+1 WHERE player_id='p'"],['wrong admission epoch',"UPDATE kernel511_admissions SET epoch=epoch+1 WHERE player_id='p'"],
  ['wrong admission channel',"UPDATE kernel511_admissions SET channel=2 WHERE player_id='p'"],['wrong owner boot',"UPDATE kernel511_channel_owners SET incarnation='other' WHERE player_id='p'"],
  ['offline process',"UPDATE kernel511_channel_processes SET online=0"],['wrong process boot',"UPDATE kernel511_channel_processes SET incarnation='other'"],
  ['missing owner',"DELETE FROM kernel511_channel_owners WHERE player_id='p'"],['missing admission',"DELETE FROM kernel511_admissions WHERE player_id='p'"],
  ['simulation',"DELETE FROM kernel511_admissions WHERE player_id='p';INSERT INTO kernel511_simulations VALUES('p',1,1,'run',1)"],
  ['bad simulation',"DELETE FROM kernel511_admissions WHERE player_id='p';INSERT INTO kernel511_simulations VALUES('p',2,1,'run',1)"],
  ['bad admission cannot use good simulation',"UPDATE kernel511_admissions SET epoch=2 WHERE player_id='p';INSERT INTO kernel511_simulations VALUES('p',1,1,'run',1)"]
 ];
 const outcome=(authority,method,options)=>{try{return {value:authority[method](sql,s.peer,'p',s.owners.get('p').epoch,options)};}catch(e){return {code:e.code};}};
 for(const [label,change]of cases){sql.exec('SAVEPOINT fence_case');try{if(change)sql.exec(change);for(const method of ['assertAdmitted','assertSimulated'])for(const allowDraining of [false,true])assert.deepEqual(outcome(s.authority,method,{allowDraining}),outcome(old,method,{allowDraining}),label+' '+method+' '+allowDraining);}finally{sql.exec('ROLLBACK TO fence_case;RELEASE fence_case');}}
 assert.equal(s.authority.assertAdmitted(sql,s.peer,'p',1).state,'active','no result survives a preceding mutation/rollback');
});
