// Diagnostic-only CPU sampling. Never a production payload.
import {load as prior,resolve as priorResolve} from '../tests/native-fixture-support/cloud-fixture-loader.mjs';
export const resolve=priorResolve;
export async function load(url,context,next){
 const result=await prior(url,context,next);
 if(process.env.R56_PROFILE_DIR&&url.endsWith('/attack-writer.mjs')){
  let source="import {stageStartR51,stageEndR51} from './stage-timing-r51.mjs';\n"+String(result.source);
  source=source.replace('const handle=(sqlite,payload,context)=>{','const handle=(sqlite,payload,context)=>{let phaseR56=stageStartR51();');
  source=source.replace('const {nowMs,receivedAtMs,seed,input,expected}=payload;',"stageEndR51('r56.attack.joinedAndGuards',phaseR56);phaseR56=stageStartR51();const {nowMs,receivedAtMs,seed,input,expected}=payload;");
  source=source.replace('const result=compactCombatResult(sync(rules.nativeAttack(db,ctx)));',"stageEndR51('r56.attack.frameAndFactory',phaseR56);phaseR56=stageStartR51();const result=compactCombatResult(sync(rules.nativeAttack(db,ctx)));stageEndR51('r56.attack.native',phaseR56);phaseR56=stageStartR51();");
  source=source.replace('if(killedIds.length&&process.env.CORE511_DROP_FINALIZE',"stageEndR51('r56.attack.eagerRewards',phaseR56);phaseR56=stageStartR51();if(killedIds.length&&process.env.CORE511_DROP_FINALIZE");
  source=source.replace('const hits=result.body.hits??[],targets=',"stageEndR51('r56.attack.finalize',phaseR56);phaseR56=stageStartR51();const hits=result.body.hits??[],targets=");
  source=source.replace('return {result,events,...(portalCreationR57?', 'const valueR56={result,events,...(portalCreationR57?');
  source=source.replace("??null};\n };","??null};stageEndR51('r56.attack.returnRows',phaseR56);return valueR56;\n };");
  return {...result,source};
 }
 if(process.env.R56_PROFILE_DIR&&url.endsWith('/xp-group-r56.mjs')){
  return {...result,source:String(result.source).replace('metrics.set(sql,stats);',"metrics.set(sql,stats);globalThis[Symbol.for('r56.xpGroupStats')]=stats;")};
 }
 if(process.env.R56_PROFILE_DIR&&url.endsWith('/nonlethal-rewards-r56.mjs')){
  let source=String(result.source).replace('counters.set(sql,stats);',"counters.set(sql,stats);globalThis[Symbol.for('r56.nonlethalStats')]=stats;");
  source=source.replace('certified.set(sql,{main,temp,ok});',"if(!ok)process.stderr.write('R56_SCHEMA_FALLBACK '+JSON.stringify(rows.filter(r=>nonlethalTriggersR56[r.scope+':'+r.name]!==hash(r.sql)).map(r=>({scope:r.scope,name:r.name,sha256:hash(r.sql),sql:r.sql})))+'\\n');certified.set(sql,{main,temp,ok});");
  return {...result,source};
 }
 if(process.env.R56_PROFILE_FULL==='1'&&url.endsWith('/reward-worker-r533.mjs')){
  // Production shutdown terminates the thread directly. Diagnostic shutdown
  // alone first requests its existing close path, allowing a profile flush.
  const anchor='if(slot&&!slot.ended)await slot.worker.terminate();';
  const source=String(result.source);if(source.split(anchor).length!==2)throw Error('R56_profile_parent_close_anchor');
  return {...result,source:source.replace(anchor,`if(slot&&!slot.ended){await new Promise(resolve=>{const done=m=>{if(m?.type==='closed'){clearTimeout(timer);slot.worker.off('message',done);resolve();}};const timer=setTimeout(()=>{slot.worker.off('message',done);resolve();},5000);slot.worker.on('message',done);slot.worker.postMessage({type:'close'});});await slot.worker.terminate();}`)};
 }
 if(process.env.R56_PROFILE_FULL==='1'&&url.endsWith('/reward-worker-runtime-r533.mjs')){
  const anchor="if(message.type==='close'){demand(!current,'reward_worker_close_pending');registry.close();";
  const source=String(result.source);if(source.split(anchor).length!==2)throw Error('R56_profile_close_anchor');
  let output=source.replace(anchor,"if(message.type==='close'){demand(!current,'reward_worker_close_pending');await hook('before_close',{database});registry.close();");
  if(process.env.R56_SQL_TRACE==='1'){
   const before=' const writer=new GameWriter';if(output.split(before).length!==2)throw Error('R56_sql_trace_writer_anchor');
   output="import {installSQLTraceR56} from "+JSON.stringify(new URL('../tests-r56/sql-trace-r56.mjs',import.meta.url).href)+";\n"+output.replace(before,' installSQLTraceR56(sql);\n'+before);
  }
  return {...result,source:output};
 }
 if(process.env.R56_PROFILE_DIR&&url.endsWith('/reward-worker-entry-r533.mjs'))return {...result,source:`
import inspector from 'node:inspector';
import fs from 'node:fs';
import {threadId} from 'node:worker_threads';
const session=new inspector.Session();session.connect();
const post=(method,params={})=>new Promise((resolve,reject)=>session.post(method,params,(e,v)=>e?reject(e):resolve(v)));
await post('Profiler.enable');await post('Profiler.setSamplingInterval',{interval:1000});await post('Profiler.start');
const {stageSnapshotR51}=await import('./stage-timing-r51.mjs');
const started=performance.now();let stopped=false,command=null;const commands=[];
async function stop(){if(stopped)return;stopped=true;try{const {profile}=await post('Profiler.stop');fs.mkdirSync(process.env.R56_PROFILE_DIR,{recursive:true});const prefix=process.env.R56_PROFILE_DIR+'/reward-worker-'+process.pid+'-'+threadId;fs.writeFileSync(prefix+'.cpuprofile',JSON.stringify(profile));fs.writeFileSync(prefix+'.timing.json',JSON.stringify({commands,stages:stageSnapshotR51(),sql:globalThis[Symbol.for('r56.sqlTrace')]?.report(),nonlethal:globalThis[Symbol.for('r56.nonlethalStats')],xpGroup:globalThis[Symbol.for('r56.xpGroupStats')]}));}finally{session.disconnect();}}
const {runRewardWorkerR533}=await import('./reward-worker-runtime-r533.mjs');
await runRewardWorkerR533({hook(phase,data){
 if(phase==='before_command'){globalThis[Symbol.for('r56.sqlTrace')]?.begin();command={kind:data.current.request.operation,targets:data.current.request.payload?.localScope?.targets?.length??null,checkpointBytes:JSON.stringify(data.current.request.payload?.checkpointR53??null).length,at:performance.now()};}
 if(phase==='before_commit'&&command)command.commitAt=performance.now();
 if(phase==='after_commit'&&command){command.commitMs=performance.now()-command.commitAt;delete command.commitAt;}
 if(phase==='after_command'){globalThis[Symbol.for('r56.sqlTrace')]?.end();if(command&&commands.length<512){const {at,...rest}=command;commands.push({...rest,wallMs:performance.now()-at,ackBytes:JSON.stringify(data.ack).length,parts:Object.fromEntries(Object.entries(data.ack?.result??{}).map(([k,v])=>[k,JSON.stringify(v)?.length??0])),hits:data.ack?.result?.result?.body?.hits?.length??null,kills:data.ack?.result?.result?.body?.hits?.filter(h=>h.killed).length??null});command=null;}}
 if(phase==='before_close')return stop();
 if(process.env.R56_PROFILE_FULL!=='1'&&phase==='after_command'&&performance.now()-started>=12000)void stop();
}});
`};
 return result;
}
