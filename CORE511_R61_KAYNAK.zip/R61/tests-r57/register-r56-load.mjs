import {register} from 'node:module';
register('./r56-load-loader.mjs',import.meta.url);
