import test from 'node:test';import assert from 'node:assert/strict';
import {planSingleDeathsR57,takeSingleDeathsR57} from '../working/core511-source/scripts/core511/death-batch-single-r57.mjs';
const enabled=process.env.CORE511_R57_DEATH_BATCH==='1';
function fixture(){
 const players=new Map(),rows=new Map(),inputs=new Map(),planned=[],guards=[],mounted=[];
 for(let i=0;i<6;i++){const id='p'+i;rows.set(id,{id,area:'forest',channel:1});const head={order:i+1,at:i+1,kind:'combat',sequence:1,receivedAtMs:1000,payload:{action:'attack',ability:0,targetId:'m'+i}};players.set(id,{epoch:1,queue:i?[head]:[],deferred:[]});inputs.set(id,head);}
 const kernel={players,metrics:{},state:{assertOwner:()=>{}}};
 const c={kernel,state:kernel.state,view:{player:id=>rows.get(id),monster:id=>({id,channel:1})},identities:new Map([...rows.keys()].map(id=>[id,{actor:id}])),checkpoints:{overdueR53:()=>false},retaliationMemory:{due:()=>[]},mounts:{enabled:true,beforeAction:id=>mounted.push(id)},ports:{guard:i=>{guards.push(i.actor);return true;}},frames:{attack:id=>({id})},attackMemory:{plan:frame=>{planned.push(frame.id);return {durable:true,id:frame.id};}}};
 const runtime={channel:c,forceSharedActors:new Map(),localResident:()=>true,localKill:(id,p)=>p.durable?{ids:[...rows.keys()],targets:[{id:'m'+id.slice(1),spawnRound:1}]}:null};
 const local={ids:[...rows.keys()],targets:[{id:'m0',spawnRound:1}]};
 return {c,runtime,inputs,guards,mounted,planned,prepare:()=>planSingleDeathsR57(runtime,{id:'p0',inputOrder:1,now:1000,kernel},local)};
}
test('single-death planning reserves no input until the expanded lease is acquired',()=>{
 const s=fixture(),plan=s.prepare();if(!enabled){assert.equal(plan,null);assert.equal(s.planned.length,0);return;}
 assert.equal(plan.entries.length,4);assert.equal(plan.targets.length,5);assert.equal(s.c.kernel.players.get('p1').queue.length,1);assert.equal(s.mounted.length,0);
 const entries=takeSingleDeathsR57(s.c,plan);assert.equal(entries.length,4);for(const e of entries){assert.equal(s.c.kernel.players.get(e.actor).queue.length,0);assert.equal(s.c.kernel.players.get(e.actor).deferred[0].sequence,1);}assert.deepEqual(s.mounted,s.guards);assert.throws(()=>takeSingleDeathsR57(s.c,plan),{code:'death_batch_plan'});
});
test('nonlethal, older potion, overlapping life, foreign party and actor fence retain original queue',()=>{
 for(const kind of ['nonlethal','potion','overlap','foreign','epoch']){const s=fixture();
  if(kind==='nonlethal')s.c.attackMemory.plan=()=>({durable:false});
  if(kind==='potion')s.inputs.get('p1').payload.action='use_potion';
  if(kind==='overlap')s.inputs.get('p1').payload.targetId='m0';
  if(kind==='foreign')s.runtime.localKill=()=>({ids:['foreign'],targets:[{id:'m1',spawnRound:1}]});
  if(kind==='epoch')s.c.kernel.state.assertOwner=()=>{throw Object.assign(Error('fenced'),{code:'owner_epoch_fenced'});};
  if(enabled&&kind==='epoch')assert.throws(s.prepare,{code:'owner_epoch_fenced'});else assert.equal(s.prepare(),null,kind);
  assert.equal(s.c.kernel.players.get('p1').queue.length,1);assert.equal(s.c.kernel.players.get('p1').deferred.length,0);
 }
});
test('changed last head is rejected before consuming any earlier prepared input',()=>{
 const s=fixture(),plan=s.prepare();if(!enabled)return;s.c.kernel.players.get('p4').queue[0]={...s.inputs.get('p4')};assert.throws(()=>takeSingleDeathsR57(s.c,plan),{code:'death_batch_queue_changed'});
 for(let i=1;i<=4;i++){assert.equal(s.c.kernel.players.get('p'+i).queue.length,1);assert.equal(s.c.kernel.players.get('p'+i).deferred.length,0);}
});
test('a selected actor next input keeps priority over a newer different actor',()=>{
 const s=fixture();for(let i=2;i<6;i++){s.inputs.get('p'+i).order++;s.inputs.get('p'+i).at++;}
 s.c.kernel.players.get('p1').queue.push({...s.inputs.get('p1'),order:3,at:3,sequence:2});const plan=s.prepare();if(enabled){assert.equal(plan.entries.length,1);assert.equal(plan.entries[0].actor,'p1');}else assert.equal(plan,null);
});
