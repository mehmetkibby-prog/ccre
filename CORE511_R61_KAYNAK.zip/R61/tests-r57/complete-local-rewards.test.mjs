import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import {spawn} from 'node:child_process';import {once} from 'node:events';
import {GameWriter} from '../working/core511-source/scripts/core511/writer-runtime.mjs';
import {localRewardBudgetR57} from '../working/core511-source/scripts/core511/local-reward-budget-r57.mjs';
import {native} from '../working/core511-source/scripts/core511/tests/helpers.mjs';
const {LocalDatabase}=await native('vds-server/src/database.mjs'),{installRegistry}=await native('vds-server/src/loadlab/registry.mjs');
async function replay(t,{kills=64,original=false,enabled=true,phase=''}={}){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'r57-complete-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));const output=path.join(root,'result.json'),stateFile=path.join(root,'state.json');
 const child=spawn(process.execPath,['tests-r56/replay-native-writer-r56.mjs'],{cwd:new URL('..',import.meta.url),env:{...process.env,R56_REPLAY_ORIGINAL:original?'1':'0',R56_REPLAY_OUT:output,R56_REPLAY_TARGETS:String(kills),R56_REPLAY_KILLS:String(kills),R56_REPLAY_RECIPIENTS:'25',R56_REPLAY_CRASH:phase,R56_REPLAY_STATE:stateFile,R56_REPLAY_JOIN_CLAIM:'0',CORE511_R57_COMPLETE_LOCAL_REWARDS:enabled?'1':'0',CORE511_R56_SMALL_GROUP_EAGER:'1',CORE511_R56_REWARD_SLICE:'1'},stdio:['ignore','pipe','pipe']});
 let log='';for(const stream of [child.stdout,child.stderr])stream.on('data',b=>log=(log+b).slice(-7000));t.after(()=>{if(child.exitCode===null&&child.signalCode===null)child.kill('SIGKILL');});
 const [code,signal]=await once(child,'exit');if(phase){assert.equal(signal,'SIGKILL',log);return JSON.parse(fs.readFileSync(stateFile));}assert.equal(signal,null,log);assert.equal(code,0,log);return JSON.parse(fs.readFileSync(output));
}
test('64 local deaths finish all 1600 party awards with exact immutable R55 native SQL/events/action parity',async t=>{
 const old=await replay(t,{original:true}),now=await replay(t);assert.equal(now.summary.normalClaims,1600);assert.equal(now.summary.xpClaims,1600);assert(now.summary.replayEconomyUnchanged);assert.deepEqual(now.action,old.action);assert.deepEqual(now.events,old.events);assert.deepEqual(now.delta,old.delta);
});
test('33-death off control stays sliced; on completes; 65-death stress remains sliced',async t=>{
 for(const [kills,enabled,immediate]of [[33,false,16],[33,true,33],[65,true,4]]){const r=await replay(t,{kills,enabled});assert.equal(r.summary.normalClaims,immediate*25);assert.equal(r.summary.xpClaims,kills*25);assert(r.summary.replayEconomyUnchanged);}
});
test('shared, special, oversized or incompletely held reward groups cannot expand the native budget',()=>{
 const killed=Array.from({length:33},(_,i)=>'m'+i),payload={localScope:{kind:'mixed',targets:killed.map(id=>({id,spawnRound:1}))},resources:['player:p',...killed.map(id=>'monster:'+id)]};
 assert.equal(localRewardBudgetR57(payload,'forest',killed,16),64);
 for(const p of [{...payload,sharedLease:{}},{...payload,localScope:{...payload.localScope,kind:'claim'}},{...payload,localScope:{...payload.localScope,targets:[]}},{...payload,resources:payload.resources.slice(0,-1)},{...payload,resources:[...payload.resources,...Array.from({length:25},(_,i)=>'player:extra'+i)]}])assert.equal(localRewardBudgetR57(p,'forest',killed,16),16);
 for(const area of ['black','sanctum','arena','mist','dragon'])assert.equal(localRewardBudgetR57(payload,area,killed,16),16);
});
for(const phase of ['before','after'])test('SIGKILL '+phase+' 64-death COMMIT/fsync: full party awards recover exactly once',async t=>{
 const state=await replay(t,{phase});assert.deepEqual(state.counts,{xp:1600,normal:1600,defeats:64});
 const database=new LocalDatabase(state.file,{create:false,groupWrites:true,asyncDurable:false});t.after(()=>database.close());const sql=database.sqlite;sql.function('unixepoch',()=>1792800000);
 const counts=()=>({xp:sql.prepare('SELECT COUNT(*) n FROM monster_xp_claims').get().n,normal:sql.prepare('SELECT COUNT(*) n FROM normal_reward_claims').get().n,defeats:sql.prepare('SELECT COUNT(*) n FROM normal_defeats').get().n});
 assert.deepEqual(counts(),phase==='before'?{xp:0,normal:0,defeats:0}:state.counts);
 const registry=installRegistry();t.after(()=>registry.close());const writer=new GameWriter(database,{realmId:'r56-replay',ports:{guard:()=>true},clock:()=>110000});await writer.initialize();t.after(()=>writer.maintenance.close());
 const answer=await writer.command(state.peer,state.request);assert.equal(answer.result.result.status,200);assert.deepEqual(counts(),state.counts);assert.equal(sql.prepare('SELECT COUNT(*) n FROM normal_defeats WHERE rewards_completed_at=0').get().n,0);
 const players=sql.prepare('SELECT id,xp,level,gems FROM players ORDER BY id').all();await writer.command(state.peer,state.request);assert.deepEqual(counts(),state.counts);assert.deepEqual(sql.prepare('SELECT id,xp,level,gems FROM players ORDER BY id').all(),players);
});
