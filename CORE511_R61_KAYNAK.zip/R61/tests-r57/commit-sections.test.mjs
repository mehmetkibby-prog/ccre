import test from 'node:test';
import assert from 'node:assert/strict';
import {refreshActorSectionsR52} from '../working/core511-source/scripts/core511/actor-section-reuse-r52.mjs';
import {writeReceipt,replayValue} from '../working/core511-source/scripts/core511/compact-receipt.mjs';
import {groundLoot30s} from '../working/core511-source/scripts/core511/ground-loot-expiry.mjs';
import {ENCOUNTER_FIELDS} from '../working/core511-source/scripts/core511/encounter-checkpoint.mjs';
const enabled=process.env.CORE511_R57_COMMIT_SECTIONS==='1';
function fixture(count=25){
 const rows=new Map(),owners=new Map(),players=new Map(),subscribers=new Map(),frames=new Map(),mutations=[];
 const result={result:{status:200},players:[],monsters:[],sharedRefresh:{version:1,all:false,tables:['players','world_drops'],actors:[]},actorSectionsR52:{version:1,cycle:1,readSections:true,readDrops:true,actor:'p0',actors:[]},engagement:null};
 for(let i=0;i<count;i++){
  const id='p'+i,row={id,area:'forest',channel:1,arena_match_id:'',hp:100,max_hp:100,hp_revision:1,level:40,xp:0,last_seen:1},owner={epoch:2,channel:1,incarnation:'boot'};
  rows.set(id,row);owners.set(id,owner);players.set(id,{epoch:2,barrier:{}});frames.set(id,{valid:true});
  subscribers.set(id,{ownerRow:{...row},data:{area:row.area,channel:1,players:[{...row}],inventory:[],drops:[]},revision:1});
  result.players.push({...row,xp:10});result.sharedRefresh.actors.push(id);result.actorSectionsR52.actors.push({id,owner:{...owner},engagementRef:{kind:i===0?'ack-attack':'resident'}});
 }
 const channel={world:{cycle:1},owners,kernel:{players},frames:{entries:frames},lanes:{busy:()=>true},state:{assertOwner:()=>{}},presence:{merge:row=>row},view:{player:id=>rows.get(id),engagements:new Map(),setPlayer:row=>{mutations.push(row.id);rows.set(row.id,row);},setEngagement:()=>{}},setMonster:m=>mutations.push(m.id)};
 const runtime={channel,world:{subscribers},dungeon:{locked:()=>false},slimReload:{forget:()=>{}}};
 const read=actors=>({version:1,complete:true,cycle:1,actors:actors.map(({actor})=>({id:actor,owner:{...owners.get(actor)},player:{...result.players.find(p=>p.id===actor)},engagement:null,drops:[]}))});
 return {runtime,result,rows,owners,players,subscribers,mutations,read};
}

function direct(){
 const s=fixture(),now=Date.now();s.runtime.clock=()=>now;
 s.result.actorCommitSectionsR57={...s.read(s.result.players.map(row=>({actor:row.id}))),readAtMs:now};return s;
}
test('a secondary attack installs its exact committed encounter; malformed batch references mutate nothing',async()=>{
 const fixtureBatch=()=>{const s=direct(),engagement=Object.fromEntries(ENCOUNTER_FIELDS.map(k=>[k,k==='player_id'?'p1':0]));s.result.batchResultsR57=[{actor:'p1',sequence:2,result:{status:200}}];s.result.batchEngagementsR57=[['p1',engagement]];s.result.actorSectionsR52.actors[1].engagementRef={kind:'ack-batch-r57',index:0};s.result.actorCommitSectionsR57.actors[1].engagement=engagement;return s;};
 const s=fixtureBatch(),applied=[];s.runtime.channel.view.setEngagement=(id,e)=>applied.push([id,e]);
 assert.equal(await refreshActorSectionsR52(s.runtime,s.result,actors=>{const fresh=s.read(actors);fresh.actors.find(e=>e.id==='p1').engagement=s.result.batchEngagementsR57[0][1];return fresh;}),true);assert.deepEqual(applied.find(e=>e[0]==='p1'),s.result.batchEngagementsR57[0]);
 for(const change of [s=>s.result.batchEngagementsR57[0][0]='p2',s=>s.result.batchResultsR57[0].actor='p2',s=>s.result.batchEngagementsR57[0][1]={},s=>s.result.actorSectionsR52.actors[1].engagementRef.index=1]){const s=fixtureBatch();change(s);assert.equal(await refreshActorSectionsR52(s.runtime,s.result,()=>assert.fail('invalid reference must fail before reads')),false);assert.deepEqual(s.mutations,[]);}
});
test('25 recipients use the durable writer snapshot with zero follow-up IPC reads',async()=>{
 const s=direct();let reads=0;
 const value=refreshActorSectionsR52(s.runtime,s.result,async actors=>{assert.deepEqual(s.mutations,[]);reads++;return s.read(actors);});
 if(enabled)assert.equal(value,true,'direct apply should not yield');
 assert.equal(await value,true);assert.equal(reads,enabled?0:1);assert.equal(s.mutations.length,25);
});
test('old, future, oversized and altered snapshot sections fall back before any mutation',async()=>{
 for(const change of [
  s=>s.result.actorCommitSectionsR57.readAtMs-=1001,
  s=>s.result.actorCommitSectionsR57.readAtMs++,
  s=>s.result.actorCommitSectionsR57.cycle++,
  s=>s.result.actorCommitSectionsR57.actors[24].owner.epoch++,
  s=>s.result.actorCommitSectionsR57.actors[24].player.xp++,
  s=>s.result.actorCommitSectionsR57.actors[24].engagement={},
  s=>s.result.actorCommitSectionsR57.actors[24].drops=[{owner_id:'stranger'}],
  s=>s.result.actorCommitSectionsR57.actors.push(s.result.actorCommitSectionsR57.actors[0]),
  s=>s.result.actorCommitSectionsR57.actors[24].extra='x'.repeat(512*1024),
 ]){
  const s=direct();change(s);let reads=0;
  assert.equal(await refreshActorSectionsR52(s.runtime,s.result,async actors=>{assert.deepEqual(s.mutations,[]);reads++;return s.read(actors);}),true);
  assert.equal(reads,1);assert.equal(s.mutations.length,25);
 }
});
test('last-recipient ownership, projection, HP and equipment fences still protect the entire group',async()=>{
 for(const change of [s=>s.owners.get('p24').epoch++,s=>s.runtime.channel.world.cycle++,s=>s.players.get('p24').barrier=null,s=>s.rows.set('p24',{...s.rows.get('p24'),hp:0}),s=>s.rows.set('p24',{...s.rows.get('p24'),max_hp:110}),s=>s.subscribers.get('p24').data.area='ancient']){
  const s=direct();change(s);assert.equal(await refreshActorSectionsR52(s.runtime,s.result,()=>{throw Error('must not read after bad fence');}),false);assert.deepEqual(s.mutations,[]);
 }
});
test('commit-only snapshot is excluded from durable receipts and replay, preserving canonical reward data',()=>{
 const s=direct(),ack={key:'key',sequence:1,result:s.result};
 const expected=structuredClone(ack);delete expected.result.actorCommitSectionsR57;
 assert.deepEqual(replayValue(ack),expected);
 const stored=JSON.parse(writeReceipt(ack,'key').response);assert.deepEqual(stored,expected);
 assert(s.result.actorCommitSectionsR57,'never mutate the live reply');
});
test('crossing a second applies the exact native expiry predicate without re-reading held recipients',async()=>{
 const s=direct(),seconds=Math.floor(Date.now()/1000);s.result.actorCommitSectionsR57.readAtMs=seconds*1000-10;s.runtime.clock=()=>seconds*1000+10;
 const drops=[{id:'expired',owner_id:'p0',expires_at:seconds-1},{id:'boundary',owner_id:'p0',expires_at:seconds},{id:'valid',owner_id:'p0',expires_at:seconds+1}];s.result.actorCommitSectionsR57.actors[0].drops=drops;
 let reads=0;assert.equal(await refreshActorSectionsR52(s.runtime,s.result,actors=>{reads++;return s.read(actors);}),true);
 if(enabled){assert.equal(reads,0);assert.deepEqual(s.subscribers.get('p0').data.drops.map(d=>d.id),groundLoot30s?['valid']:['boundary','valid']);}
 assert.equal(drops.length,3,'receipt snapshot remains immutable');
});
