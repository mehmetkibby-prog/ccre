import test from 'node:test';import assert from 'node:assert/strict';
import {planMixedSuccessorsR57,takeSingleDeathsR57} from '../working/core511-source/scripts/core511/death-batch-single-r57.mjs';
function fixture(){
 const rows=new Map(['a','b','c'].map(id=>[id,{id,role:'arkanist',area:'forest',channel:1,x:100,y:100}])),monsters=new Map(Array.from({length:60},(_,i)=>['m'+i,{id:'m'+i,spawn_round:1,hp:1,channel:1,area:'forest',x:100+i,y:100}]));
 const head=(order,ability=2)=>({order,at:order,kind:'combat',sequence:1,receivedAtMs:1000,payload:{action:'attack',targetId:'m1',ability}}),players=new Map([['a',{epoch:1,queue:[],deferred:[]}],['b',{epoch:1,queue:[head(2)],deferred:[]}],['c',{epoch:1,queue:[head(3,1)],deferred:[]}]]);
 const kernel={players,metrics:{},state:{assertOwner:()=>{}}},c={kernel,state:kernel.state,view:{monsters,player:id=>rows.get(id),monster:id=>monsters.get(id)},attackMemory:{participants:new Map([['p',{monster_id:'m4',spawn_round:1,player_id:'c'}]])},identities:new Map([...rows.keys()].map(id=>[id,{actor:id}])),ports:{guard:()=>true},mounts:{enabled:false},checkpoints:{overdueR53:()=>false},retaliationMemory:{due:()=>[]}};
 const runtime={channel:c,forceSharedActors:new Map(),localResident:()=>true,localGroup:id=>rows.has(id)?[...rows.keys()]:null},context={id:'a',input:{action:'attack',targetId:'m0',ability:0},inputOrder:1,now:1000,kernel},local={ids:[...rows.keys()],targets:[{id:'m0',spawnRound:1}]};
 return {c,runtime,context,local,prepare:()=>planMixedSuccessorsR57(runtime,context,local)};
}
test('single death can lease a bounded area successor union without consuming any input first',()=>{
 const s=fixture(),p=s.prepare();assert.equal(p.scope.kind,'mixed');assert.equal(p.targets.length,60);assert.equal(p.entries.length,2);assert.equal(s.c.kernel.players.get('b').queue.length,1);takeSingleDeathsR57(s.c,p);assert.equal(s.c.kernel.players.get('b').deferred[0].sequence,1);assert.equal(s.c.kernel.metrics.promotedDeathBatchInputsR57,2);
});
test('unknown contributors, more than64 targets, shared monsters and older potions prevent promotion',()=>{
 for(const change of [s=>s.c.attackMemory.participants.set('foreign',{monster_id:'m4',spawn_round:1,player_id:'outside'}),s=>{for(let i=60;i<65;i++)s.c.view.monsters.set('m'+i,{...s.c.view.monsters.get('m0'),id:'m'+i});},s=>s.c.view.monsters.get('m5').channel=0,s=>s.c.kernel.players.get('b').queue[0].payload.action='use_potion']){const s=fixture();change(s);assert.equal(s.prepare(),null);assert.equal(s.c.kernel.players.get('b').queue.length,1);assert.deepEqual(s.c.kernel.players.get('b').deferred,[]);}
});
test('a selected actor older second input keeps priority over another area successor',()=>{
 const s=fixture();s.c.kernel.players.get('c').queue[0].order=4;s.c.kernel.players.get('c').queue[0].at=4;s.c.kernel.players.get('b').queue.push({...s.c.kernel.players.get('b').queue[0],order:3,at:3,sequence:2});const p=s.prepare();assert.equal(p.entries.length,1);assert.equal(p.entries[0].actor,'b');
});
