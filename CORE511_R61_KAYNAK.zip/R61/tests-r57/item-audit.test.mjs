import test from 'node:test';import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {initializeItemRefreshR57,readItemRefreshR57,clearItemRefreshR57} from '../working/core511-source/scripts/core511/item-refresh-audit-r57.mjs';
import {nonlethalSchemaR56} from '../working/core511-source/scripts/core511/nonlethal-rewards-r56.mjs';
test('item audit follows OLD/NEW owners and SQL savepoint rollback, with exact trigger certification',t=>{
 const sql=new DatabaseSync(':memory:');t.after(()=>sql.close());sql.exec('CREATE TABLE player_items(id TEXT PRIMARY KEY,player_id TEXT,value INTEGER);CREATE TEMP TABLE kernel511_refresh_enabled(v INTEGER);INSERT INTO kernel511_refresh_enabled VALUES(0)');initializeItemRefreshR57(sql);assert(nonlethalSchemaR56(sql));
 sql.exec("INSERT INTO player_items VALUES('a','p1',0);BEGIN;UPDATE kernel511_refresh_enabled SET v=1;UPDATE player_items SET value=1");assert.deepEqual(readItemRefreshR57(sql).itemActorsR57,['p1']);
 sql.exec("SAVEPOINT test;UPDATE player_items SET player_id='p2'");assert.deepEqual(readItemRefreshR57(sql).itemActorsR57,['p1','p2']);sql.exec('ROLLBACK TO test;RELEASE test');assert.deepEqual(readItemRefreshR57(sql).itemActorsR57,['p1']);
 sql.exec("INSERT OR REPLACE INTO player_items VALUES('b','p1',3)");assert.deepEqual(readItemRefreshR57(sql).itemActorsR57,['p1']);clearItemRefreshR57(sql);sql.exec('DELETE FROM player_items');assert.deepEqual(readItemRefreshR57(sql).itemActorsR57,['p1']);sql.exec('ROLLBACK');assert.deepEqual(readItemRefreshR57(sql).itemActorsR57,[]);
 sql.exec('DROP TRIGGER kernel511_item_refresh_r57_UPDATE;CREATE TEMP TRIGGER kernel511_item_refresh_r57_UPDATE AFTER UPDATE ON player_items BEGIN SELECT random();END');assert.equal(nonlethalSchemaR56(sql),false);
});
