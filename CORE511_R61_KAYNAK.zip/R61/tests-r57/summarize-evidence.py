"""Reproduce acceptance from sealed evidence, retaining failed experiments."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,math
R=Path(__file__).resolve().parents[1];E=R/'evidence-r57'
sp=importlib.util.spec_from_file_location('identity',R.parent/'r55_gameplay_work/package/__main__.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
p=argparse.ArgumentParser();p.add_argument('--soak',default='stable-seed-soak-100');p.add_argument('--all-combat',default='stable-seed-allcombat-100');a=p.parse_args()
sha=lambda b:hashlib.sha256(b).hexdigest();core=m.core_identity(R/'working/core511-source/scripts/core511');rows=[]
flags=dict(line.split('=',1) for line in (R/'r57-candidate.env').read_text().splitlines() if line and not line.startswith('#'))
observers={name:sha((R/name).read_bytes()) for name in ['tests-r57/observe-full-rewards.mjs','tests-r57/full-reward-tracker.mjs']}
for path in sorted(E.glob('*/source.json')):
 proof=json.loads(path.read_bytes())
 if not proof.get('completed'):continue
 for name,digest in proof['evidenceSha256'].items():assert sha((path.parent/name).read_bytes())==digest,path.parent/name
 d=json.loads((path.parent/'result.json').read_bytes());db=json.loads((path.parent/'result.acceptance.json').read_bytes());reward=d['rewardObservationR54'];full=reward.get('fullRewardsR57')
 issues={'faults':len(d['faults']),'disconnects':d['disconnects'],'unacked':d['unacked'],'pendingDurable':len(reward['pendingFinal']),'unfinishedRewards':db['unfinishedRewards'],'duplicateKeys':db['duplicateKeys'],'harnessFailures':sum(n for kind,n in d.get('failureEvidence',{}).get('byKind',{}).items() if kind!='native_result')}
 normalRejections={'attack:basic_attack_cadence','attack:Yetenek henüz hazır değil.','use_potion:Canın zaten dolu.','collect:bag_full','collect:loot_expired','collect:Ganimet artık burada değil.'}
 issues['unexpectedGameRejections']=sum(n for code,n in d.get('errCodes',{}).items() if code not in normalRejections)
 if full:issues.update(pendingFullRewards=len(full['pending']),rewardObserverErrors=len(full['errors']),unmeasuredDeaths=abs(full['deathAndAllRewardsMs']['n']+full.get('finalWithoutKill',0)-reward['durableDeathFromInputMs']['n']))
 rows.append({'run':path.parent.name,'sourceCore':proof['sourceCore'],'currentSource':proof['sourceCore']==core,'baselineR56':proof.get('immutableR56',False),'diagnostic':proof.get('trace',False) or proof.get('diagnosticWorkerProfile',False),'currentObserver':proof.get('observerSha256')==observers,'selectedProfile':proof['profileSha256']==sha((R/'r57-candidate.env').read_bytes()) and all(proof['flags'].get(k)==v for k,v in flags.items()),'players':d['players'],'durationS':d['durationS'],'workload':proof['workload'],'flags':proof['flags'],'durableDeath':reward['durableDeathFromInputMs'],'fullRewards':full,'firstRewardVisible':reward['firstOwnXpOrTargetDropObservedMs'],'latency':d['latency'],'normalGameplayRejections':{k:v for k,v in d.get('errCodes',{}).items() if k in normalRejections},'consistency':issues,'resources':d['resources'],'evidenceSha256':proof['evidenceSha256'],'sourceProofSha256':sha(path.read_bytes())})
expected=[a.soak,a.all_combat];assert len(set(expected))==2
final=[r for name in expected for r in rows if r['run']==name]
def accepted(r,seconds,fighters,samples):
 full=r['fullRewards'];w=r['workload']
 if not(r['currentSource'] and r['currentObserver'] and r['selectedProfile'] and not r['diagnostic'] and r['players']==100 and r['durationS']>=seconds and full and not any(r['consistency'].values())):return False
 if not all(w.get(k)==v for k,v in {'CORE_SCENARIO':'real','CORE_PER':'25','CORE_WEAPONS':'1','CORE_PARTY':'1','CORE_AOE':'1','CORE_COLLECT':'1','CORE_BAGFILL':'35','CORE_MON_HP':'200','CORE_MONS':'60','CORE_MONSTER_POOL':'channel','CORE_CLAIM_CAP':'1','CORE_COLLECT_RETRY':'1'}.items()):return False
 if float(w['CORE_FIGHTERS'])!=fighters:return False
 for stat in [r['durableDeath'],full['deathAndAllRewardsMs']]:
  if not(stat['n']>=samples and isinstance(stat['p95'],(int,float)) and math.isfinite(stat['p95']) and 0<=stat['p95']<=400):return False
 return True
goal=len(final)==2 and accepted(final[0],300,.6,200) and accepted(final[1],300,1.,200)
checks={}
for name,key in [('regression/validated-source.json','regression'),('r57-focused-seal.json','r57'),('installer-r57.json','installer')]:
 path=E/name
 if path.exists():
  v=json.loads(path.read_bytes());checks[key]={'currentSource':v.get('sourceCore',v.get('afterCore'))==core,'sha256':sha(path.read_bytes()),'details':v}
report={'sourceCore':core,'goal':'100 players, 4x25 channels, client durable death AND all native rewards p95 <=400ms','goalThresholdMs':400,'goalMetLocally':goal,'status':'LOCAL_TARGET_MET_VDS_UNVERIFIED' if goal else 'TARGET_NOT_MET_OR_INCOMPLETE','performanceApproved':False,'liveDeployment':False,'cpuQuota':4,'vdsReportedCores':8,'coLocatedClients':True,'finalCases':expected,'checks':checks,'results':rows,'limitations':['Synthetic clients share the 4CPU cloud; no direct production VDS observation.','Random runs are comparable scenarios, not identical execution schedules.','202 preview is separate; acceptance also requires every killed target reward complete and covering main/external worker durability.','Final inventory rendering and Internet RTT are not measured.','Diagnostic, older-source, incomplete or older-observer runs cannot approve acceptance.']}
(E/'acceptance.json').write_bytes(m.encoded(report))
lines=['# R57 ölçüm sonucu\n',f"Kaynak: `{core}`. Kullanıcının **100 oyuncuda p95 ≤400 ms** yerel hedefi: **{'GEÇTİ' if goal else 'HENÜZ GEÇMEDİ / eksik koşu'}**. VDS’ye kurulum yapılmadı.\n",'Dört kanala 25’er oyuncu dağıtılır. Takılı silah, parti, alan saldırısı, iksir, eşya toplama ve 35 eşyalık çanta kullanılır. Uzun koşuda oyuncuların %60’ı, ikinci koşuda tamamı savaşır. Botlar da 4 CPU kotalı test makinesindedir.\n','| Koşu | Süre | Ölüm p95 | Ölüm ve tüm ödüller p95 | Hareket p95 | İksir p95 | Bütünlük sorunları |\n|---|---:|---:|---:|---:|---:|---:|\n']
show=[*expected,'immutable-r56-weapons-soak-100','resource-authority-soak-100','wide-death-batch-100']
for r in rows:
 if r['run'] not in show:continue
 label=r['run']+(' (önceki kaynak)' if not r['currentSource'] and not r['baselineR56'] else '')
 f=r['fullRewards'];allms=f"{f['deathAndAllRewardsMs']['p95']:.1f} ms" if f and f['deathAndAllRewardsMs']['p95'] is not None else 'ölçülmedi'
 if f and not r['currentObserver']:allms+=' (önceki gözlemci)'
 lines.append(f"| {label} | {r['durationS']} sn | {r['durableDeath']['p95']:.1f} ms ({r['durableDeath']['n']} olay) | {allms} | {r['latency']['move']['p95']} ms | {r['latency']['use_potion']['p95']} ms | {sum(r['consistency'].values())} |\n")
lines.extend(['\n400 ms saniyenin 0,4’üdür. p95 ölçümlerin %95’inin en geç bu sürede tamamlanmasıdır; her işlemin üst sınırı değildir. Kalıcı ölüm ve tüm ödüller ölçümü istemciye ölümün gelmesiyle her hedefin native ödüllerinin ve ilgili disk onayının tamamlanmasının geç olanını kullanır. İlk 202 cevabı başarı sayılmaz.\n','\nBütünlük: sunucu hatası, kopma, cevapsız girdi, açık ölüm sonucu, tamamlanmamış veya yinelenen ödül, test sürücüsü hatası, açık ölçüm ve eksik ölüm gözlemi. Canı doluyken iksir, saldırı bekleme süresi ve dolu çanta/süresi biten ganimet gibi normal oyun retleri ayrı gösterilir; bunlar sunucu hatası sayılmaz. Eski gözlemci/senaryo sonuçları son kabul koşullarına dahil edilmez. Tüm ara ve tanı koşuları acceptance.json içinde korunur.\n','\nOyun kurallarının korunması, native tablo/olay/RNG eşitliği, kayıt sırasında çökme ve tekrar denemede tek ödül verilmesi ayrıca test edilir. Güncel kaynakla eşleşen doğrulama mühürleri acceptance.json içindedir. Gerçek VDS’deki disk, CPU paylaşımı, ağ ve tarayıcı koşulları bu yerel testin kapsamı dışındadır.\n'])
if not goal:lines.append('\nHedef karşılanmadan güncelleme paketi hazırlanmaz.\n')
(R/'R57_SONUC.md').write_text(''.join(lines));print(json.dumps({'sourceCore':core,'runs':len(rows),'goalThresholdMs':400,'goalMetLocally':goal}))
