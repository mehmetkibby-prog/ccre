// Disposable local-load timeline. No production imports; no gameplay changes.
import {performance} from 'node:perf_hooks';
import {isMainThread,threadId} from 'node:worker_threads';
import {FixedLoop,DEFER_INPUT} from '../working/core511-source/scripts/core511/fixed-loop.mjs';
import {ResidentChannel} from '../working/core511-source/scripts/core511/resident-channel.mjs';
import {ChannelRuntime} from '../working/core511-source/scripts/core511/channel-runtime.mjs';
import {OrderedWriterClient} from '../working/core511-source/scripts/core511/ownership.mjs';
import {GameWriter} from '../working/core511-source/scripts/core511/writer-runtime.mjs';
import {RewardWorkerR533} from '../working/core511-source/scripts/core511/reward-worker-r533.mjs';
const inputs=new WeakMap(),contexts=new WeakMap(),groups=new WeakMap(),results=new WeakMap();
const channelRows=[];
const log=(type,row)=>{const value={type,pid:process.pid,threadId,at:Date.now(),...row};if(type==='death-channel'||type==='death-error'){channelRows.push(value);if(channelRows.length>256)channelRows.shift();}else process.stdout.write('R57_TIMELINE '+JSON.stringify(value)+'\n');};
const control=ChannelRuntime.prototype.control;
ChannelRuntime.prototype.control=async function(method,...args){const value=await control.call(this,method,...args);if(method==='metrics')value.r57DeathTimeline=channelRows;return value;};
const trace=input=>{let r=inputs.get(input);if(!r){r={intent:input.intentId,action:input.action,target:input.targetId,deferred:[]};inputs.set(input,r);}return r;};
const enqueue=FixedLoop.prototype.enqueue;
FixedLoop.prototype.enqueue=function(id,value){const out=enqueue.call(this,id,value);if(value.payload?.action==='attack')Object.assign(trace(value.payload),{actor:id,sequence:value.sequence,received:Date.now()});return out;};
const action=ResidentChannel.prototype.action;
ResidentChannel.prototype.action=function(ctx){
 contexts.set(ctx.kernel,ctx);const r=trace(ctx.input);r.attempts=(r.attempts??0)+1;
 try{const out=action.call(this,ctx);if(out===DEFER_INPUT&&ctx.input.action==='attack'&&r.deferred.length<40){
  const busy=[...ctx.kernel.players].filter(([,p])=>p.barrier).map(([id,p])=>({id,...groups.get(p.barrier)}));
  r.deferred.push({at:Date.now(),ownOverdue:this.checkpoints.overdueR53(ctx.id),targetBusy:this.lanes.busy(['monster:'+ctx.input.targetId]),busy:[...new Map(busy.map(b=>[JSON.stringify([b.actor,b.started,b.action]),b])).values()].slice(0,8)});
 }return out;}finally{contexts.delete(ctx.kernel);}
};
const durable=FixedLoop.prototype.durableGroup;
FixedLoop.prototype.durableGroup=function(ids,...args){
 const ctx=contexts.get(this),start=Date.now(),pending=durable.call(this,ids,...args);
 groups.set(pending,{action:ctx?.input.action,actor:ctx?.id,started:start,players:ids.length});
 if(ctx?.input.action==='attack'){
  const r=trace(ctx.input);r.groupAt=start;r.groupSize=ids.length;r.receivedAtMs=ctx.receivedAtMs;
  pending.then(()=>log('death-channel',{...r,done:Date.now()}),e=>log('death-error',{...r,code:e.code}));
 }
 return pending;
};
const tick=FixedLoop.prototype.tick;
FixedLoop.prototype.tick=function(...args){
 for(const [id,p]of this.players){const input=p.queue[0]?.payload;if(input?.action!=='attack'||!p.barrier)continue;const r=trace(input);if(r.deferred.length<40)r.deferred.push({at:Date.now(),ownBarrier:groups.get(p.barrier)??{unknown:true}});}
 return tick.apply(this,args);
};
const submit=OrderedWriterClient.prototype.submit;
OrderedWriterClient.prototype.submit=function(event){
 const out=submit.call(this,event);if(event.kind==='attack'){
  const r=trace(event.payload.input);r.key=event.key;r.submitAt=Date.now();r.resources=event.payload.resources.length;r.checkpointRawBytes=event.payload.checkpointR53?.bytes;
  out.then(ack=>{r.ackAt=Date.now();r.players=ack.result.players?.length;r.kills=ack.result.result?.body?.hits?.filter(h=>h.killed).length;results.set(ack.result,r);},()=>{});
 }return out;
};
const apply=ResidentChannel.prototype.applyCommit;
ResidentChannel.prototype.applyCommit=async function(value,...args){const r=results.get(value);if(r)r.refreshAt=Date.now();try{return await apply.call(this,value,...args);}finally{if(r)r.refreshedAt=Date.now();}};
const command=GameWriter.prototype.command;
GameWriter.prototype.command=async function(peer,request){
 if(request.operation!=='attack')return command.call(this,peer,request);
 const at=Date.now(),start=performance.now();try{return await command.call(this,peer,request);}
 finally{log(isMainThread?'death-main':'death-worker',{key:request.operationId,actor:request.playerId,start:at,elapsed:performance.now()-start,channel:peer.channel});}
};
const dispatch=RewardWorkerR533.prototype.dispatch;
RewardWorkerR533.prototype.dispatch=function(peer,request){
 if(!this.timelineInstalled){this.timelineInstalled=true;const run=this.lane.run,worker=this;
  this.lane.run=function(work){const key=worker.timelineKey,at=Date.now();return run.call(this,()=>{if(key)log('writer-lane-enter',{key,queued:at,wait:Date.now()-at});return work();});};
 }
 const d=dispatch.call(this,peer,request),atomic=d.atomic,worker=this;
 d.atomic=function(...args){worker.timelineKey=request.operationId;try{return atomic.apply(this,args);}finally{worker.timelineKey=null;}};return d;
};
const send=RewardWorkerR533.prototype.send;
RewardWorkerR533.prototype.send=async function(envelope){const start=Date.now();try{return await send.call(this,envelope);}finally{log('worker-roundtrip',{key:envelope.request.operationId,start,ms:Date.now()-start});}};
