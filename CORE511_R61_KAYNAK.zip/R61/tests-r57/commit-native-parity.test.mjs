import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {spawn} from 'node:child_process';import {once} from 'node:events';
async function replay(t,{kills,targets=kills,original=false,portal=false,weapon=false}){
 const folder=fs.mkdtempSync(path.join(os.tmpdir(),'r56-small-complete-'));t.after(()=>fs.rmSync(folder,{recursive:true,force:true}));const out=path.join(folder,'result.json');
 const child=spawn(process.execPath,['tests-r57/replay-native-commit.mjs'],{cwd:new URL('..',import.meta.url),env:{...process.env,R57_WEAPON:weapon?'1':'0',R57_FORCE_PORTAL:portal?'1':'0',R56_REPLAY_CRASH:'',R56_REPLAY_JOIN_CLAIM:'0',R56_REPLAY_ORIGINAL:original?'1':'0',R56_REPLAY_OUT:out,R56_REPLAY_TARGETS:String(targets),R56_REPLAY_KILLS:String(kills),R56_REPLAY_RECIPIENTS:'15'},stdio:['ignore','pipe','pipe']});
 let output='';for(const stream of [child.stdout,child.stderr])stream.on('data',b=>output=(output+b).slice(-8000));t.after(()=>{if(child.exitCode===null&&child.signalCode===null)child.kill('SIGKILL');});
 const [code,signal]=await once(child,'exit');assert.equal(signal,null,output);assert.equal(code,0,output);return JSON.parse(fs.readFileSync(out));
}
test('20 ordinary kills complete every native reward in the death receipt, with exact immutable R55 action/event/table parity',async t=>{
 const old=await replay(t,{kills:20,targets:60,original:true}),now=await replay(t,{kills:20,targets:60});
 assert.equal(now.summary.normalClaims,300);assert.equal(now.summary.xpClaims,300);assert.equal(now.summary.replayEconomyUnchanged,true);
 assert.deepEqual(now.action,old.action);assert.deepEqual(now.events,old.events);assert.deepEqual(now.delta,old.delta);
});

test('forced native portal + reward preserves every R55 table/event/RNG result, but uses section refresh',async t=>{
 const old=await replay(t,{kills:1,targets:1,original:true,portal:true}),now=await replay(t,{kills:1,targets:1,portal:true});
 assert.equal(now.summary.portals,1);assert.equal(now.summary.normalClaims,15);assert.equal(now.summary.xpClaims,15);
 assert.deepEqual(now.action,old.action);assert.deepEqual(now.events,old.events);assert.deepEqual(now.delta,old.delta);
});

test('equipped weapon counter crossing threshold keeps every R55 reward, stat, event and SQL delta',async t=>{
 const old=await replay(t,{kills:20,targets:60,original:true,weapon:true}),now=await replay(t,{kills:20,targets:60,weapon:true});
 assert.equal(now.summary.normalClaims,300);assert.deepEqual(now.action,old.action);assert.deepEqual(now.events,old.events);assert.deepEqual(now.delta,old.delta);
});
