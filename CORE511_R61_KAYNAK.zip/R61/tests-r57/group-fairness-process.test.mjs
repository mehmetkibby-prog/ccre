import test from 'node:test';import assert from 'node:assert/strict';import {randomUUID} from 'node:crypto';
import {setup,extraPlayer} from '../working/core511-source/scripts/core511/tests/process-fixture.mjs';
import {put} from '../working/core511-source/scripts/core511/tests/pvp-fixture.mjs';
import {until} from '../working/core511-source/scripts/core511/tests/helpers.mjs';
import {ChannelProcessSupervisor} from '../working/core511-source/scripts/core511/process-supervisor.mjs';
const enabled=process.env.CORE511_R57_GROUP_FAIRNESS==='1';
function state(row){const request=randomUUID();return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{row.child.off('message',listen);reject(Error('fairness_state_timeout'));},2000);const listen=m=>{if(m?.type==='test-fairness-state'&&m.request===request){clearTimeout(timer);row.child.off('message',listen);resolve(new Map(m.deferred));}};row.child.on('message',listen);row.child.send({type:'test-fairness-state',request});});}
for(const targetOnly of [false,true])test('old party death gets priority over a newer '+(targetOnly?'monster read lane':'party potion')+' while an independent actor continues',{timeout:40000},async t=>{
 const start=ChannelProcessSupervisor.prototype.start;ChannelProcessSupervisor.prototype.start=function(...args){ChannelProcessSupervisor.prototype.start=start;this.entry=new URL('./group-fairness-channel-fixture.mjs',import.meta.url).pathname;return start.apply(this,args);};t.after(()=>{ChannelProcessSupervisor.prototype.start=start;});
 const s=await setup(t,{shared:true,localCombat:{hp:1}});await s.world.stopJobs();assert.equal((await s.http('ticket')).status,200);const ticket=await s.http('transfer',{channel:4}),p=await s.connect(ticket);
 const peers=[];for(let n=0;n<3;n++){const other=extraPlayer(s,91+n,'fairness-'+n);assert.equal((await other.http()).status,200);const ticket=await other.http('transfer',{channel:4});peers.push({...other,live:await s.connect(ticket)});}
 const [q,r,x]=peers,ids=[s.f.id,q.id,r.id,x.id];
 await s.core.permanentPlayers(ids,()=>{for(const id of ids)s.f.sql.prepare("UPDATE players SET area='forest',x=2700,y=2025,hp=400,max_hp=1000,potions=3,level=40,xp=0,arena_match_id='',attack_one_at=0,stun_until_ms=0,root_until_ms=0 WHERE id=?").run(id);put(s.f.sql,'parties',{id:'fairness-party',leader_id:s.f.id,created_at:1});for(const id of ids.slice(0,targetOnly?2:3))put(s.f.sql,'party_members',{party_id:'fairness-party',player_id:id,joined_at:1});});
 let releaseQ,releaseR;const gateQ=new Promise(r=>releaseQ=r),gateR=new Promise(r=>releaseR=r),seen=[];const command=s.writer.command.bind(s.writer);
 s.writer.command=async(peer,request)=>{if(request.operation==='native_action'&&request.payload.input.action==='use_potion'){seen.push(request.playerId);if(request.playerId===q.id)await gateQ;if(request.playerId===r.id)await gateR;}if(request.operation==='attack'&&request.playerId===s.f.id)seen.push(s.f.id);return command(peer,request);};
 const send=(live,input)=>live.ws.send(JSON.stringify({type:'input',sequence:1,payload:input})),reply=live=>live.packets.flatMap(p=>p.results??[]).find(r=>r.sequence===1);
 try{
  send(q.live,{action:'use_potion'});await until(()=>seen.includes(q.id),3000);
  send(p,{action:'attack',targetId:'golge-local-terminal511',spawnRound:17,ability:0,intentId:'fairness-death'});
  const row=s.supervisor.rows.get(4),end=Date.now()+3000;let deferred=0;
  while(Date.now()<end){deferred=(await state(row)).get(s.f.id)??0;if(deferred)break;await new Promise(r=>setTimeout(r,10));}assert(deferred,'old party death actually reached and deferred in the real channel');
  send(r.live,{action:'use_potion',...(targetOnly?{intentId:'r57-test-resource-wait'}:{})});send(x.live,{action:'use_potion'});await until(()=>reply(x.live),3000);assert.equal(reply(x.live).status,200);
  if(enabled)assert(!seen.includes(r.id),'newer party potion must wait behind the older deferred party death');else await until(()=>seen.includes(r.id),1000);
  releaseQ();await until(()=>reply(q.live),3000);
  if(enabled){await until(()=>reply(p),6000);assert([200,202].includes(reply(p).status));assert(seen.indexOf(s.f.id)<seen.indexOf(r.id)||!seen.includes(r.id));}
  else assert(!seen.includes(s.f.id),'the newer potion really extended the old death wait');
  releaseR();await until(()=>reply(r.live)&&reply(p),6000);assert.equal(reply(r.live).status,200);
  await until(()=>s.f.sql.prepare("SELECT hp FROM monsters WHERE id='golge-local-terminal511'").get().hp===0,6000);
  assert.equal(s.faults.length,0,JSON.stringify(s.faults));for(const live of [p,q.live,r.live,x.live])assert.equal(live.ws.readyState,1);
  console.log(JSON.stringify({groupFairness:enabled,targetOnly,submittedOrder:seen.map(id=>id===s.f.id?'death':id===q.id?'old-potion':id===r.id?'new-potion':'independent-potion'),independentActorCompletedWhileOldPotionHeld:true}));
 }finally{releaseQ();releaseR();}
 await s.writer.rewardWorkerR533.close();
});
