from pathlib import Path
import hashlib, importlib.util, json, sys
R=Path(__file__).resolve().parents[1];E=R/'evidence-r57'
sp=importlib.util.spec_from_file_location('identity',R.parent/'r55_gameplay_work/package/__main__.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
sha=lambda b:hashlib.sha256(b).hexdigest()
inputs={str(p.relative_to(R)):sha(p.read_bytes()) for p in (R/'tests-r57').iterdir() if p.is_file()}
source={'sourceCore':m.core_identity(R/'working/core511-source/scripts/core511'),'profileSha256':sha((R/'r57-candidate.env').read_bytes()),'testInputs':inputs}
if sys.argv[1]=='begin':(E/'r57-focused-start.json').write_bytes(m.encoded(source))
else:
 assert sys.argv[1]=='finish' and json.loads((E/'r57-focused-start.json').read_bytes())==source,'Source/profile/test changed during focused validation'
 logs={}
 for name,count in [('r57-focused.log',89),('r57-off-control.log',35)]:
  b=(E/name).read_bytes();s=b.decode();assert f'# pass {count}\n' in s and '# fail 0\n' in s,name
  logs[name]={'passed':count,'sha256':sha(b)}
 proof={**source,'status':'PASS','distinctChecksPassed':89,'additionalOffControlsPassed':35,'logs':logs,'liveDeployment':False}
 (E/'r57-focused-seal.json').write_bytes(m.encoded(proof));print(json.dumps({k:v for k,v in proof.items() if k not in ('logs','testInputs')}))
