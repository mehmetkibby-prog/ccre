#!/usr/bin/env bash
# Disposable SQLite/process fixtures; never uses a live game DB or credentials.
set -euo pipefail
cd "$(dirname "$0")/.."
python3 tests-r57/seal-validation.py begin
set -a
. ./r57-candidate.env
set +a
export NODE_OPTIONS="--no-warnings --import $PWD/tests/native-fixture-support/register-cloud-fixture.mjs"
export COL_CLOUD_ISOLATED_FIXTURE=1 R35_CORE_REGRESSION=1
export COL_TEST_ACORN_MODULE="$PWD/working/deps/build/node_modules/acorn/dist/acorn.mjs"
export COL_CORE511_SCOPE_MODULE="$PWD/working/deps/build/node_modules/eslint-scope"
export CORE511_R56_REFRESH_READ_PIPELINE=0 CORE511_R56_AUDIT_GATE=0
export CORE511_R56_NONLETHAL_REWARDS=1 CORE511_R56_REWARD_SLICE=1 CORE511_R56_BULK_HITS=1 CORE511_R56_RESOURCE_BATCH=1 CORE511_R56_XP_GROUP=1 CORE511_R56_REWARD_WARMUP=1
export CORE511_R56_CLAIM_ACTOR_JOIN=1 CORE511_R56_COMPLETED_CLAIM=1 CORE511_R56_SMALL_GROUP_EAGER=1 CORE511_R56_WORKER_WINDOW=1 CORE511_R56_CLAIM_SCOPED_DRAIN=1
export CORE511_R56_REWARD_READ_CACHE=1 CORE511_R56_MIST_CONFIG_CACHE=1 CORE511_R56_POTION_ACTOR_JOIN=1
export CORE511_R56_SECTION_READ_GROUP=1 CORE511_R56_SHORT_WRITE_WINDOW=1 CORE511_R56_SMALL_REWARD_COMPLETE=1
node_bin=./tooling/node-v22.22.0-linux-x64/bin/node
CORE511_REWARD_ASYNC_REPLY_R54=0 "$node_bin" --test --test-concurrency=1 --test-skip-pattern='V510 dungeon declarations' tests-r55/*.test.mjs tests-r56/nonlethal-rewards.test.mjs tests-r56/bulk-hits.test.mjs tests/checkpoint-audit-regression-r54.test.mjs tests/commit-refresh-r531.test.mjs tests/joined-death.test.mjs > evidence-r57/regression/final-native-54.log 2>&1
"$node_bin" --test --test-concurrency=1 tests/reward-async-r54.test.mjs tests/reward-pipeline-r54.test.mjs tests/reward-scope-r54.test.mjs tests/reward-worker-r54.test.mjs tests/joined-process-r54.test.mjs tests/checkpoint-wire-r54.test.mjs tests-r56/reward-warmup.test.mjs tests-r56/claim-worker-recovery.test.mjs tests-r56/xp-group.test.mjs tests-r56/xp-group-crash.test.mjs tests-r56/resource-reads.test.mjs tests-r56/reward-roster-fallback.test.mjs tests-r56/claim-actor-join.test.mjs tests-r56/claim-actor-crash.test.mjs tests-r56/completed-claims.test.mjs tests-r56/claim-drain.test.mjs tests-r56/worker-window.test.mjs > evidence-r57/regression/final-async-45.log 2>&1
"$node_bin" --test tests-r56/completed-claim-party.test.mjs > evidence-r57/regression/causal-party-candidate.log 2>&1
"$node_bin" --test tests-r56/reward-read-cache.test.mjs > evidence-r57/regression/final-read-cache-3.log 2>&1
"$node_bin" --test --test-concurrency=1 tests-r56/potion-native-join.test.mjs tests-r56/potion-checkpoint-gate.test.mjs tests-r56/potion-crash.test.mjs tests-r56/potion-process.test.mjs > evidence-r57/regression/potion-join-12.log 2>&1
# Historical assertions expect visual events in replay; retain their original
# uncompressed receipt mode. New potion tests above check default replay.
CORE511_COMPACT_RECEIPT=0 "$node_bin" --test --test-concurrency=1 working/core511-source/scripts/core511/tests/settlement-resources.test.mjs working/core511-source/scripts/core511/tests/potion-read-lanes.test.mjs > evidence-r57/regression/potion-legacy-7.log 2>&1
"$node_bin" --test --test-concurrency=1 working/core511-source/scripts/core511/tests/adventure-r19.test.mjs working/core511-source/scripts/core511/tests/mist-integration-r19.test.mjs > evidence-r57/regression/mist-existing-integration.log 2>&1
"$node_bin" --test --test-concurrency=1 tests-r56/section-group.test.mjs tests-r56/section-group-native.test.mjs > evidence-r57/regression/section-group-4.log 2>&1
"$node_bin" --test --test-concurrency=1 tests-r56/short-write-window.test.mjs tests/reward-group-commit.test.mjs tests/group-crash.test.mjs tests/system-group-r53.test.mjs > evidence-r57/regression/writer-window-15.log 2>&1
CORE511_R57_COMPLETE_LOCAL_REWARDS=0 "$node_bin" --test tests-r56/small-reward-complete.test.mjs > evidence-r57/regression/small-complete-2.log 2>&1
# Exercise every legacy section/owner/fallback check, including the optional
# pipeline's failed-wave path. The selected profile keeps that pipeline off.
CORE511_R56_SECTION_READ_GROUP=0 CORE511_R56_REFRESH_READ_PIPELINE=1 "$node_bin" --test tests/actor-section-r54.test.mjs > evidence-r57/regression/actor-section-52.log 2>&1
export CORE511_R57_COMMIT_SECTIONS=0 CORE511_R57_CHECKPOINT_WIRE=0 CORE511_R57_PORTAL_SECTIONS=0 CORE511_R57_GROUP_FAIRNESS=0 CORE511_R57_ITEM_REFRESH=0 CORE511_R57_REPLY_WIRE=0 CORE511_R57_WEAPON_COUNTER=0 CORE511_R57_CHECKPOINT_SCHEDULE=0 CORE511_R57_CLEAN_JOIN=0 CORE511_R57_JOINED_ACK=0 CORE511_R57_AUTHORITY_READ=0 CORE511_R57_COMBAT_CONTINUATION=0 CORE511_R57_DEATH_BATCH=0 CORE511_R57_COMPLETE_LOCAL_REWARDS=0
export CORE511_R56_NONLETHAL_REWARDS=0 CORE511_R56_REWARD_SLICE=0 CORE511_R56_BULK_HITS=0 CORE511_R56_RESOURCE_BATCH=0 CORE511_R56_XP_GROUP=0 CORE511_R56_CLAIM_ACTOR_JOIN=0 CORE511_R56_COMPLETED_CLAIM=0 CORE511_R56_SMALL_GROUP_EAGER=0 CORE511_R56_WORKER_WINDOW=0 CORE511_R56_CLAIM_SCOPED_DRAIN=0
export CORE511_R56_REWARD_READ_CACHE=0 CORE511_R56_MIST_CONFIG_CACHE=0 CORE511_R56_POTION_ACTOR_JOIN=0
export CORE511_R56_SECTION_READ_GROUP=0 CORE511_R56_SHORT_WRITE_WINDOW=0 CORE511_R56_SMALL_REWARD_COMPLETE=0
"$node_bin" --test tests-r56/completed-claim-party.test.mjs > evidence-r57/regression/causal-party-baseline-fixed.log 2>&1
CORE511_R56_MIST_CONFIG_CACHE=1 "$node_bin" --test tests-r56/mist-config-cache.test.mjs > evidence-r57/regression/mist-config-cache-3.log 2>&1
"$node_bin" --test tests-r56/potion-checkpoint-gate.test.mjs > evidence-r57/regression/potion-gate-off-control.log 2>&1
"$node_bin" --test tests-r56/section-group.test.mjs > evidence-r57/regression/section-group-off-3.log 2>&1
"$node_bin" --test tests-r56/short-write-window.test.mjs > evidence-r57/regression/short-window-off-1.log 2>&1
python3 tests-r57/seal-validation.py finish

printf '207 distinct checks passed; 6 additional flag-off checks passed. No VDS capacity approval.\n'
