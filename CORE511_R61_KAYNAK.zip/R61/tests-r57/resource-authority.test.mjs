import test from 'node:test';import assert from 'node:assert/strict';
import {fixture} from '../tests/checkpoint-fixture-r531.mjs';
import {assertNativeWriteResources as candidate} from '../working/core511-source/scripts/core511/native-write-resources.mjs';
import {assertNativeWriteResources as original} from '../../r56_performance_work/working/core511-source/scripts/core511/native-write-resources.mjs';
import {PlayerWriteScope} from '../working/core511-source/scripts/core511/player-write-scope.mjs';
import {PlayerWriteScope as OriginalScope} from '../../r56_performance_work/working/core511-source/scripts/core511/player-write-scope.mjs';
test('bulk resource ownership equals immutable R56, including last-recipient corruption and rollback',async t=>{
 const s=await fixture(t),sql=s.db.sqlite;sql.exec('CREATE TABLE monsters(id TEXT PRIMARY KEY,channel INTEGER)');
 const payload={resources:['player:p','player:q']},context={actor:'p',epoch:1,peer:s.peer},options={authority:s.authority};
 const cases=['',"UPDATE kernel511_channel_owners SET state='draining' WHERE player_id='q'","UPDATE kernel511_channel_owners SET state='released' WHERE player_id='q'","UPDATE kernel511_channel_owners SET epoch=2 WHERE player_id='q'","UPDATE kernel511_admissions SET epoch=2 WHERE player_id='q'","UPDATE kernel511_admissions SET channel=2 WHERE player_id='q'","UPDATE kernel511_channel_owners SET incarnation='other' WHERE player_id='q'","DELETE FROM players WHERE id='q'","DELETE FROM kernel511_channel_owners WHERE player_id='q'","DELETE FROM kernel511_admissions WHERE player_id='q'","DELETE FROM kernel511_admissions WHERE player_id='q';INSERT INTO kernel511_simulations VALUES('q',1,1,'run',1)","UPDATE kernel511_admissions SET epoch=2 WHERE player_id='q';INSERT INTO kernel511_simulations VALUES('q',1,1,'run',1)","UPDATE kernel511_channel_processes SET online=0"];
 const outcome=fn=>{try{return {value:fn(sql,payload,context,options)};}catch(e){return {code:e.code,message:e.message};}};
 for(const change of cases){sql.exec('SAVEPOINT resource_case');try{if(change)sql.exec(change);assert.deepEqual(outcome(candidate),outcome(original),change);}finally{sql.exec('ROLLBACK TO resource_case;RELEASE resource_case');}}
 sql.exec('BEGIN');try{assert.equal(candidate(sql,payload,context,options),true);}finally{sql.exec('ROLLBACK');}
});
test('bulk initial player scope retains post-native write auditing and fresh reads after rollback',async t=>{
 const s=await fixture(t),sql=s.db.sqlite,scope=new PlayerWriteScope(s.authority);scope.initialize(sql);
 const payload={resources:['player:p','player:q']},context={actor:'p',epoch:1,peer:s.peer};
 const outcome=(run,change)=>{sql.exec('SAVEPOINT player_case');try{if(change)sql.exec(change);return {value:run.call(scope,sql,payload,context,'attack',()=>{sql.prepare('UPDATE players SET gems=gems+1 WHERE id=?').run('q');return scope.ids();})};}catch(e){return {code:e.code};}finally{sql.exec('ROLLBACK TO player_case;RELEASE player_case');}};
 for(const change of ['',"UPDATE kernel511_channel_owners SET state='released' WHERE player_id='q'","UPDATE kernel511_admissions SET epoch=2 WHERE player_id='q'","DELETE FROM kernel511_admissions WHERE player_id='q'"])assert.deepEqual(outcome(scope.run,change),outcome(OriginalScope.prototype.run,change),change);
 sql.exec('BEGIN');try{assert.throws(()=>scope.run(sql,{resources:['player:p']},context,'attack',()=>{sql.prepare("UPDATE players SET gems=gems+1 WHERE id='q'").run();return {};}),{code:'player_write_unlocked_actor'});}finally{sql.exec('ROLLBACK');}
});
