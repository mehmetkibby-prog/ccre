"""Byte comparison to immutable R56; no code, service, config or DB mutation."""
from pathlib import Path
import difflib,hashlib,importlib.util,json
R=Path(__file__).resolve().parents[1];B=R.parent/'r56_performance_work';E=R/'evidence-r57';CORE=Path('core511-source/scripts/core511')
sha=lambda b:hashlib.sha256(b).hexdigest()
def files(root):return {p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file() and not p.is_symlink() and not {'node_modules','__pycache__','.git'}.intersection(p.relative_to(root).parts)}
sp=importlib.util.spec_from_file_location('identity',R.parent/'r55_gameplay_work/package/__main__.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
before=m.core_identity(B/'working'/CORE);after=m.core_identity(R/'working'/CORE)
assert before=='7cfdab81bc01db8e4f2c2b7ad89df5064da06965454df7d532b64f1e707f959b'
old,new=files(B/'working'/CORE),files(R/'working'/CORE);assert old.keys()<=new.keys()
delta=sorted(n for n in new if n not in old or new[n].read_bytes()!=old[n].read_bytes());assert not any(n.startswith('generated/') for n in delta)
a,b=files(B/'working/native510-bb3a6cc689c6'),files(R/'working/native510-bb3a6cc689c6')
assert a.keys()==b.keys() and all(p.read_bytes()==b[n].read_bytes() for n,p in a.items()),'Native drift'
changes=[];diff=[]
for n in delta:
 prior=old[n].read_bytes() if n in old else None;data=new[n].read_bytes()
 changes.append({'path':str(CORE/n),'beforeSha256':None if prior is None else sha(prior),'afterSha256':sha(data),'bytes':len(data),'productionModule':not n.startswith(('benchmark/','tests/'))})
 diff.extend(difflib.unified_diff((prior or b'').decode().splitlines(True),data.decode().splitlines(True),fromfile='a/'+n if prior else '/dev/null',tofile='b/'+n))
proof={'sourceCoreBefore':before,'sourceCoreAfter':after,'nativeFilesByteIdentical':len(a),'generatedFilesByteIdentical':sum(n.startswith('generated/') for n in old),'changes':changes,'liveDeployment':False}
(E/'current-source-proof.json').write_bytes(m.encoded(proof));(E/'R56-R57.diff').write_text(''.join(diff));print(json.dumps({k:v for k,v in proof.items() if k!='changes'}))
