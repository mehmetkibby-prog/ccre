import test from 'node:test';import assert from 'node:assert/strict';
import {setupPvp,put} from '../working/core511-source/scripts/core511/tests/pvp-fixture.mjs';
import {CombatFrames,readCombatBundle} from '../working/core511-source/scripts/core511/combat-frames.mjs';
import {captureWeaponCountersR57,prepareWeaponCountersR57} from '../working/core511-source/scripts/core511/weapon-counter-r57.mjs';
import {COLLECT_INVENTORY_SQL} from '../working/core511-source/scripts/core511/collect-light.mjs';

test('counter refresh matches all original native combat projections, including +5 and an unequipped spare',async t=>{
 const s=await setupPvp(t),{sql}=s;s.reset({area:'forest'});const now=Date.now();
 const inventory=()=>sql.prepare(COLLECT_INVENTORY_SQL).all(s.id),raw=()=>sql.prepare('SELECT * FROM players WHERE id=?').get(s.id);
 const world=sql.prepare('SELECT * FROM world_state WHERE id=1').get();
 const frames=()=>new CombatFrames({view:{player:raw},settings:()=>s.settings,world:()=>world,party:()=>null,arena:()=>null,team:()=>null,participants:()=>false,now:()=>now});
 for(const variant of ['plain','plus5','spare-weapon','empty-counter']){
  sql.prepare("DELETE FROM player_items WHERE player_id=? AND kind='weapon'").run(s.id);
  const enchantments=variant==='empty-counter'?'[]':'[{"kind":"evolution_kills","value":99},{"kind":"evolution_attack","value":20}]';
  put(sql,'player_items',{id:'counter-weapon-a',player_id:s.id,kind:'weapon',item_name:variant==='plus5'?'+5 Fixture':'Fixture',rarity:'white',power:31,role:'avci',enchantments,equipped:1,created_at:1});
  if(variant==='spare-weapon')put(sql,'player_items',{id:'counter-weapon-b',player_id:s.id,kind:'weapon',item_name:'+5 Second',rarity:'white',power:19,role:'avci',enchantments,equipped:0,created_at:2});
  const before=readCombatBundle(sql,s.id,{revision:1,nowMs:now}),c=frames(),sub={data:{inventory:inventory()},revision:1};c.hydrate(before);
  const channel={frames:c,owners:new Map([[s.id,{}]]),revision:1},runtime={channel,world:{subscribers:new Map([[s.id,sub]])},slimReload:{forget:()=>{}}};
  sql.prepare("UPDATE player_items SET enchantments=? WHERE player_id=? AND kind='weapon' AND equipped=1").run(variant==='empty-counter'?'[{"kind":"evolution_kills","value":1}]':'[{"kind":"evolution_kills","value":100},{"kind":"evolution_attack","value":20}]',s.id);
  sql.prepare('UPDATE players SET xp=xp+9,hp=hp-3,hp_revision=hp_revision+1 WHERE id=?').run(s.id);
  let meta;const changes=sql.prepare('SELECT total_changes() n').get().n;
  await s.f.database.atomic(()=>{meta=captureWeaponCountersR57(sql,{result:{body:{hits:[{killed:true}]}}},[s.id],now);});
  assert.equal(sql.prepare('SELECT total_changes() n').get().n,changes,'proof capture writes nothing');
  assert(meta);assert.equal(meta.items[0].combat,undefined,'no full native bundle is serialized');
  const apply=prepareWeaponCountersR57(runtime,{...meta,cold:[s.id]});assert(apply,variant);apply();
  const full=frames(),fresh=readCombatBundle(sql,s.id,{revision:2,nowMs:now});full.hydrate(fresh);
  for(const kind of ['actorFrame','targetFrame','retaliationPlayer'])assert.deepEqual(c.frame(s.id,kind),full.frame(s.id,kind),variant+':'+kind);
  for(const key of ['armorItems','heartbeatState','runeRankEligible','arenaLife','runeArmorJson','pets','labAssociated','afk'])assert.deepEqual(c.entry(s.id)[key],full.entry(s.id)[key],variant+':'+key);
  assert.deepEqual(sub.data.inventory,inventory());
 }
});

test('a malformed last counter projection cannot change any earlier actor frame',()=>{
 const ids=['a','b'],frames=new Map(),subs=new Map(),changes=[];
 for(const id of ids){frames.set(id,{valid:true,actor:id,actorFrame:{id,equipped_weapon_enchantments:'[]'},targetFrame:{id,equipped_weapon_enchantments:'[]'},retaliationPlayer:{id},armorItems:[],pets:[]});subs.set(id,{data:{inventory:[]},revision:1});}
 const runtime={channel:{owners:new Map(ids.map(id=>[id,{}])),frames:{entries:frames,hydrate:b=>changes.push(b)},revision:0},world:{subscribers:subs},slimReload:{forget:()=>{}}};
 const meta={kills:1,cold:ids,items:ids.map(id=>({id,inventory:[],weaponEnchantmentR57:'[]',heartbeatStateR57:{gearDue:false,queue:null},atR57:100}))};
 meta.items[1].heartbeatStateR57.gearDue='false';assert.equal(prepareWeaponCountersR57(runtime,meta),null);assert.deepEqual(changes,[]);assert.equal(subs.get('a').revision,1);
});
