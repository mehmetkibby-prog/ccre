import test from 'node:test';
import assert from 'node:assert/strict';
import {refreshActorSectionsR52} from '../working/core511-source/scripts/core511/actor-section-reuse-r52.mjs';
import {writeReceipt,replayValue} from '../working/core511-source/scripts/core511/compact-receipt.mjs';
import {AdventureChannel} from '../working/core511-source/scripts/core511/adventure-channel.mjs';
function fixture(count=25){
 const rows=new Map(),owners=new Map(),players=new Map(),subscribers=new Map(),frames=new Map(),mutations=[];
 const result={result:{status:200},players:[],monsters:[],sharedRefresh:{version:1,all:false,tables:['players','world_drops'],actors:[]},actorSectionsR52:{version:1,cycle:1,readSections:true,readDrops:true,actor:'p0',actors:[]},engagement:null};
 for(let i=0;i<count;i++){
  const id='p'+i,row={id,area:'forest',channel:1,arena_match_id:'',hp:100,max_hp:100,hp_revision:1,level:40,xp:0,last_seen:1},owner={epoch:2,channel:1,incarnation:'boot'};
  rows.set(id,row);owners.set(id,owner);players.set(id,{epoch:2,barrier:{}});frames.set(id,{valid:true});
  subscribers.set(id,{ownerRow:{...row},data:{area:row.area,channel:1,players:[{...row}],inventory:[],drops:[]},revision:1});
  result.players.push({...row,xp:10});result.sharedRefresh.actors.push(id);result.actorSectionsR52.actors.push({id,owner:{...owner},engagementRef:{kind:i===0?'ack-attack':'resident'}});
 }
 const channel={world:{cycle:1},owners,kernel:{players},frames:{entries:frames},lanes:{busy:()=>true},state:{assertOwner:()=>{}},presence:{merge:row=>row},view:{player:id=>rows.get(id),engagements:new Map(),setPlayer:row=>{mutations.push(row.id);rows.set(row.id,row);},setEngagement:()=>{}},setMonster:m=>mutations.push(m.id)};
 const runtime={channel,world:{subscribers},dungeon:{locked:()=>false},slimReload:{forget:()=>{}}};
 const read=actors=>({version:1,complete:true,cycle:1,actors:actors.map(({actor})=>({id:actor,owner:{...owners.get(actor)},player:{...result.players.find(p=>p.id===actor)},engagement:null,drops:[]}))});
 return {runtime,result,rows,owners,players,subscribers,mutations,read};
}

function direct(){
 const s=fixture(),now=Date.now();s.runtime.clock=()=>now;
 s.result.actorCommitSectionsR57={...s.read(s.result.players.map(row=>({actor:row.id}))),readAtMs:now};return s;
}

function portalFixture(){
 const s=direct(),now=Date.now(),portal={id:'portal-new',run_id:'run-new',channel:1,area:'forest',x:2700,y:2025,opens_ms:now-20,closes_ms:now+45000,gold:0,capacity:4,entered:0,source_key:'monster:1'};
 s.result.portalCreationR57={version:1,cycle:1,channel:1,capturedAtMs:now,portals:[portal]};
 s.result.sharedRefresh.all=true;s.result.sharedRefresh.tables.push('adventure_portals','adventure_runs');
 const adventure=s.runtime.adventure={portals:new Map(),bundles:new Map(),sent:new Map(),runs:new Map(),loot:new Map(),channel:s.runtime.channel};
 for(const [id,sub] of s.subscribers){adventure.bundles.set(id,{portals:[],run:null,profiles:[],loot:[]});sub.data.adventure511={portals:[],run:null,profiles:[],loot:[]};}
 return {...s,portal,adventure};
}
test('one native portal becomes visible to all 25 recipients without any cold actor read',async()=>{
 const s=portalFixture();let reads=0;
 assert.equal(await refreshActorSectionsR52(s.runtime,s.result,async actors=>{reads++;return s.read(actors);}),true);assert.equal(reads,0);assert.equal(s.mutations.length,25);
 for(const [id,sub] of s.subscribers){assert.deepEqual(sub.data.adventure511.portals,[s.portal]);assert.deepEqual(s.adventure.bundles.get(id).portals,[s.portal]);assert.deepEqual(AdventureChannel.prototype.project.call(s.adventure,id,Date.now()).portals,[s.portal]);}
});
test('stale portal, changed membership image, foreign cycle and unrelated cold writes fall back atomically',async()=>{
 for(const change of [s=>s.result.portalCreationR57.cycle++,s=>s.result.portalCreationR57.capturedAtMs-=1001,s=>s.adventure.portals.set(s.portal.id,{...s.portal,entered:1}),s=>s.subscribers.get('p24').data.adventure511=null,s=>s.adventure.bundles.get('p24').run={id:s.portal.run_id},s=>s.result.sharedRefresh.tables.push('player_items'),s=>delete s.result.portalCreationR57]){
  const s=portalFixture();change(s);const before=JSON.stringify([...s.adventure.portals]);assert.equal(await refreshActorSectionsR52(s.runtime,s.result,async actors=>s.read(actors)),false);assert.deepEqual(s.mutations,[]);assert.equal(JSON.stringify([...s.adventure.portals]),before);
 }
});
test('durable replay cannot reuse a historical new-portal assertion',()=>{
 const s=portalFixture(),ack={key:'portal-command',result:s.result};
 const stored=JSON.parse(writeReceipt(ack,'portal-command').response);assert.equal(stored.result.portalCreationR57,undefined);assert.equal(replayValue(ack).result.portalCreationR57,undefined);assert(s.result.portalCreationR57);
});
