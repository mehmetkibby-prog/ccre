import test from 'node:test';import assert from 'node:assert/strict';
import {compactJoinedAckR57 as compact,expandJoinedAckR57 as expand} from '../working/core511-source/scripts/core511/joined-ack-r57.mjs';
import {normalizeEncounterPlan} from '../working/core511-source/scripts/core511/encounter-clock.mjs';
const enabled=process.env.CORE511_R57_JOINED_ACK==='1';
const payload=()=>({current:{id:'p',hp:90,x:12,position_revision:2},pve:{base:null,current:{player_id:'p',updated_at_ms:100,hit_sequence:0,attackers489:JSON.stringify(Object.fromEntries(Array.from({length:20},(_,i)=>['monster-'+i,{monster_id:'monster-'+i,spawn_round:1,next_hit_at_ms:100,last_skill_at_ms:0}])))} }});
test('exact journal echo becomes a bounded digest and reconstructs every original byte',()=>{
 const p=payload(),value={saved:p.current,encounter:p.pve.current},row=compact('p',p,value);
 if(enabled)assert(Buffer.byteLength(JSON.stringify(row))<Buffer.byteLength(JSON.stringify(value))/10);else assert.deepEqual(row,{id:'p',...value});
 assert.deepEqual(expand(row,'p',p),{id:'p',...value});
});
test('native clock normalization reconstructs exactly; unexpected saved state retains the full ACK',()=>{
 const p=payload();p.pve.base={...p.pve.current,updated_at_ms:200};
 const value={saved:p.current,encounter:normalizeEncounterPlan(p.pve).current},row=compact('p',p,value);assert.deepEqual(expand(row,'p',p),{id:'p',...value});
 for(const changed of [{...value,saved:{...p.current,hp:88}},{...value,encounter:{...value.encounter,updated_at_ms:201}},{...value,extra:'native'}])assert.deepEqual(compact('p',p,changed),{id:'p',...changed});
});
test('digest cannot acknowledge another actor, changed HP, changed encounter or extra wire fields',()=>{
 const p=payload(),row=compact('p',p,{saved:p.current,encounter:p.pve.current});if(!enabled)return;
 for(const bad of [{...row,id:'q'},{...row,joinedAckSha256R57:'0'.repeat(64)},{...row,extra:true}])assert.throws(()=>expand(bad,'p',p),e=>e.code==='checkpoint_join_ack');
 assert.throws(()=>expand(row,'p',{...p,current:{...p.current,hp:89}}),e=>e.code==='checkpoint_join_ack');
 assert.throws(()=>expand(row,'p',{...p,pve:{...p.pve,current:{...p.pve.current,hit_sequence:1}}}),e=>e.code==='checkpoint_join_ack');
});
