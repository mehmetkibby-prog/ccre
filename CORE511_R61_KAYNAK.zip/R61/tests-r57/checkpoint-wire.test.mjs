import test from 'node:test';
import assert from 'node:assert/strict';
import {randomBytes} from 'node:crypto';
import {packCheckpointR54,unpackCheckpointR54} from '../working/core511-source/scripts/core511/checkpoint-wire-r54.mjs';

test('medium party journals use a lossless bounded wire image before the old 224 KiB limit',()=>{
 const encounter=JSON.stringify(Object.fromEntries(Array.from({length:32},(_,i)=>['monster-'+i,{monster_id:'monster-'+i,spawn_round:1,next_hit_at_ms:12345,last_skill_at_ms:12300}])));
 const value={actors:Array.from({length:15},(_,i)=>({actor:'player-'+i,epoch:2,payload:{base:{hp:100},current:{hp:90},pve:{base:{attackers489:encounter},current:{attackers489:encounter}}}})),combat:{monsters:[],participants:[],bossParticipants:[],combatEvents:[]}};
 const bytes=Buffer.byteLength(JSON.stringify(value));assert(bytes>16*1024&&bytes<224*1024);
 const packed=packCheckpointR54(value);
 if(process.env.CORE511_R57_CHECKPOINT_WIRE!=='1'){assert.equal(packed,value);return;}
 assert.equal(packed.codec,'deflate-r57');assert(Buffer.byteLength(JSON.stringify(packed))<bytes/4);
 assert.deepEqual(unpackCheckpointR54(packed),value);
 for(const bad of [{...packed,sha256:'0'.repeat(64)},{...packed,bytes:1},{...packed,bytes:225*1024},{...packed,data:packed.data.slice(5)},{...packed,codec:'unknown'},{...packed,extra:1}])assert.throws(()=>unpackCheckpointR54(bad),{code:'checkpoint_join_encoding'});
});
test('small or incompressible medium images retain their original identity',()=>{
 for(const value of [{actors:[],combat:{}},{data:randomBytes(50000).toString('base64')}])assert.equal(packCheckpointR54(value),value);
});
