import test from 'node:test';import assert from 'node:assert/strict';
import {olderGroupWaitingR57,rememberDeferredGroupR57} from '../working/core511-source/scripts/core511/group-fairness-r57.mjs';
function fixture(){
 const ids=['a','b','c','outside'],input={action:'attack'},players=new Map(ids.map(id=>[id,{epoch:1,queue:[],barrier:null,suspended:false,passive:false}])),owners=new Map(ids.map(id=>[id,{epoch:1}])),rows=new Map(ids.map(id=>[id,{id,area:'forest',channel:1}]));
 players.get('a').queue=[{payload:input}];players.get('b').barrier=Promise.resolve();
 const kernel={running:true,metrics:{ticks:1},players,state:{channel:1,owners,read:(_,id)=>rows.get(id)}};
 const remember=()=>rememberDeferredGroupR57({kernel,id:'a',input,inputOrder:100,ids:ids.slice(0,3)});
 const blocked=(id='c',inputOrder=101,ids=[id])=>olderGroupWaitingR57({kernel,id,input:{action:'use_potion'},inputOrder,ids});return {kernel,input,rows,remember,blocked};
}
test('older pending party survives ticks and existing commit, without acquiring any owner',()=>{
 const s=fixture(),owners=[...s.kernel.state.owners];s.remember();assert(s.blocked());assert(!s.blocked('outside'));assert(!s.blocked('c',99));assert(s.blocked('outside',101,['outside','c']));
 s.kernel.metrics.ticks++;s.kernel.players.get('a').barrier=Promise.resolve();assert(s.blocked());
 s.kernel.players.get('a').queue.shift();assert(!olderGroupWaitingR57({kernel:s.kernel,id:'a',input:s.input,inputOrder:100,ids:['a','b','c']}));
 // The popped current head is still live, then disappears once executed.
 s.kernel.players.get('a').queue.unshift({payload:s.input});assert(s.blocked());s.kernel.players.get('a').queue.shift();assert(!s.blocked());assert.deepEqual([...s.kernel.state.owners],owners);
});
test('retired head/epoch/owner or suspended source releases preference',()=>{
 for(const invalidate of [s=>s.kernel.players.get('a').queue.shift(),s=>s.kernel.players.get('a').epoch++,s=>s.kernel.state.owners.set('a',{epoch:2}),s=>s.kernel.players.get('a').suspended=true]){const s=fixture();s.remember();assert(s.blocked());invalidate(s);assert(!s.blocked());}
});
test('special, foreign, suspended or missing members cannot reserve priority',()=>{
 for(const change of [s=>s.rows.get('b').area='arena',s=>s.rows.get('b').channel=2,s=>s.kernel.players.get('b').suspended=true,s=>s.kernel.players.delete('b'),s=>s.kernel.running=false]){const s=fixture();change(s);s.remember();assert(!s.blocked());}
});
test('newer monster readers outside the reward party cannot starve its earlier death',()=>{
 const s=fixture();rememberDeferredGroupR57({kernel:s.kernel,id:'a',input:s.input,inputOrder:100,ids:['a','b'],resources:['monster:m']});
 const probe=(resources,order=101)=>olderGroupWaitingR57({kernel:s.kernel,id:'outside',input:{action:'use_potion'},inputOrder:order,ids:['outside'],resources});
 assert(probe(['monster:m']));assert(!probe(['monster:other']));assert(!probe(['monster:m'],99));
 s.kernel.players.get('a').queue.shift();assert(!probe(['monster:m']));
});
