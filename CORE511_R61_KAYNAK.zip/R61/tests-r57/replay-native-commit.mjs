// Deterministic attack replay through the actual GameWriter/authority/receipt/
// SQLite/fsync path. No sockets, no capacity claim, no production database.
import fs from 'node:fs';import assert from 'node:assert/strict';
import {setup} from '../tests/native-attack-fixture-r53-1.mjs';
const {GameWriter}=await import(process.env.R56_REPLAY_ORIGINAL==='1'?'../../r55_gameplay_work/working/core511-source/scripts/core511/writer-runtime.mjs':'../working/core511-source/scripts/core511/writer-runtime.mjs');
import {readAttackFrame} from '../working/core511-source/scripts/core511/attack-writer.mjs';
import {xpGroupStatsR56} from '../working/core511-source/scripts/core511/xp-group-r56.mjs';
import {bulkHitStatsR56} from '../working/core511-source/scripts/core511/bulk-hits-r56.mjs';
import {nonlethalStatsR56} from '../working/core511-source/scripts/core511/nonlethal-rewards-r56.mjs';
import {ResidentState} from '../working/core511-source/scripts/core511/resident-state.mjs';
import {ActorCheckpoints} from '../working/core511-source/scripts/core511/actor-checkpoint.mjs';
const cleanup=[],s=await setup({after:f=>cleanup.push(f)}),sql=s.sql,TARGETS=Number(process.env.R56_REPLAY_TARGETS??900),KILLS=Number(process.env.R56_REPLAY_KILLS??300),RECIPIENTS=Number(process.env.R56_REPLAY_RECIPIENTS??15);
const trace=process.env.R56_REPLAY_SQL?(await import('../tests-r56/sql-trace-r56.mjs')).installSQLTraceR56(sql):null;
assert(Number.isSafeInteger(TARGETS)&&TARGETS<=1024&&TARGETS>=1&&Number.isSafeInteger(KILLS)&&KILLS<=TARGETS&&KILLS>=0&&Number.isSafeInteger(RECIPIENTS)&&RECIPIENTS>=1&&RECIPIENTS<=25);
const put=(table,row)=>sql.prepare('INSERT INTO '+table+'('+Object.keys(row).join(',')+') VALUES('+Object.keys(row).map(()=>'?').join(',')+')').run(...Object.values(row));
try{
 s.reset({role:'arkanist',ability:2,hp:1,patch:{x:2700,y:2025}});
 sql.exec('DELETE FROM party_members;DELETE FROM parties;DELETE FROM monster_participants;UPDATE monsters SET hp=0;UPDATE players SET created_at=1;');
 const actor=sql.prepare('SELECT * FROM players WHERE id=?').get(s.id),monster=sql.prepare('SELECT * FROM monsters WHERE id=?').get(s.mid),ids=[s.id],mids=[s.mid];
 for(let i=1;i<RECIPIENTS;i++){const id='r56-replay-'+i;put('players',{...actor,id,name:id,account_id:null,x:2700+i,y:2025});ids.push(id);}
 put('parties',{id:'r56-party',leader_id:s.id,created_at:1});for(const id of ids)put('party_members',{party_id:'r56-party',player_id:id,joined_at:1});
 for(let i=1;i<TARGETS;i++){const id='golge-r56-replay-'+i;put('monsters',{...monster,id,x:2750+i%10,y:2025+Math.floor(i/10),hp:200,max_hp:200});mids.push(id);}
 sql.prepare('UPDATE players SET last_seen=110,level=40,xp=0,attack_one_at=0,attack_two_at=0,attack_three_at=0,attack_four_at=0,combat_lock_until_ms=0,stun_until_ms=0,root_until_ms=0').run();
 for(const [i,mid]of mids.entries()){sql.prepare('UPDATE monsters SET hp=?,max_hp=200,x=?,y=? WHERE id=?').run(i<KILLS?1:200,2750+i%10,2025+Math.floor(i/10),mid);for(const id of ids)put('monster_participants',{monster_id:mid,spawn_round:1,player_id:id,created_at:100});}
 if(process.env.R57_WEAPON==='1')put('player_items',{id:'r57-native-weapon',player_id:s.id,kind:'weapon',item_name:'+5 Test weapon',rarity:'white',power:0,role:'arkanist',enchantments:'[{"kind":"evolution_kills","value":99}]',equipped:1,created_at:1});
 sql.function('unixepoch',()=>1792800000);
 const writer=new GameWriter(s.f.database,{realmId:'r56-replay',ports:{guard:()=>true},clock:()=>110000});await writer.initialize();
 if(process.env.R57_FORCE_PORTAL==='1'){const config=JSON.parse(sql.prepare('SELECT value FROM adventure_settings WHERE id=1').get().value);sql.prepare('UPDATE adventure_settings SET value=? WHERE id=1').run(JSON.stringify({...config,enabled:true,chancePercent:100,minLevel:1,killCooldownSeconds:120}));}
 const peer={channel:1,incarnation:'replay-owner'};await writer.register(peer);let owner;
 for(const id of ids){const result=await writer.admit(id,peer,{sessionId:'session-'+id,guard:()=>true});if(id===s.id)owner=result;}
 const settings={...sql.prepare('SELECT * FROM game_settings WHERE id=1').get(),...sql.prepare('SELECT * FROM combat_settings WHERE id=1').get()},frame=readAttackFrame(sql,s.id,s.mid,writer.services.globals);
 const payload={nowMs:110000,receivedAtMs:110000,seed:'9'.repeat(64),input:{action:'attack',targetId:s.mid,spawnRound:1,ability:2,intentId:'r56-replay'},expected:{...frame,settings},resources:[...ids.map(id=>'player:'+id),...mids.map(id=>'monster:'+id)],localScope:{kind:'mixed',area:'forest',targets:mids.map(id=>({id,spawnRound:1})),narrow:true}};
 const tables=sql.prepare("SELECT name FROM main.sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE 'kernel511_%' ORDER BY name").all().map(r=>r.name);
 const snapshot=()=>Object.fromEntries(tables.map(t=>{const info=sql.prepare('PRAGMA table_info("'+t+'")').all(),keys=info.filter(c=>c.pk).sort((a,b)=>a.pk-b.pk).map(c=>c.name),rows=sql.prepare('SELECT '+(keys.length?'':'rowid __key,')+'* FROM "'+t+'"').all();return [t,new Map(rows.map(r=>[JSON.stringify(keys.length?keys.map(k=>r[k]):r.__key),r]))];}));
 const delta=(before,after)=>Object.fromEntries(tables.map(t=>[t,[...new Set([...before[t].keys(),...after[t].keys()])].sort().flatMap(key=>{const a=before[t].get(key),b=after[t].get(key);if(JSON.stringify(a)===JSON.stringify(b))return [];if(!a||!b)return [{key,before:a??null,after:b??null}];return [{key,fields:Object.fromEntries(Object.keys(b).filter(k=>!Object.is(a[k],b[k])).map(k=>[k,[a[k],b[k]]]))}];})]).filter(([,v])=>v.length));
 const before=snapshot(),request={playerId:s.id,epoch:owner.epoch,sequence:1,operationId:'replay-attack',operation:'attack',payload};
 const armCrash=request=>{if(!process.env.R56_REPLAY_CRASH)return;
  const phase=process.env.R56_REPLAY_CRASH;assert(['before','after'].includes(phase));
  const baselineCounts={xp:sql.prepare('SELECT COUNT(*) n FROM monster_xp_claims').get().n,normal:sql.prepare('SELECT COUNT(*) n FROM normal_reward_claims').get().n,defeats:sql.prepare('SELECT COUNT(*) n FROM normal_defeats').get().n};
  const stop=()=>{const state={phase,file:s.f.file,request,peer,baselineCounts,counts:{xp:sql.prepare('SELECT COUNT(*) n FROM monster_xp_claims').get().n,normal:sql.prepare('SELECT COUNT(*) n FROM normal_reward_claims').get().n,defeats:sql.prepare('SELECT COUNT(*) n FROM normal_defeats').get().n},xpGroup:xpGroupStatsR56(sql)};const fd=fs.openSync(process.env.R56_REPLAY_STATE,'wx',0o600);fs.writeFileSync(fd,JSON.stringify(state));fs.fsyncSync(fd);fs.closeSync(fd);process.kill(process.pid,'SIGKILL');};
  if(phase==='before'){const commit=s.f.database.commitWrites.bind(s.f.database);s.f.database.commitWrites=()=>{stop();return commit();};}
  else{const durable=s.f.database.durableAfterCommit.bind(s.f.database);s.f.database.durableAfterCommit=(...args)=>Promise.resolve(durable(...args)).then(()=>stop());}
 };
 if(process.env.R56_REPLAY_JOIN_CLAIM!=='1')armCrash(request);
 let profiler,post;
 if(process.env.R56_REPLAY_CPU){const {Session}=await import('node:inspector');profiler=new Session();profiler.connect();post=(method,params={})=>new Promise((resolve,reject)=>profiler.post(method,params,(e,v)=>e?reject(e):resolve(v)));await post('Profiler.enable');await post('Profiler.setSamplingInterval',{interval:500});await post('Profiler.start');}
 trace?.begin();const at=performance.now(),ack=await writer.command(peer,request),wallMs=performance.now()-at;trace?.end();
 if(profiler){const {profile}=await post('Profiler.stop');fs.writeFileSync(process.env.R56_REPLAY_CPU,JSON.stringify(profile));profiler.disconnect();}
 if(trace)fs.writeFileSync(process.env.R56_REPLAY_SQL,JSON.stringify(trace.report(),null,2));
 assert.equal(ack.result.result.status,200,JSON.stringify(ack));assert.equal(ack.result.result.body.hits.length,TARGETS);assert.equal(ack.result.result.body.hits.filter(h=>h.killed).length,KILLS);
 const change=delta(before,snapshot()),xp=sql.prepare('SELECT COUNT(*) n FROM monster_xp_claims').get().n,normal=sql.prepare('SELECT COUNT(*) n FROM normal_reward_claims').get().n;
 const replay=await writer.command(peer,request);assert.equal(replay.result.result.status,200);assert.equal(sql.prepare('SELECT COUNT(*) n FROM monster_xp_claims').get().n,xp);assert.equal(sql.prepare('SELECT COUNT(*) n FROM normal_reward_claims').get().n,normal);

 if(process.env.CORE511_R57_COMMIT_SECTIONS==='1'&&process.env.R56_REPLAY_ORIGINAL!=='1'){
  const section=ack.result.itemRefreshR57??ack.result;assert(section.actorSectionsR52,'native operation must be section certified');
  if(process.env.R57_FORCE_PORTAL==='1'){assert.equal(ack.result.portalCreationR57?.portals.length,1);assert.equal(replay.result.portalCreationR57,undefined);}
  assert.equal(section.actorCommitSectionsR57?.actors.length,RECIPIENTS,'live fsync ACK carries all recipient sections');
  assert.equal(replay.result.actorCommitSectionsR57,undefined,'receipt replay must force a fresh reader');assert.equal(replay.result.itemRefreshR57,undefined);
  const {readReceipt}=await import('../working/core511-source/scripts/core511/compact-receipt.mjs');
  const stored=readReceipt(sql,sql.prepare('SELECT response FROM kernel511_channel_receipts WHERE operation_id=?').get(request.operationId).response);
  assert.equal(stored.result.actorCommitSectionsR57,undefined,'ephemeral sections must never be durable');
 }
 let joinedClaim;
 if(process.env.R56_REPLAY_JOIN_CLAIM==='1'){
  assert(KILLS>4&&KILLS<=20);const state=new ResidentState(1),cp=new ActorCheckpoints({state,submit:()=>assert.fail('joined claim cannot submit separate actor writes')});
  for(const id of ids){const row=sql.prepare('SELECT * FROM players WHERE id=?').get(id);state.put('players',{...row,cycle:1});state.claim(id,writer.authority.owner(id).epoch);cp.hydrate(row);state.patch('players',id,{hp:row.hp-1,hp_revision:row.hp_revision+1});}
  const tokens=ids.map(id=>cp.captureR53(id)),targetIds=mids.slice(Math.max(0,KILLS-10),KILLS),fresh=readAttackFrame(sql,s.id,'',writer.services.globals),current=state.read('players',s.id);
  const claim={playerId:s.id,epoch:owner.epoch,sequence:2,operationId:'replay-joined-claim',operation:'native_action',payload:{nowMs:110000,receivedAtMs:110000,seed:'8'.repeat(64),input:{action:'claim_rewards',rewardTargets:targetIds.map(id=>({id,spawnRound:1}))},expected:{player:{...fresh.player,hp:current.hp,hp_revision:current.hp_revision},settings},resources:[...ids.map(id=>'player:'+id),...targetIds.map(id=>'monster:'+id)],localScope:{kind:'claim',targets:targetIds.map(id=>({id,spawnRound:1}))},claimActorsR56:tokens.map(t=>({actor:t.id,epoch:t.entry.epoch,payload:t.payload}))}};
  armCrash(claim);const started=performance.now(),answer=await writer.command(peer,claim);assert.equal(answer.result.result.status,200,JSON.stringify(answer));
  assert.equal(answer.result.claimActorsR56.length,RECIPIENTS);for(const t of tokens){cp.finishR53(t,answer.result.claimActorsR56.find(r=>r.id===t.id));assert.equal(sql.prepare('SELECT hp FROM players WHERE id=?').get(t.id).hp,t.payload.current.hp);}
  const awarded=sql.prepare('SELECT COUNT(*) n FROM normal_reward_claims').get().n;assert.equal(awarded,KILLS*RECIPIENTS);assert.equal(sql.prepare('SELECT COUNT(*) n FROM monster_xp_claims').get().n,xp);
  await writer.command(peer,claim);assert.equal(sql.prepare('SELECT COUNT(*) n FROM normal_reward_claims').get().n,awarded);for(const t of tokens)assert.equal(sql.prepare('SELECT hp FROM players WHERE id=?').get(t.id).hp,t.payload.current.hp);
  joinedClaim={actors:RECIPIENTS,normalBefore:normal,normalAfter:awarded,xpUnchanged:true,replayUnchanged:true,actorCheckpointAndClaimCommittedTogether:true,wallMs:performance.now()-started};
  if(process.env.CORE511_R56_COMPLETED_CLAIM==='1'){
   assert(RECIPIENTS>=2);for(const [i,id]of ids.slice(0,2).entries())put('world_drops',{id:'r56-finalize-'+i,owner_id:id,monster_id:targetIds[0],kind:'weapon',item_name:'Native test',rarity:'white',power:1,amount:1,role:'arkanist',enchantments:'__pending__',x:2750,y:2025,expires_at:230,collectible_at:110});
   const row=sql.prepare('SELECT * FROM players WHERE id=?').get(s.id);state.put('players',{...row,cycle:1});cp.hydrate(row);state.patch('players',s.id,{hp:row.hp-1,hp_revision:row.hp_revision+1});const token=cp.captureR53(s.id),fresh=readAttackFrame(sql,s.id,'',writer.services.globals);
   const narrow={...claim,sequence:3,operationId:'replay-completed-claim',payload:{...claim.payload,resources:['player:'+s.id,...targetIds.map(id=>'monster:'+id)],localScope:{...claim.payload.localScope,completedR56:true},claimActorsR56:[{actor:token.id,epoch:token.entry.epoch,payload:token.payload}],expected:{...claim.payload.expected,player:{...fresh.player,hp:token.payload.current.hp,hp_revision:token.payload.current.hp_revision}}}};
   const answer=await writer.command(peer,narrow);assert.equal(answer.result.result.status,200,JSON.stringify(answer));assert.equal(answer.result.result.body.processed,0);assert.deepEqual(answer.result.players.map(p=>p.id),[s.id]);cp.finishR53(token,answer.result.claimActorsR56[0]);assert.equal(sql.prepare('SELECT COUNT(*) n FROM normal_reward_claims').get().n,awarded);
   assert.notEqual(sql.prepare("SELECT enchantments FROM world_drops WHERE id='r56-finalize-0'").get().enchantments,'__pending__');assert.equal(sql.prepare("SELECT enchantments FROM world_drops WHERE id='r56-finalize-1'").get().enchantments,'__pending__');
   const players=sql.prepare('SELECT id,hp,hp_revision,xp,gems FROM players ORDER BY id').all();await writer.command(peer,narrow);assert.deepEqual(sql.prepare('SELECT id,hp,hp_revision,xp,gems FROM players ORDER BY id').all(),players);
   // The old hint remains, but the CURRENT defeat no longer certifies a no-op.
   const prior=sql.prepare('SELECT rewards_completed_at t FROM normal_defeats WHERE monster_id=? AND spawn_round=1').get(targetIds[0]).t;sql.prepare('UPDATE normal_defeats SET rewards_completed_at=0 WHERE monster_id=? AND spawn_round=1').run(targetIds[0]);
   await assert.rejects(writer.command(peer,{...narrow,sequence:4,operationId:'replay-stale-completion'}),error=>error.code==='local_claim_requires_shared');
   assert.deepEqual(sql.prepare('SELECT id,hp,hp_revision,xp,gems FROM players ORDER BY id').all(),players);assert.equal(writer.authority.owner(s.id).sequence,3);sql.prepare('UPDATE normal_defeats SET rewards_completed_at=? WHERE monster_id=? AND spawn_round=1').run(prior,targetIds[0]);
   joinedClaim.completedNarrow={nativeProcessed:0,onlyCallerWritten:true,otherPartyActorsNotLeased:true,onlyOwnPendingGearFinalized:true,replayUnchanged:true,staleHintRejectedBeforeWrites:true};
  }
 }
 const summary={source:process.env.R56_REPLAY_ORIGINAL==='1'?'immutable-R55':'R56-working',targets:TARGETS,kills:KILLS,recipients:RECIPIENTS,wallMs,xpClaims:xp,normalClaims:normal,replayEconomyUnchanged:true,portals:sql.prepare('SELECT COUNT(*) n FROM adventure_portals').get().n,nonlethal:nonlethalStatsR56(sql),bulk:bulkHitStatsR56(sql),xpGroup:xpGroupStatsR56(sql)};
 fs.writeFileSync(process.env.R56_REPLAY_OUT,JSON.stringify({summary,...(joinedClaim?{joinedClaim}:{}),action:ack.result.result,events:ack.result.events,delta:change}));console.log(JSON.stringify({...summary,joinedClaim}));writer.maintenance.close();
}finally{for(const fn of cleanup.reverse())await fn();}
