import test from 'node:test';import assert from 'node:assert/strict';
import {counterOnlyInventoryR57} from '../working/core511-source/scripts/core511/weapon-counter-r57.mjs';
const item={id:'weapon',player_id:'p',kind:'weapon',item_name:'+5 Sword',rarity:'white',power:20,role:'avci',enchantments:'[{"kind":"evolution_kills","value":99},{"kind":"evolution_attack","value":20}]',equipped:1,created_at:1,expires_at_ms:0,sale_locked499:0};
const bump=()=>({...item,enchantments:'[{"kind":"evolution_kills","value":100},{"kind":"evolution_attack","value":20}]'});
test('counter-only updates across an evolution threshold preserve the manual-evolution stat contract',()=>{
 assert(counterOnlyInventoryR57([item],[bump()],'p',1));assert(counterOnlyInventoryR57([{...item,enchantments:'[]'}],[{...item,enchantments:'[{"kind":"evolution_kills","value":1}]'}],'p',1));
 assert(counterOnlyInventoryR57([item],[item],'p',1));
});
test('changed power, equip, owner, identity, stat enchantment, impossible jump or malformed counters force full refresh',()=>{
 const bad=[{...bump(),power:21},{...bump(),equipped:0},{...bump(),player_id:'q'},{...bump(),id:'other'},{...bump(),enchantments:'[{"kind":"evolution_kills","value":100},{"kind":"evolution_attack","value":21}]'},{...bump(),enchantments:'[{"kind":"evolution_kills","value":200},{"kind":"evolution_attack","value":20}]'},{...bump(),enchantments:'[{"kind":"evolution_kills","value":100},{"kind":"evolution_kills","value":100},{"kind":"evolution_attack","value":20}]'},{...bump(),enchantments:'{}'},{...bump(),extra:1}];
 for(const row of bad)assert.equal(counterOnlyInventoryR57([item],[row],'p',1),false);
 assert.equal(counterOnlyInventoryR57([item],[bump(),bump()],'p',1),false);assert.equal(counterOnlyInventoryR57([item],[],'p',1),false);
});
