import test from 'node:test';import assert from 'node:assert/strict';
import {ActorCheckpoints,CHECKPOINT_FIELDS} from '../working/core511-source/scripts/core511/actor-checkpoint.mjs';
import {ResidentState} from '../working/core511-source/scripts/core511/resident-state.mjs';
const paced=process.env.CORE511_R57_CHECKPOINT_SCHEDULE==='1',settle=()=>new Promise(r=>setImmediate(r));
function fixture(){
 const state=new ResidentState(1),sent=[];let now=0,release;const gate=new Promise(r=>release=r);
 const cp=new ActorCheckpoints({state,clock:()=>now,submit:async e=>{sent.push(e);await gate;return {key:e.key,result:{saved:e.payload.current}};}});
 for(let i=0;i<25;i++){const id='p'+i,row={...Object.fromEntries(CHECKPOINT_FIELDS.map(k=>[k,0])),id,account_id:'a'+i,area:'forest',channel:1,arena_match_id:'',realtime_scope_version:0,max_hp:100,hp:100,motion_stream_id:''};state.put('players',row);state.claim(id,1);cp.hydrate(row);state.patch('players',id,{x:1,position_revision:1});}
 return {state,cp,sent,release,time:v=>now=v};
}
test('25 simultaneous dirty checkpoints spread over frames; repeated polls cannot bypass the budget',async()=>{
 const s=fixture();s.time(1499);s.cp.poll();await settle();assert.equal(s.sent.length,0);
 for(let i=0;i<5;i++){s.time(1500+i*50);s.cp.poll();s.cp.poll();await settle();assert.equal(s.sent.length,paced?(i+1)*5:25);}
 assert.equal(new Set(s.sent.map(e=>e.actor)).size,25);s.time(2000);assert(s.cp.overdueR53('p24'),'2s stale-memory input fence remains active until actual ACK');s.release();await settle();assert(!s.cp.changed('p24'));
});
test('explicit drain bypasses a full periodic budget and retains actual ACK waiting',async()=>{
 const s=fixture();s.time(1500);s.cp.poll();await settle();let done=false;const drain=s.cp.drain('p24').then(()=>done=true);await settle();assert(s.sent.some(e=>e.actor==='p24'));assert.equal(done,false);s.release();await drain;assert.equal(done,true);await settle();
});
