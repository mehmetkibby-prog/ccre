import test from 'node:test';import assert from 'node:assert/strict';
import {setup,extraPlayer} from '../working/core511-source/scripts/core511/tests/process-fixture.mjs';
import {put} from '../working/core511-source/scripts/core511/tests/pvp-fixture.mjs';
import {ChannelProcessSupervisor} from '../working/core511-source/scripts/core511/process-supervisor.mjs';
import {until} from '../working/core511-source/scripts/core511/tests/helpers.mjs';
for(const mode of ['area','single','promoted'])for(const phase of ['normal','before_commit','after_commit'])test('accepted '+mode+' death batch across real channel/worker: '+phase,{timeout:45000},async t=>{
 const single=mode!=='area',promoted=mode==='promoted';
 if(single){const start=ChannelProcessSupervisor.prototype.start;ChannelProcessSupervisor.prototype.start=function(...args){ChannelProcessSupervisor.prototype.start=start;const sql=this.core.database.sqlite,row=sql.prepare("SELECT * FROM monsters WHERE id='golge-local-terminal511'").get();put(sql,'monsters',{...row,id:'golge-batch-process-second',x:2701});return start.apply(this,args);};t.after(()=>{ChannelProcessSupervisor.prototype.start=start;});}
 const s=await setup(t,{shared:true,localCombat:{hp:1}});await s.world.stopJobs();assert.equal((await s.http('ticket')).status,200);const first=await s.connect(await s.http('transfer',{channel:4}));
 const peers=[];for(let i=0;i<2;i++){const p=extraPlayer(s,280+i,'batch-process-'+i);assert.equal((await p.http()).status,200);peers.push({...p,live:await s.connect(await p.http('transfer',{channel:4}))});}
 const [other,gateActor]=peers,ids=[s.f.id,other.id,gateActor.id];
 await s.core.permanentPlayers(ids,()=>{for(const id of ids)s.f.sql.prepare("UPDATE players SET area='forest',role='arkanist',x=2700,y=2025,hp=400,max_hp=1000,potions=3,level=40,xp=0,arena_match_id='',combat_lock_until_ms=0,attack_one_at=0,attack_two_at=0,attack_three_at=0,attack_four_at=0,stun_until_ms=0,root_until_ms=0,last_seen=? WHERE id=?").run(Math.floor(s.f.clock()/1000),id);put(s.f.sql,'parties',{id:'batch-process-party',leader_id:s.f.id,created_at:1});for(const id of ids)put(s.f.sql,'party_members',{party_id:'batch-process-party',player_id:id,joined_at:1});});
 let releaseGate,gateEntered=false,request,peer,ack,reached=false;const gate=new Promise(r=>releaseGate=r),command=s.writer.command.bind(s.writer),worker=s.writer.rewardWorkerR533;
 t.after(releaseGate);
 s.writer.command=async(p,r)=>{if(r.operation==='native_action'&&r.playerId===gateActor.id&&r.payload.input.action==='use_potion'){gateEntered=true;await gate;}if(r.operation==='attack'){request=r;peer=p;}const value=await command(p,r);if(r.operation==='attack')ack=value;return value;};
 if(phase!=='normal'){
  if(worker.slot){await worker.slot.worker.terminate();await worker.slot.exit;}
  worker.entry=new URL('../tests/reward-worker-fault-entry-r533.mjs',import.meta.url);worker.workerOptions={workerData:{stopAt:phase,gate:new SharedArrayBuffer(4)}};worker.onTestHook=()=>{reached=true;};
 }
 const send=(live,payload)=>live.ws.send(JSON.stringify({type:'input',sequence:1,payload})),reply=live=>live.packets.flatMap(p=>p.results??[]).find(r=>r.sequence===1);
 send(gateActor.live,{action:'use_potion'});await until(()=>gateEntered,3000);
 const attack=(intent,secondary=false)=>({action:'attack',targetId:single&&secondary?'golge-batch-process-second':'golge-local-terminal511',spawnRound:17,ability:promoted?(secondary?2:0):single?0:secondary&&phase==='normal'?1:2,intentId:intent});
 send(first,attack('batch-process-first'));send(other.live,attack('batch-process-next',true));
 // The writer gate is still held; allow both accepted heads to arrive, while
 // neither attack can acquire its whole party. This is test coordination only.
 await new Promise(r=>setTimeout(r,120));assert.equal(reply(first),undefined);assert.equal(reply(other.live),undefined);releaseGate();
 if(phase!=='normal'){
  await until(()=>reached,12000);assert.equal(request.payload.batchAttacksR57.length,1);assert.equal(reply(other.live),undefined,'secondary actor must not receive an early success');
  await worker.slot.worker.terminate();
 }
 await until(()=>reply(other.live)||s.faults.some(f=>f.globalRecovery),12000);assert.equal(request.payload.batchAttacksR57.length,1);assert.equal(request.payload.batchAttacksR57[0].actor,other.id);
 const read=()=>({hp:s.f.sql.prepare("SELECT hp FROM monsters WHERE id='golge-local-terminal511'").get().hp,defeats:s.f.sql.prepare("SELECT count(*) n FROM normal_defeats WHERE monster_id IN ('golge-local-terminal511','golge-batch-process-second') AND spawn_round=17").get().n,unfinished:s.f.sql.prepare('SELECT count(*) n FROM normal_defeats WHERE rewards_completed_at=0').get().n,xp:ids.map(id=>s.f.sql.prepare('SELECT xp FROM players WHERE id=?').get(id).xp)});
 const value=read();assert.equal(value.unfinished,0);
 if(phase==='before_commit'){assert.equal(reply(other.live).status,409);assert.equal(reply(other.live).body.not_executed,true);assert.equal(value.hp,1);assert.equal(value.defeats,0);assert.deepEqual(value.xp,[0,0,0]);}
 else{assert(ack);assert.equal(value.hp,0);assert.equal(value.defeats,single?2:1);assert(value.xp.some(n=>n>0));assert.deepEqual(reply(other.live),JSON.parse(JSON.stringify({type:'action',...ack.result.batchResultsR57[0].result,sequence:1})));await command(peer,request);assert.deepEqual(read(),value);}
 if(phase==='normal'){other.live.ws.send(JSON.stringify({type:'input',sequence:2,payload:{action:'use_potion'}}));await until(()=>other.live.packets.some(p=>p.results?.some(r=>r.sequence===2)),5000);assert.equal(other.live.packets.flatMap(p=>p.results??[]).find(r=>r.sequence===2).status,200);}
 assert(s.faults.every(f=>f.error?.code==='reward_worker_rolled_back'),JSON.stringify(s.faults.map(f=>f.error?.stack)));for(const live of [first,other.live,gateActor.live])assert.equal(live.ws.readyState,1);await worker.close();
});
