import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import {spawn} from 'node:child_process';import {once} from 'node:events';
async function replay(t,{baseline=false,weapons=false,portals=false,bad=false,single=false,mixedInputs=false,promoted=false}={}){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'r57-batch-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));const out=path.join(dir,'result.json');
 const child=spawn(process.execPath,['tests-r57/death-batch-replay.mjs'],{cwd:new URL('..',import.meta.url),env:{...process.env,CORE511_R57_DEATH_BATCH:'1',R57_BATCH_PROMOTED:promoted?'1':'0',R57_BATCH_MIXED_INPUTS:mixedInputs?'1':'0',R57_BATCH_SINGLE:single?'1':'0',R57_BATCH_BASELINE:baseline?'1':'0',R57_BATCH_WEAPONS:weapons?'1':'0',R57_BATCH_PORTALS:portals?'1':'0',R57_BATCH_BAD_EPOCH:bad?'1':'0',R57_BATCH_OUT:out},stdio:['ignore','pipe','pipe']});let log='';for(const stream of [child.stdout,child.stderr])stream.on('data',b=>log=(log+b).slice(-6000));t.after(()=>{if(child.exitCode===null&&child.signalCode===null)child.kill('SIGKILL');});
 const [code,signal]=await once(child,'exit');assert.equal(signal,null,log);assert.equal(code,0,log);return JSON.parse(fs.readFileSync(out));
}
for(const extras of [{},{weapons:true},{weapons:true,portals:true},{single:true,weapons:true,portals:true},{mixedInputs:true,weapons:true,portals:true},{promoted:true,weapons:true,portals:true}])test('one native death batch equals three immutable R56 attacks: '+JSON.stringify(extras),{timeout:60000},async t=>{
 const before=await replay(t,{baseline:true,...extras}),after=await replay(t,extras);assert.equal(after.answers.length,3);assert(after.kills[0]>0);assert.deepEqual(after.answers,before.answers);assert.deepEqual(after.events,before.events);assert.deepEqual(after.delta,before.delta);assert(after.replayed);
});
test('a wrong epoch on the last batched actor cannot save the first death or consume its receipt',async t=>{assert.deepEqual(await replay(t,{bad:true}),{rolledBack:true});});
