"""R57 maintenance installer over byte-exact R56, retaining current DB on rollback."""
from pathlib import Path
import argparse,hashlib,json,re,zipfile
R=Path(__file__).resolve().parents[1];B=R.parent/'r56_performance_work';P=R/'package-r57';E=R/'evidence-r57';CORE='core511-source/scripts/core511/'
sha=lambda b:hashlib.sha256(b).hexdigest()
enc=lambda v:(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
parser=argparse.ArgumentParser();parser.add_argument('--test',action='store_true');args=parser.parse_args()
baseline=B/'candidate/CORE511_R56_PERFORMANCE.zip'
assert sha(baseline.read_bytes())=='f8f93aa99cb77d047c7d483d9d2cb3ba0a22e898f7e97536e1fa53f1c2f7036f'
with zipfile.ZipFile(baseline) as z:
 original=z.read('__main__.py').decode();prior=json.loads(z.read('patch.json'));http=z.read('runtime/r55-readonly-proof.zip')
scope={'__name__':'r57_builder_reference','__file__':str(B/'package-r56/__main__.py')};exec(compile(original,scope['__file__'],'exec'),scope)
before=scope['core_identity'](B/'working'/CORE);after=scope['core_identity'](R/'working'/CORE)
acceptance=json.loads((E/'acceptance.json').read_bytes())
assert acceptance['sourceCore']==after and acceptance['goalThresholdMs']==400 and acceptance['goalMetLocally'] is True,'User gate: 100-player 400ms target must pass before creating any update ZIP'
for key in ('regression','r57'):
 assert acceptance['checks'].get(key,{}).get('currentSource') is True,'Current-source validation required before packaging: '+key
assert before==prior['afterCore']=='7cfdab81bc01db8e4f2c2b7ad89df5064da06965454df7d532b64f1e707f959b'
expected=dict(prior['bases'][0]['baseFiles']);expected.update({r['path']:{'bytes':r['bytes'],'sha256':r['after']} for r in prior['changes']})
ops=scope['OPS']
def normalized(data):
 data,n=re.subn(rb"export const CANDIDATE='[0-9a-f]{64}';",("export const CANDIDATE='"+before+"';").encode(),data);assert n==1;return data
expected[ops]={'bytes':len(normalized((B/'working'/ops).read_bytes())),'sha256':sha(normalized((B/'working'/ops).read_bytes()))}
for name,row in expected.items():
 data=(B/'working'/name).read_bytes();data=normalized(data) if name==ops else data
 assert {'bytes':len(data),'sha256':sha(data)}==row,name
old={n[len(CORE):]:B/'working'/n for n in expected if n.startswith(CORE)}
new={p.relative_to(R/'working'/CORE).as_posix():p for p in (R/'working'/CORE).rglob('*') if p.is_file() and not p.is_symlink() and not {'node_modules','__pycache__','.git'}.intersection(p.parts)}
assert old.keys()<=new.keys()
delta=sorted(n for n in new if n not in old or new[n].read_bytes()!=old[n].read_bytes());assert not any(n.startswith('generated/') for n in delta)
flags=dict(line.split('=',1) for line in (R/'r57-candidate.env').read_text().splitlines() if line and not line.startswith('#'))
assert all(k.startswith(('CORE511_R56_','CORE511_R57_')) and v in ('0','1') for k,v in flags.items())
allflags={**prior['flags'],**flags};newflags=[k for k in flags if k.startswith('CORE511_R57_')]
s=original.replace('R56_PERFORMANCE','R57_PERFORMANCE').replace('r56-performance-backups','r57-performance-backups').replace("'r56-performance'","'r57-performance'")
s=s.replace('checkpoint isolation and bounded combat work over exact delivered R50, R51, R52 or R53.','commit snapshots, equipment/portal refresh and fair scheduling over exact delivered R56.')
s=s.replace("'R55'","'R56'").replace('kod_dogrulanmis_R55','kod_dogrulanmis_R56').replace('doğrulanmış R55','doğrulanmış R56').replace('R56_INSTALL_FLAGS','R57_INSTALL_FLAGS')
anchor="prior_spec['afterCore']==spec['bases'][0]['beforeCore']"
assert s.count(anchor)==1;s=s.replace(anchor,"prior_spec['afterCore']=='0c69884e73b36b3c8137209fe1e4a680579b891b6054a86444c09e5a5db82127'")
start=s.index('def payload_allowed(name):');end=s.index('def verify_restored(',start)
s=s[:start]+'def payload_allowed(name):\n    return name in '+repr(tuple(CORE+n for n in delta))+'\n\n'+s[end:]
s,n=re.subn(r'BOOL_FLAGS = [^\n]+\nINSTALL_FLAGS = [^\n]+\nR57_INSTALL_FLAGS = [^\n]+','BOOL_FLAGS = '+repr(tuple(allflags))+'\nINSTALL_FLAGS = '+repr(allflags)+'\nR57_INSTALL_FLAGS = '+repr(flags),s);assert n==1
compile(s,'R57/__main__.py','exec')
changes=[{'path':CORE+n,'beforeByBase':{'R56':sha(old[n].read_bytes()) if n in old else None},'after':sha(new[n].read_bytes()),'bytes':new[n].stat().st_size} for n in delta]
spec={'version':'R57_PERFORMANCE','installerRevision':'r57-r56-exact-1',**{k:prior[k] for k in ('sourceZip','r34PatchSha256','nativeBaseline','identityManifestFiles','baseProofArchive')},'bases':[{'name':'R56','beforeCore':before,'archiveSha256':sha(baseline.read_bytes()),'baseFiles':expected}], 'afterCore':after,'changes':changes,'flags':allflags,'newFlags':newflags,'goalThresholdMs':400,'goalMetLocally':True,'performanceApproved':False,'liveDeployment':False,'databasePolicy':'No persistent schema migration. Current DB retained on rollback. Native claims unchanged.'}
P.mkdir(exist_ok=True);(P/'__main__.py').write_text(s);(P/'patch.json').write_bytes(enc(spec))
if not args.test:
 assert json.loads((E/'regression/validated-source.json').read_text())['sourceCore']==after,'Validate current source first'
 proof=json.loads((E/'installer-r57.json').read_text());assert proof['status']=='PASS' and proof['afterCore']==after and proof['installerSha256']==sha(s.encode())
entries={'__main__.py':s.encode(),'patch.json':enc(spec),'runtime/r55-readonly-proof.zip':http}
entries.update({'payload/'+CORE+n:new[n].read_bytes() for n in delta})
for n in ('KURULUM.md','R57_SONUC.md','R57_TASARIM.md','r57-candidate.env'):
 if (R/n).exists():entries[n]=(R/n).read_bytes()
for n in ('installer-r57.json','acceptance.json','current-source-proof.json','r57-focused-seal.json','regression/validated-source.json'):
 if (E/n).exists():entries['evidence/'+n]=(E/n).read_bytes()
if not args.test:
 with zipfile.ZipFile(R/'candidate/CORE511_R57_PERFORMANCE_TEST.zip') as tested:
  executable=lambda n:n in ('__main__.py','patch.json') or n.startswith(('payload/','runtime/'))
  assert {n:sha(b) for n,b in entries.items() if executable(n)}=={n:sha(tested.read(n)) for n in tested.namelist() if executable(n)},'Final executable bytes must match roundtrip-tested ZIP'
out=R/'candidate'/('CORE511_R57_PERFORMANCE_TEST.zip' if args.test else 'CORE511_R57_PERFORMANCE.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in sorted(entries.items()):z.writestr(n,b)
out.with_suffix('.zip.sha256').write_text(sha(out.read_bytes())+'  '+out.name+'\n')
print(json.dumps({'archive':str(out),'sourceCore':after,'installerSha256':sha(s.encode()),'sha256':sha(out.read_bytes()),'changes':len(changes),'liveDeployment':False}))
