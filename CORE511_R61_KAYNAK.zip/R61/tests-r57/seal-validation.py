"""Bind passing logs to the source; begin/finish also detect mid-run edits."""
from pathlib import Path
import argparse, hashlib, importlib.util, json
R=Path(__file__).resolve().parents[1];E=R/'evidence-r57/regression'
sp=importlib.util.spec_from_file_location('r55_identity',R.parent/'r55_gameplay_work/package/__main__.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
p=argparse.ArgumentParser();p.add_argument('phase',choices=['begin','finish','seal-completed']);a=p.parse_args()
source=m.core_identity(R/'working/core511-source/scripts/core511')
start=E/'validation-start-source.json'
if a.phase=='begin':start.write_bytes(m.encoded({'sourceCore':source}));raise SystemExit(0)
if a.phase=='finish':assert json.loads(start.read_text())['sourceCore']==source,'Source changed during validation'
logs={'final-native-54.log':54,'final-async-45.log':45,'causal-party-candidate.log':1,'final-read-cache-3.log':3,'mist-config-cache-3.log':3,'causal-party-baseline-fixed.log':1,'potion-join-12.log':12,'potion-legacy-7.log':7,'mist-existing-integration.log':9,'potion-gate-off-control.log':1,'section-group-4.log':4,'writer-window-15.log':15,'actor-section-52.log':52,'section-group-off-3.log':3,'short-window-off-1.log':1,'small-complete-2.log':2}
proof={}
for name,count in logs.items():
 b=(E/name).read_bytes();s=b.decode();assert f'# pass {count}\n' in s and '# fail 0\n' in s,name
 proof[name]={'passed':count,'sha256':hashlib.sha256(b).hexdigest()}
if a.phase=='seal-completed':
 # One-time sealing of an already completed run, before begin/finish was added.
 # Every source module must predate even the first completed group log.
 cutoff=min((E/n).stat().st_mtime_ns for n in logs)
 assert all(p.stat().st_mtime_ns<cutoff for p in (R/'working/core511-source/scripts/core511').rglob('*') if p.is_file() and not p.is_symlink()),'Source newer than completed validation'
seal={'sourceCore':source,'distinctChecksPassed':207,'negativeCausalControlPassed':6,'logs':proof,'liveDeployment':False,'performanceApproved':False}
(E/'validated-source.json').write_bytes(m.encoded(seal));print(json.dumps({'sourceCore':source,'checks':207,'negativeControl':6}))
