import {register} from 'node:module';
register(new URL('./worker-profile-loader.mjs',import.meta.url));
