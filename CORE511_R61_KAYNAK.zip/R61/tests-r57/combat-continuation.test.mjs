import test from 'node:test';import assert from 'node:assert/strict';
import {FixedLoop} from '../working/core511-source/scripts/core511/fixed-loop.mjs';
import {continueCombatR57} from '../working/core511-source/scripts/core511/combat-continuation-r57.mjs';
import {ResidentState} from '../working/core511-source/scripts/core511/resident-state.mjs';
const enabled=process.env.CORE511_R57_COMBAT_CONTINUATION==='1',turn=()=>new Promise(r=>setImmediate(r));
function fixture(combat,count=2){
 const state=new ResidentState(1),phases=[],calls=[];let time=1000;
 const rules={combat:ctx=>{calls.push(ctx);return combat?.(ctx)??{type:'action',status:200,body:{ok:true}};},movement:()=>phases.push('movement'),ai:()=>phases.push('ai'),respawn:()=>phases.push('respawn'),project:()=>phases.push('project')};
 const kernel=new FixedLoop({state,rules,send:()=>assert.fail('continuation cannot bypass ordered frame output'),clock:()=>time,wall:()=>time});kernel.stopped=false;
 for(let i=0;i<count;i++){const id='p'+i;state.put('players',{id,area:'forest',arena_match_id:'',channel:1,hp:100,x:0,y:0});state.claim(id,1);kernel.admit(id,1);}
 const enqueue=(id,action='attack',kind='combat')=>kernel.enqueue(id,{sequence:kernel.players.get(id).lastAccepted+1,epoch:1,kind,payload:{action}});
 return {kernel,phases,calls,enqueue,time:value=>time=value};
}
test('actual durable ACK starts the queued death before the next tick; second reward still waits for its own ACK',async()=>{
 let releaseOld,releaseNew;const old=new Promise(r=>releaseOld=r),next=new Promise(r=>releaseNew=r);
 const s=fixture(ctx=>{ctx.kernel.durableGroup([ctx.id],()=>next,{replyTo:ctx.id,emitReceipt:false,ackResult:()=>({type:'action',status:200})});return {type:'action'};});
 const pending=s.kernel.durableGroup(['p0'],()=>old,{emitReceipt:false});s.enqueue('p0');await turn();assert.equal(s.calls.length,0);releaseOld();await pending;await turn();
 assert.equal(s.calls.length,enabled?1:0);assert.equal(s.kernel.metrics.ticks,0);assert.deepEqual(s.phases,[]);
 const p=s.kernel.players.get('p0');if(enabled){assert(p.barrier);assert.equal(p.lastApplied,0);assert.equal(p.results.length,0);assert.equal(s.kernel.state.owners.get('p0').pending,1);}
 releaseNew();await turn();if(enabled){assert.equal(p.lastApplied,1);assert.equal(p.results[0].status,200);assert.equal(p.barrier,null);assert.equal(s.kernel.state.owners.get('p0').pending,0);}s.kernel.stop();
});
test('tick slices, outbound flush, suspension and stopped kernels cannot be reentered',()=>{
 for(const state of ['running','flushing','stopped']){const s=fixture();s.enqueue('p0');s.kernel[state]=true;continueCombatR57(s.kernel);assert.equal(s.calls.length,0);assert.equal(s.kernel.players.get('p0').queue.length,1);}
 const s=fixture();s.enqueue('p0');s.kernel.players.get('p0').suspended=true;continueCombatR57(s.kernel);assert.equal(s.calls.length,0);
});
test('older potion and each actor sequence retain their order',()=>{
 const s=fixture();s.enqueue('p0','use_potion');s.enqueue('p1');continueCombatR57(s.kernel);assert.equal(s.calls.length,0);
 const t=fixture();t.enqueue('p0','move','movement');t.enqueue('p0');continueCombatR57(t.kernel);assert.equal(t.calls.length,0);assert.equal(t.kernel.players.get('p0').lastApplied,0);
});
test('continuations have a shared four-input/50ms bound and never advance movement or AI',()=>{
 const s=fixture(null,6);for(let i=0;i<6;i++)s.enqueue('p'+i);continueCombatR57(s.kernel);continueCombatR57(s.kernel);assert.equal(s.calls.length,enabled?4:0);
 s.time(1050);continueCombatR57(s.kernel);assert.equal(s.calls.length,enabled?6:0);assert.deepEqual(s.phases,[]);assert.equal(s.kernel.metrics.ticks,0);
 if(enabled)for(const p of s.kernel.players.values()){assert.equal(p.lastApplied,1);assert.equal(p.results.length,1);assert.equal(p.queue.length,0);}
});
