// Isolated native SQL replay; no sockets or capacity claims.
import fs from 'node:fs';import assert from 'node:assert/strict';
import {setup} from '../tests/native-attack-fixture-r53-1.mjs';
import {readAttackFrame} from '../working/core511-source/scripts/core511/attack-writer.mjs';
const {GameWriter}=await import(process.env.R57_BATCH_BASELINE==='1'?'../../r56_performance_work/working/core511-source/scripts/core511/writer-runtime.mjs':'../working/core511-source/scripts/core511/writer-runtime.mjs');
const cleanup=[],s=await setup({after:f=>cleanup.push(f)}),sql=s.sql,batch=process.env.R57_BATCH_BASELINE!=='1',single=process.env.R57_BATCH_SINGLE==='1',mixedInputs=process.env.R57_BATCH_MIXED_INPUTS==='1',promoted=process.env.R57_BATCH_PROMOTED==='1';
const put=(table,row)=>sql.prepare('INSERT INTO '+table+'('+Object.keys(row).join(',')+') VALUES('+Object.keys(row).map(()=>'?').join(',')+')').run(...Object.values(row));
try{
 s.reset({role:'arkanist',ability:2,hp:1,patch:{x:2700,y:2025}});sql.exec('DELETE FROM party_members;DELETE FROM parties;DELETE FROM monster_participants;UPDATE monsters SET hp=0;UPDATE players SET created_at=1');
 const actor=sql.prepare('SELECT * FROM players WHERE id=?').get(s.id),monster=sql.prepare('SELECT * FROM monsters WHERE id=?').get(s.mid),ids=[s.id],mids=[s.mid];
 for(let i=1;i<5;i++){const id='batch-player-'+i;put('players',{...actor,id,name:id,account_id:null,x:2700+i,y:2025});ids.push(id);}
 put('parties',{id:'batch-party',leader_id:s.id,created_at:1});for(const id of ids)put('party_members',{party_id:'batch-party',player_id:id,joined_at:1});
 for(let i=1;i<60;i++){const id='golge-batch-'+i;put('monsters',{...monster,id,x:2750+i%10,y:2025+Math.floor(i/10),hp:200,max_hp:200});mids.push(id);}
 sql.prepare('UPDATE players SET last_seen=110,level=40,xp=0,attack_one_at=0,attack_two_at=0,attack_three_at=0,attack_four_at=0,combat_lock_until_ms=0,stun_until_ms=0,root_until_ms=0').run();
 for(const [i,id]of mids.entries()){sql.prepare('UPDATE monsters SET hp=?,max_hp=200,x=?,y=? WHERE id=?').run(i<10?1:i<20?30:i<30?55:200,2750+i%10,2025+Math.floor(i/10),id);for(const p of ids)put('monster_participants',{monster_id:id,spawn_round:1,player_id:p,created_at:100});}
 if(process.env.R57_BATCH_WEAPONS==='1')for(const id of ids)put('player_items',{id:'weapon-'+id,player_id:id,kind:'weapon',item_name:'+5 Fixture',rarity:'white',power:0,role:'arkanist',enchantments:'[{"kind":"evolution_kills","value":99}]',equipped:1,created_at:1});
 sql.function('unixepoch',()=>1792800000);
 const writer=new GameWriter(s.f.database,{realmId:'batch-replay',ports:{guard:()=>true},clock:()=>110000});await writer.initialize();
 if(process.env.R57_BATCH_PORTALS==='1'){const config=JSON.parse(sql.prepare('SELECT value FROM adventure_settings WHERE id=1').get().value);sql.prepare('UPDATE adventure_settings SET value=? WHERE id=1').run(JSON.stringify({...config,enabled:true,chancePercent:100,minLevel:1,killCooldownSeconds:120}));}
 const peer={channel:1,incarnation:'batch-owner'},owners=new Map();await writer.register(peer);for(const id of ids)owners.set(id,await writer.admit(id,peer,{sessionId:'session-'+id,guard:()=>true}));
 const settings={...sql.prepare('SELECT * FROM game_settings WHERE id=1').get(),...sql.prepare('SELECT * FROM combat_settings WHERE id=1').get()};
 const entries=ids.slice(0,3).map((actor,i)=>({actor,epoch:owners.get(actor).epoch,sequence:1,receivedAtMs:110000,seed:String(i+1).repeat(64),input:{action:'attack',ability:single?0:promoted?[0,2,1][i]:mixedInputs?[2,0,1][i]:2,targetId:mids[single?i:[0,35,45][i]],spawnRound:1,intentId:'batch-intent-'+i}}));
 const tables=sql.prepare("SELECT name FROM main.sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE 'kernel511_%' ORDER BY name").all().map(r=>r.name);
 const snapshot=()=>Object.fromEntries(tables.map(t=>{const keys=sql.prepare('PRAGMA table_info("'+t+'")').all().filter(c=>c.pk).sort((a,b)=>a.pk-b.pk).map(c=>c.name);return [t,new Map(sql.prepare('SELECT '+(keys.length?'':'rowid __key,')+'* FROM "'+t+'"').all().map(r=>[JSON.stringify(keys.length?keys.map(k=>r[k]):r.__key),r]))];}));
 const delta=(a,b)=>Object.fromEntries(tables.map(t=>[t,[...new Set([...a[t].keys(),...b[t].keys()])].sort().flatMap(key=>{const old=a[t].get(key),now=b[t].get(key);if(JSON.stringify(old)===JSON.stringify(now))return [];if(!old||!now)return [{key,before:old??null,after:now??null}];return [{key,fields:Object.fromEntries(Object.keys(now).filter(k=>!Object.is(old[k],now[k])).map(k=>[k,[old[k],now[k]]]))}];})]).filter(([,v])=>v.length));
 const before=snapshot(),answers=[],events=[];let firstRequest;
 for(const [i,e]of entries.entries()){
  if(batch&&i>0)break;
  const frame=readAttackFrame(sql,e.actor,e.input.targetId,writer.services.globals),payload={nowMs:110000,receivedAtMs:e.receivedAtMs,seed:e.seed,input:e.input,expected:{...frame,settings},resources:[...ids.map(id=>'player:'+id),...mids.map(id=>'monster:'+id)],localScope:single?{kind:'kill',targets:mids.slice(0,3).map(id=>({id,spawnRound:1}))}:{kind:'mixed',area:'forest',targets:mids.map(id=>({id,spawnRound:1})),narrow:true},...(batch?{batchAttacksR57:entries.slice(1)}:{})};
  if(!batch&&(mixedInputs&&i>0||promoted&&i!==1))payload.localScope={kind:'kill',targets:[{id:e.input.targetId,spawnRound:1}]};
  if(process.env.R57_BATCH_BAD_EPOCH==='1')payload.batchAttacksR57[1].epoch++;
  const request={playerId:e.actor,epoch:e.epoch,sequence:1,operationId:'batch-replay-'+i,operation:'attack',payload};firstRequest??=request;
  if(process.env.R57_BATCH_BAD_EPOCH==='1'){await assert.rejects(writer.command(peer,request));assert.deepEqual(delta(before,snapshot()),{});assert.equal(writer.authority.owner(e.actor).sequence,0);fs.writeFileSync(process.env.R57_BATCH_OUT,JSON.stringify({rolledBack:true}));writer.maintenance.close();process.exitCode=0;break;}
  const ack=await writer.command(peer,request);assert.equal(ack.result.result.status,200,JSON.stringify(ack.result.result));answers.push(ack.result.result,...(ack.result.batchResultsR57??[]).map(r=>r.result));events.push(...ack.result.events);
 }
 if(process.env.R57_BATCH_BAD_EPOCH!=='1'){
  const change=delta(before,snapshot());await writer.command(peer,firstRequest);assert.deepEqual(delta(before,snapshot()),change,'receipt replay cannot repeat any native effect');
  fs.writeFileSync(process.env.R57_BATCH_OUT,JSON.stringify({answers,events,delta:change,kills:answers.map(r=>r.body.hits?.filter(h=>h.killed).length??0),replayed:true}));writer.maintenance.close();
 }
}finally{for(const fn of cleanup.reverse())await fn();}
