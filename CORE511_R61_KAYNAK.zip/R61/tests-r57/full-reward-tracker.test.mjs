import test from 'node:test';import assert from 'node:assert/strict';import {FullRewardTrackerR57} from './full-reward-tracker.mjs';
const turn=()=>new Promise(r=>setImmediate(r));
test('a client death and partial awards cannot complete the latency sample; final fsync must also finish',async()=>{
 let now=10,release;const t=new FullRewardTrackerR57(()=>now),disk=new Promise(r=>release=r);
 t.sent('p',{action:'attack',intentId:'a'},10,true);t.provisional('a');t.kills('p','a',[{id:'m1',spawnRound:1,killed:true},{id:'m2',spawnRound:1,killed:true}]);t.death('a',100);
 t.inspect(()=>[{id:'m1',spawnRound:1,completed:1},{id:'m2',spawnRound:1,completed:0}],()=>assert.fail('partial award must not be certified'));await turn();assert.equal(t.report().deathAndAllRewardsMs.n,0);assert.equal(t.report().pending.length,1);
 now=200;t.inspect(()=>[{id:'m1',spawnRound:1,completed:1},{id:'m2',spawnRound:1,completed:1}],()=>disk);await turn();assert.equal(t.report().deathAndAllRewardsMs.n,0);now=350;release();await turn();
 assert.equal(t.report().deathAndAllRewardsMs.p95,340);assert.equal(t.report().rewardTailAfterClientDeathMs.p95,250);assert.equal(t.report().killsCovered,2);assert.deepEqual(t.report().pending,[]);
});
test('post-fsync server completion still waits for the client death and duplicate replies do not create samples',async()=>{
 let now=90;const t=new FullRewardTrackerR57(()=>now);t.sent('p',{action:'attack',intentId:'a'},10,true);const hits=[{id:'m',spawnRound:1,killed:true}];t.kills('p','a',hits);t.kills('p','a',hits);t.inspect(()=>[{id:'m',spawnRound:1,completed:1}],()=>undefined);await turn();assert.equal(t.report().deathAndAllRewardsMs.n,0);t.death('a',120);t.death('a',130);assert.equal(t.report().deathAndAllRewardsMs.n,1);assert.equal(t.report().deathAndAllRewardsMs.p95,110);assert.equal(t.report().serverAllRewardsMs.p95,80);
});
test('a provisional lethal prediction superseded by a final no-kill reply is accounted separately',()=>{
 const t=new FullRewardTrackerR57();t.sent('p',{action:'attack',intentId:'lost-race'},10,true);t.provisional('lost-race');t.noKillFinal('lost-race');t.death('lost-race',100);t.noKillFinal('lost-race');assert.equal(t.report().finalWithoutKill,1);assert.equal(t.report().deathAndAllRewardsMs.n,0);assert.deepEqual(t.report().pending,[]);
 t.sent('p',{action:'attack',intentId:'real-death'},10,true);t.kills('p','real-death',[{id:'m',spawnRound:1,killed:true}]);t.noKillFinal('real-death');assert.equal(t.report().finalWithoutKill,1);assert.equal(t.report().pending.length,1,'actual kills cannot be dropped');
});
