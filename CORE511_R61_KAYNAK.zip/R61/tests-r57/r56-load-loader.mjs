// Use the corrected R57 equipped-player driver with byte-immutable R56 gameplay.
// This changes module locations only; it does not rewrite baseline source.
const current=new URL('../working/core511-source/scripts/core511/',import.meta.url).href;
const baseline=new URL('../../r56_performance_work/working/core511-source/scripts/core511/',import.meta.url).href;
export async function resolve(specifier,context,next){
 const result=await next(specifier,context);
 if(result.url.startsWith(current)&&!result.url.slice(current.length).startsWith('benchmark/'))return {...result,url:baseline+result.url.slice(current.length)};
 return result;
}
