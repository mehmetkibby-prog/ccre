"""Real ZIP/Node/SQLite/filesystem roundtrip; only root and services simulated.

Run under the pinned setup fakeroot. No /opt,/var/lib or real service is used.
The starting HTTP fixture was reconstructed with the original SHA-pinned
verifiers; its omitted native media limits this test, as in the R55 evidence.
"""
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
import contextlib,hashlib,importlib.util,io,json,os,re,shutil,sqlite3,stat,sys,tempfile,unittest,zipfile
R=Path(__file__).resolve().parents[1];B=R.parent/'r55_gameplay_work';E=R/'evidence-r57'
def module(name,path):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
m=module('r57_installer_test',R/'package-r57/__main__.py');old=module('r55_installer_fixture',B/'package/__main__.py')
sha=lambda b:hashlib.sha256(b).hexdigest()
def copy_links(a,b):
 seen={}
 def copy(source,dest):
  s=os.stat(source);k=(s.st_dev,s.st_ino)
  if k in seen:os.link(seen[k],dest)
  else:shutil.copy2(source,dest);seen[k]=dest
  return dest
 shutil.copytree(a,b,copy_function=copy,symlinks=True)
class Installer(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='r57-installer-');self.addCleanup(self.tmp.cleanup);self.dir=Path(self.tmp.name);self.root=self.dir/'release'
  cache=B/'fixture-cache-r54';copy_links(cache/'release',self.root)
  self.state=self.dir/'state.json';self.config_file=self.dir/'config.json';self.db=self.dir/'game.sqlite';self.node=R/'tooling/node-v22.22.0-linux-x64/bin/node'
  for name in ('state.json','config.json','game.sqlite'):shutil.copyfile(cache/name,self.dir/name)
  c=json.loads(self.config_file.read_bytes());c['database']=str(self.db);self.config_file.write_bytes(m.encoded(c))
  shutil.copyfile(B/'input/CORE511_R46.zip',self.dir/'CORE511_R46.zip')
  self.archive=self.dir/'CORE511_R57_PERFORMANCE.zip';shutil.copyfile(R/'candidate/CORE511_R57_PERFORMANCE_TEST.zip',self.archive)
  with zipfile.ZipFile(self.archive) as z:self.spec=json.loads(z.read('patch.json'))
  daily=self.dir/'backups';daily.mkdir(mode=0o700);(daily/'daily.sqlite').write_bytes(b'preserve daily backup')
  self.backups=self.dir/'r57-performance-backups';self.actions=[];self.fail_start=False;self.enabled=True;self.checks={};outer=self
  self.dbbytes=self.db.read_bytes();self.dbst=self.db.stat()
  class Live:
   def __init__(live):
    live.root=outer.root;live.state=json.loads(outer.state.read_bytes());live.config_file=outer.config_file;live.config=json.loads(outer.config_file.read_bytes());live.database=outer.db;live.node=outer.node;live.unit='coreoflife-r1.service';live.accounts_unit='coreoflife-accounts.service'
   def active_binding(live,**kwargs):pass
   def maintenance(live,revision=None):m.require(outer.enabled,'maintenance_required');live.same_database();return 119
   def same_database(live):
    outer.assertEqual(outer.db.read_bytes(),outer.dbbytes);outer.assertEqual(outer.db.stat().st_ino,outer.dbst.st_ino);outer.assertEqual(outer.db.stat().st_mtime_ns,outer.dbst.st_mtime_ns)
   def stop_services(live):outer.actions.append('stop')
   def start_services(live,revision):
    outer.actions.append('start');outer.assertEqual(revision,119);live.same_database()
    if outer.fail_start:outer.fail_start=False;raise m.Refused('injected_health_failure')
   def ready(live,revision):live.same_database()
   def central(live,revision):outer.assertEqual(revision,119)
   def empty(live):pass
  self.Live=Live
  for name,value in [('STATE',self.state),('BACKUPS',self.backups),('Live',Live)]:
   p=patch.object(m,name,value);p.start();self.addCleanup(p.stop)
 def run_main(self,*args):
  out=io.StringIO()
  try:
   with patch.object(sys,'argv',[str(self.archive),*args]),contextlib.redirect_stdout(out),contextlib.redirect_stderr(out):m.main()
  finally:
   with (E/'installer-r57.log').open('a') as f:f.write('\n$ '+' '.join(args)+'\n'+out.getvalue())
  return out.getvalue()
 def snapshot(self):
  result={p.relative_to(self.root).as_posix():sha(p.read_bytes()) for p in self.root.rglob('*') if p.is_file() and not p.is_symlink() and 'node_modules' not in p.parts}
  result['__state']=sha(self.state.read_bytes());result['__config']=sha(self.config_file.read_bytes());return result
 def build_r56_fixture(self):
  with zipfile.ZipFile(B/'candidate/CORE511_R55_GAMEPLAY.zip') as z:
   spec=json.loads(z.read('patch.json'));live=self.Live()
   with patch.object(old,'STATE',self.state),patch.object(old,'LIVE_CONFIG_FILE',self.config_file),patch.object(old,'PATCH_FILES',[r['path'] for r in spec['changes']]),patch.object(old,'BASE_ARCHIVE',str(self.dir/'CORE511_R46.zip')):
    runtime=old.runtime_activation(live,z,spec);selected=old.select_base(live,spec,runtime);updates=old.prepare(live,z,selected)
    default=old.regular(self.root/(old.CORE+'permanent-coordinator.mjs'))
    for file,data in updates.items():
     s=old.regular(file,allow_hardlinks=True) if file.exists() else default
     file.parent.mkdir(parents=True,exist_ok=True)
     old.apply_update(file,data,{'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid})
    old.verify_installed(live,selected)
  ref=module('r56_reference_fixture',R.parent/'r56_performance_work/package-r56/__main__.py')
  with zipfile.ZipFile(R.parent/'r56_performance_work/candidate/CORE511_R56_PERFORMANCE.zip') as z:
   spec=json.loads(z.read('patch.json'));live=self.Live()
   with patch.object(ref,'STATE',self.state),patch.object(ref,'PATCH_FILES',[r['path'] for r in spec['changes']]),patch.object(ref,'BASE_ARCHIVE',str(self.dir/'CORE511_R46.zip')):
    runtime=ref.runtime_activation(live,z,spec);selected=ref.select_base(live,spec,runtime);updates=ref.prepare(live,z,selected)
    default=ref.regular(self.root/(ref.CORE+'permanent-coordinator.mjs'))
    for file,data in updates.items():
     st=ref.regular(file,allow_hardlinks=True) if file.exists() else default
     file.parent.mkdir(parents=True,exist_ok=True);ref.apply_update(file,data,{'mode':stat.S_IMODE(st.st_mode),'uid':st.st_uid,'gid':st.st_gid})
    ref.verify_installed(live,selected)
 def test_roundtrip_failure_recovery_flags_and_current_database(self):
  # R54 is not silently promoted by the embedded read-only R55 verifier.
  with self.assertRaisesRegex(Exception,'once_R55_GAMEPLAY'):self.run_main('--check')
  self.assertEqual(self.actions,[]);self.checks['r54RefusedWithoutWrites']=True
  self.build_r56_fixture();before=self.snapshot();config_before=self.config_file.read_bytes();db_inode=self.db.stat().st_ino
  http={p.relative_to(self.root).as_posix():(sha(p.read_bytes()),p.stat().st_ino) for p in (self.root/'http-runtime').rglob('*') if p.is_file()}
  self.assertIn('"taban": "R56"',self.run_main('--check'));self.assertEqual(self.snapshot(),before);self.assertEqual(self.actions,[]);self.checks['checkReadOnly']=True
  self.enabled=False
  with self.assertRaisesRegex(Exception,'maintenance_required'):self.run_main('--apply')
  self.enabled=True;self.assertEqual(self.actions,[]);self.checks['maintenanceRequired']=True
  drift=self.root/(m.CORE+'channel-runtime.mjs');saved=drift.read_bytes();drift.write_bytes(saved+b'\n// unauthorized\n')
  with self.assertRaisesRegex(Exception,'kod_dogrulanmis_R56'):self.run_main('--apply')
  drift.write_bytes(saved);self.assertEqual(self.actions,[]);self.checks['sourceTamperRefusedBeforeStop']=True
  with zipfile.ZipFile(self.archive) as z:entries={n:z.read(n) for n in z.namelist()}
  changed=next('payload/'+r['path'] for r in self.spec['changes'] if r['beforeByBase']['R56'] is not None)
  with zipfile.ZipFile(self.archive,'w',zipfile.ZIP_DEFLATED) as z:
   for n,b in entries.items():z.writestr(n,b+b'\n// corrupt\n' if n==changed else b)
  with self.assertRaisesRegex(Exception,'paket_dosyasi_bozuk'):self.run_main('--apply')
  shutil.copyfile(R/'candidate/CORE511_R57_PERFORMANCE_TEST.zip',self.archive);self.assertEqual(self.actions,[]);self.checks['payloadTamperRefusedBeforeStop']=True
  self.fail_start=True
  with self.assertRaisesRegex(Exception,'injected_health_failure'):self.run_main('--apply')
  self.assertEqual(self.snapshot(),before);self.actions.clear();self.checks['automaticRollbackOnFailedHealth']=True
  self.run_main('--apply');self.assertEqual(self.actions,['stop','start']);self.actions.clear();self.checks['applyWithRealNodeManifestVerification']=True
  installed=self.snapshot();self.run_main('--check');self.run_main('--apply');self.assertEqual(self.snapshot(),installed);self.assertEqual(self.actions,[]);self.checks['repeatedApplyIdempotent']=True
  for v in ('0','1'):
   self.run_main(*sum((['--set-flag',key+'='+v] for key in self.spec['newFlags']),[]))
  self.checks['allNewFlagsOffAndOn']=True
  # Restore the selected experimental-zero settings before the final --check.
  self.run_main(*sum((['--set-flag',k+'='+v] for k,v in self.spec['flags'].items() if k in self.spec['newFlags']),[]))
  prior_env=json.loads(config_before)['environment'];env=json.loads(self.config_file.read_bytes())['environment'];self.assertTrue(all(env[k]==v for k,v in prior_env.items() if k not in self.spec['newFlags']))
  self.assertEqual({p.relative_to(self.root).as_posix():(sha(p.read_bytes()),p.stat().st_ino) for p in (self.root/'http-runtime').rglob('*') if p.is_file()},http);self.checks['allHttpBytesAndInodesUnchanged']=True
  asset=next(p for p in (self.root/m.HTTP_ASSETS).rglob('*.js'));saved=asset.read_bytes();asset.write_bytes(saved+b'\n// tamper\n')
  with self.assertRaises(Exception):self.run_main('--check')
  asset.write_bytes(saved);self.checks['immutableClientTamperRefused']=True
  with contextlib.closing(sqlite3.connect(self.db)) as db:
   with db:db.execute('INSERT INTO player(id,xp) VALUES(5555,5555)')
  self.dbbytes=self.db.read_bytes();self.dbst=self.db.stat()
  with patch.object(m,'prop',return_value='active'):self.run_main('--rollback-latest','--base-package',str(self.dir/'absent.zip'))
  self.assertEqual(self.snapshot(),before);self.assertEqual(self.db.stat().st_ino,db_inode);self.assertEqual(self.db.read_bytes(),self.dbbytes)
  with contextlib.closing(sqlite3.connect(self.db)) as db:
   self.assertEqual(db.execute('PRAGMA quick_check').fetchone()[0],'ok');self.assertEqual(db.execute('SELECT xp FROM player WHERE id=5555').fetchone()[0],5555)
  self.checks['rollbackRetainsCurrentDbAndNewData']=True;self.checks['rollbackDoesNotNeedProofArchive']=True
  self.assertEqual((self.dir/'backups/daily.sqlite').read_bytes(),b'preserve daily backup');self.checks['dailyBackupPreserved']=True
  self.assertFalse(list(self.backups.glob('*/game.sqlite')));self.checks['ownTemporaryDbBackupCleaned']=True
  (E/'installer-r57.json').write_bytes(m.encoded({'status':'PASS','afterCore':self.spec['afterCore'],'installerSha256':sha((R/'package-r57/__main__.py').read_bytes()),'checks':self.checks,'serviceHealthMocked':True,'rootSimulatedByFakeroot':True,'actualZipNodeSQLiteBackupAndRollback':True,'nativeMediaOmittedFromFixture':True,'liveDeployment':False}))
if __name__=='__main__':unittest.main(verbosity=2)
