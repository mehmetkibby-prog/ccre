"""Source review archive with exact R56 before-images and current-source evidence."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[1];B=R.parent/'r56_performance_work';E=R/'evidence-r57'
sha=lambda b:hashlib.sha256(b).hexdigest()
proof=json.loads((E/'current-source-proof.json').read_bytes());core=proof['sourceCoreAfter']
acceptance=json.loads((E/'acceptance.json').read_bytes());assert acceptance['sourceCore']==core and acceptance['goalThresholdMs']==400 and acceptance['goalMetLocally'] is True,'User performance gate is not met'
for p,k in [(E/'regression/validated-source.json','sourceCore'),(E/'r57-focused-seal.json','sourceCore'),(E/'installer-r57.json','afterCore'),(E/'acceptance.json','sourceCore')]:assert json.loads(p.read_bytes())[k]==core,p
entries={}
def include(path,name=None):
 if path.is_file():entries[name or path.relative_to(R).as_posix()]=path.read_bytes()
for row in proof['changes']:
 p=R/'working'/row['path'];assert sha(p.read_bytes())==row['afterSha256'];include(p,'payload/'+row['path'])
 if row['beforeSha256']:
  p=B/'working'/row['path'];assert sha(p.read_bytes())==row['beforeSha256'];include(p,'before/'+row['path'])
for name in ['R57_TASARIM.md','R57_SONUC.md','KURULUM.md','DEVAM.md','R57_WORK_STATE.json','r57-candidate.env']:include(R/name)
for p in (R/'tests-r57').iterdir():
 if p.is_file() and p.suffix in ('.mjs','.py','.sh'):include(p)
for p in (E/'regression').iterdir():include(p)
for name in ['acceptance.json','current-source-proof.json','R56-R57.diff','r57-focused-seal.json','r57-focused.log','r57-off-control.log','installer-r57.json','installer-r57.log','monster-fairness-before.log','monster-fairness-after.log','item-snapshot-size-before.log','item-snapshot-size-after.log']:include(E/name)
for case in dict.fromkeys(['immutable-r56-weapons-soak-100','resource-authority-soak-100','wide-death-batch-100',*acceptance['finalCases']]):
 for name in ['source.json','result.json','result.acceptance.json','result.drain.json','run.log']:include(E/case/name)
entries['manifest.json']=(json.dumps({'version':'R57_CODE_REVIEW','installable':False,'sourceCore':core,'goalThresholdMs':400,'goalMetLocally':True,'liveDeployment':False,'performanceApproved':False,'files':{n:sha(b) for n,b in entries.items()}},indent=2)+'\n').encode()
entries['README_TR.md']='''# R57 kaynak incelemesi

Bu ZIP kurulum programı değildir. Kaynak değişiklikleri, değişmez R56 before
dosyaları, yerel testler ve ham sonuçlar içerir. Ayrı kurulum paketi
CORE511_R57_PERFORMANCE.zip dosyasıdır. R57_SONUC.md hedefin geçip geçmediğini
açıklar. Gerçek VDS'ye bağlantı veya dağıtım yapılmadı.
'''.encode()
out=R/'candidate/CORE_OF_LIFE_R57_CODE_REVIEW.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,data in sorted(entries.items()):z.writestr(name,data)
out.with_suffix('.zip.sha256').write_text(sha(out.read_bytes())+'  '+out.name+'\n')
print(json.dumps({'archive':str(out),'sourceCore':core,'bytes':out.stat().st_size,'sha256':sha(out.read_bytes())}))
