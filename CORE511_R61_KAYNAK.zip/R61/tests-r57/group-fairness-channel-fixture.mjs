import {runChannelProcess} from '../working/core511-source/scripts/core511/channel-process.mjs';
import {ProcessStream} from '../working/core511-source/scripts/core511/process-stream.mjs';
import {DEFER_INPUT} from '../working/core511-source/scripts/core511/fixed-loop.mjs';
await runChannelProcess({afterCreate(runtime){
 // Deterministic trusted read-footprint conflict, even if periodic AI has
 // already advanced the native retaliation clock before the input arrives.
 const footprint=runtime.channel.actions.footprint;
 runtime.channel.actions.footprint=function(id,input,...args){const f=footprint.call(this,id,input,...args);return input.intentId==='r57-test-resource-wait'?{...f,resources:[...new Set([...f.resources,'monster:golge-local-terminal511'])]}:f;};
 const deferred=new Map(),attack=runtime.channel.attack.attack;
 runtime.channel.attack.attack=function(c){const value=attack.call(this,c);if(value===DEFER_INPUT)deferred.set(c.id,(deferred.get(c.id)??0)+1);return value;};
 process.on('message',m=>{
  if(m?.type==='test-fairness-state'){process.send({type:m.type,request:m.request,deferred:[...deferred]});return;}
  if(m?.type!=='test-browser-connection'||!/^test-browser:[a-f0-9-]{36}$/.test(m.stream))return;
  const socket=new ProcessStream(process,{stream:m.stream,connect:false});Object.defineProperty(socket,'remoteAddress',{value:'127.0.0.'+(runtime.peer.channel+1)});runtime.webSocketEndpoint.server.emit('connection',socket);
 });
}});
