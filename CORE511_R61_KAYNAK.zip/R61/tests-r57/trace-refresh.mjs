// Disposable diagnostic instrumentation, never imported by production.
import '../tests-r56/trace-input-waits.mjs';
import {performance} from 'node:perf_hooks';
import {ResidentChannel} from '../working/core511-source/scripts/core511/resident-channel.mjs';
import {ChannelRuntime} from '../working/core511-source/scripts/core511/channel-runtime.mjs';
import {GameWriter} from '../working/core511-source/scripts/core511/writer-runtime.mjs';
const command=GameWriter.prototype.command;
GameWriter.prototype.command=async function(peer,request){
 const ack=await command.call(this,peer,request);
 if(request.operation==='attack'&&!ack.result?.actorSectionsR52)process.stdout.write('R57_UNCERTIFIED_DEATH '+JSON.stringify({status:ack.result?.result?.status,code:ack.result?.result?.body?.code,players:ack.result?.players?.length,tables:ack.result?.sharedRefresh?.tables,all:ack.result?.sharedRefresh?.all,mistLoot:ack.result?.mistLoot!==undefined,keys:Object.keys(ack.result??{})})+'\n');
 return ack;
};
const traces=new WeakMap(),apply=ResidentChannel.prototype.applyCommit;
ResidentChannel.prototype.applyCommit=async function(result,context){
 const start=performance.now();
 try{return await apply.call(this,result,context);}
 finally{
  const ms=performance.now()-start;
  if(ms>50||!result.actorSectionsR52){
   let rows=traces.get(this);if(!rows)traces.set(this,rows=[]);
   rows.push({ms,players:result.players?.length,status:result.result?.status,action:context?.input?.action,proof:!!result.actorSectionsR52,snapshot:!!result.actorCommitSectionsR57,sharedRefresh:result.sharedRefresh,mistLoot:result.mistLoot!==undefined,resultKeys:Object.keys(result),playerColumns:result.players?.map(p=>Object.keys(p).filter(k=>!Object.is(p[k],this.view.player(p.id)?.[k])))});
   rows.sort((a,b)=>b.ms-a.ms);rows.length=Math.min(rows.length,24);
  }
 }
};
const control=ChannelRuntime.prototype.control;
ChannelRuntime.prototype.control=async function(method,...args){
 const result=await control.call(this,method,...args);
 if(method==='metrics')result.r57RefreshTrace=traces.get(this.channel)??[];
 return result;
};
