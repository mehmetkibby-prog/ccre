import test from 'node:test';import assert from 'node:assert/strict';
import {FixedLoop} from '../working/core511-source/scripts/core511/fixed-loop.mjs';
import {ResidentState} from '../working/core511-source/scripts/core511/resident-state.mjs';
import {takeDeathBatchR57,deathBatchReplyR57} from '../working/core511-source/scripts/core511/death-batch-channel-r57.mjs';
import {deathBatchActorPayloadR57,deathBatchWorkerCallR57,guardDeathBatchActorsR57} from '../working/core511-source/scripts/core511/death-batch-writer-r57.mjs';
const enabled=process.env.CORE511_R57_DEATH_BATCH==='1';
test('worker secondary identity is bound to the fully authenticated parent envelope',()=>{
 const entry={actor:'p1',epoch:2,input:{action:'attack'},seed:'1'.repeat(64),receivedAtMs:90};
 const request={playerId:'p0',epoch:1,operation:'attack',operationId:'batch',payload:{input:{action:'attack'},seed:'2'.repeat(64),receivedAtMs:100,nowMs:100,resources:['player:p0','player:p1'],checkpointR53:{v:1},batchAttacksR57:[entry]}};
 const context={actor:'p1',epoch:2,key:'batch'},payload=deathBatchActorPayloadR57(request.payload,entry);
 assert.equal(deathBatchWorkerCallR57(request,payload,context,'attack'),enabled);
 for(const altered of [{...payload,input:{...entry.input}},{...payload,seed:'3'.repeat(64)},{...payload,resources:[...payload.resources]},{...payload,checkpointR53:{}},{...payload,receivedAtMs:91},{...payload,unexpected:1}])assert.equal(deathBatchWorkerCallR57(request,altered,context,'attack'),false);
 for(const altered of [{...context,actor:'p2'},{...context,epoch:3},{...context,key:'other'}])assert.equal(deathBatchWorkerCallR57(request,payload,altered,'attack'),false);
 if(enabled){const seen=[];guardDeathBatchActorsR57({},request.payload,{actor:'p0',epoch:1,key:'batch'},(_s,p,c,k)=>{seen.push({p,c,k});return true;});assert.equal(seen.length,1);assert.equal(seen[0].c.actor,'p1');assert.strictEqual(seen[0].p.input,entry.input);assert.throws(()=>guardDeathBatchActorsR57({},request.payload,{},()=>false),{code:'game_writer_security'});}
});
function fixture(){
 const state=new ResidentState(1),rules=Object.fromEntries(['movement','combat','ai','respawn','project'].map(k=>[k,()=>null]));
 const kernel=new FixedLoop({state,rules,send:()=>{},clock:()=>1000,wall:()=>1000});kernel.stopped=false;
 const ids=Array.from({length:7},(_,i)=>'p'+i),identities=new Map(),guards=[],mounts=[];
 for(const id of ids){state.put('players',{id,area:'forest',channel:1,role:'arkanist',hp:100,x:0,y:0});state.claim(id,1);kernel.admit(id,1);identities.set(id,{actor:id,epoch:1});}
 const monsters=new Map([['m',{id:'m',area:'forest',channel:1,x:0,y:0,hp:100,spawn_round:1}]]);
 const channel={kernel,state,identities,view:{monsters,player:id=>state.read('players',id),monster:id=>monsters.get(id)},ports:{guard:identity=>{guards.push(identity.actor);return true;}},checkpoints:{overdueR53:()=>false},retaliationMemory:{due:()=>[]},mounts:{enabled:true,beforeAction:id=>mounts.push(id)}};
 const runtime={channel,forceSharedActors:new Map(),localResident:()=>true,localGroup:id=>[id]};
 const enqueue=(id,action='attack',kind='combat')=>kernel.enqueue(id,{epoch:1,sequence:kernel.players.get(id).lastAccepted+1,kind,payload:{action,ability:2,targetId:'m',spawnRound:1}});
 enqueue('p0');const first=kernel.players.get('p0').queue.shift();
 const take=()=>takeDeathBatchR57(runtime,{id:'p0',inputOrder:first.order,now:1000,ids,targets:[{id:'m',spawnRound:1}],kernel});
 return {kernel,runtime,enqueue,take,guards,mounts};
}
test('only bounded accepted heads are consumed, guarded and dismounted; no result before fsync',async()=>{
 const f=fixture();for(let i=1;i<7;i++)f.enqueue('p'+i);const entries=f.take();assert.equal(entries.length,enabled?4:0);
 assert.deepEqual(f.guards,entries.map(e=>e.actor));assert.deepEqual(f.mounts,f.guards);
 for(const e of entries){const p=f.kernel.players.get(e.actor);assert.equal(p.lastApplied,0);assert.equal(p.results.length,0);assert.equal(p.deferred[0].sequence,e.sequence);}
 if(!enabled)return;
 let release;const disk=new Promise(r=>release=r),ids=['p0',...entries.map(e=>e.actor)];
 const pending=f.kernel.durableGroup(ids,()=>disk,{emitReceipt:false,groupAckResult:(ack,prior,id)=>deathBatchReplyR57(ack,prior,id,entries)});
 assert(entries.every(e=>f.kernel.players.get(e.actor).barrier));
 const batchResultsR57=entries.map((e,i)=>({actor:e.actor,sequence:e.sequence,result:{status:i===1?400:200,body:{actor:e.actor}}}));
 release({result:{batchResultsR57}});await pending;await Promise.resolve();
 for(const e of entries){const p=f.kernel.players.get(e.actor);assert.equal(p.lastApplied,e.sequence);assert.equal(p.results[0].body.actor,e.actor);assert.equal(p.barrier,null);assert.equal(p.deferred.length,0);}
 f.kernel.stop();
});
test('older potion, own movement, foreign scope and expired identity keep queue position',()=>{
 for(const scenario of ['potion','movement','foreign','guard','overdue']){
  const f=fixture();f.enqueue('p1',scenario==='potion'?'use_potion':scenario==='movement'?'move':'attack',scenario==='movement'?'movement':'combat');
  if(scenario==='movement')f.enqueue('p1');else f.enqueue('p2');
  if(scenario==='foreign')f.runtime.localGroup=()=>['foreign'];
  if(scenario==='guard')f.runtime.channel.ports.guard=()=>({status:403});
  if(scenario==='overdue')f.runtime.channel.checkpoints.overdueR53=()=>true;
  assert.equal(f.take().length,0,scenario);assert(f.kernel.players.get('p1').queue.length>0);assert.equal(f.kernel.players.get('p1').deferred.length,0);
 }
});
test('a corrupt batch ACK cannot settle any member of the group',async()=>{
 if(!enabled)return;const f=fixture();f.enqueue('p1');f.enqueue('p2');const entries=f.take();assert.equal(entries.length,2);
 const ack={result:{batchResultsR57:entries.map(e=>({actor:e.actor,sequence:e.sequence,result:{status:200}}))}};ack.result.batchResultsR57[1].sequence++;
 await f.kernel.durableGroup(['p0','p1','p2'],()=>ack,{emitReceipt:false,groupAckResult:(a,p,id)=>deathBatchReplyR57(a,p,id,entries)});await new Promise(r=>setImmediate(r));
 assert.equal(f.kernel.failure?.code,'death_batch_ack_actor');for(const id of ['p1','p2']){const p=f.kernel.players.get(id);assert.equal(p.lastApplied,0);assert.equal(p.results.length,0);assert(p.barrier);}f.kernel.stop();
});
test('a second input of the same actor stays queued and cannot be jumped by a later actor',()=>{
 const f=fixture();f.enqueue('p1');f.enqueue('p1');f.enqueue('p2');const entries=f.take();assert.equal(entries.length,enabled?1:0);assert.equal(f.kernel.players.get('p1').queue.length,enabled?1:2);assert.equal(f.kernel.players.get('p2').queue.length,1);
});
