#!/usr/bin/env bash
# R57 candidate plus causal all-off controls, in disposable real-process fixtures.
set -euo pipefail
cd "$(dirname "$0")/.."
python3 tests-r57/seal-focused.py begin
set -a
. ./r57-candidate.env
set +a
export NODE_OPTIONS="--no-warnings --import $PWD/tests/native-fixture-support/register-cloud-fixture.mjs"
export COL_CLOUD_ISOLATED_FIXTURE=1 R35_CORE_REGRESSION=1
export COL_TEST_ACORN_MODULE="$PWD/working/deps/build/node_modules/acorn/dist/acorn.mjs"
export COL_CORE511_SCOPE_MODULE="$PWD/working/deps/build/node_modules/eslint-scope"
node_bin=./tooling/node-v22.22.0-linux-x64/bin/node
"$node_bin" --test --test-concurrency=1 tests-r57/*.test.mjs > evidence-r57/r57-focused.log 2>&1
export CORE511_R57_COMMIT_SECTIONS=0 CORE511_R57_CHECKPOINT_WIRE=0 CORE511_R57_PORTAL_SECTIONS=0 CORE511_R57_GROUP_FAIRNESS=0 CORE511_R57_ITEM_REFRESH=0 CORE511_R57_REPLY_WIRE=0 CORE511_R57_WEAPON_COUNTER=0 CORE511_R57_CHECKPOINT_SCHEDULE=0 CORE511_R57_CLEAN_JOIN=0 CORE511_R57_JOINED_ACK=0 CORE511_R57_AUTHORITY_READ=0 CORE511_R57_COMBAT_CONTINUATION=0 CORE511_R57_DEATH_BATCH=0 CORE511_R57_COMPLETE_LOCAL_REWARDS=0
"$node_bin" --test --test-concurrency=1 tests-r57/commit-sections.test.mjs tests-r57/checkpoint-schedule.test.mjs tests-r57/group-fairness-process.test.mjs tests-r57/portal-process.test.mjs tests-r57/clean-join.test.mjs tests-r57/joined-ack.test.mjs tests-r57/authority-read.test.mjs tests-r57/combat-continuation.test.mjs tests-r57/death-batch-channel.test.mjs tests-r57/death-batch-single.test.mjs tests-r57/resource-authority.test.mjs tests-r57/planned-seed.test.mjs > evidence-r57/r57-off-control.log 2>&1
python3 tests-r57/seal-focused.py finish
