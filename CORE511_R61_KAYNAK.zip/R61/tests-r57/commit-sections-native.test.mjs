import test from 'node:test';
import assert from 'node:assert/strict';
import {setupPvp,put,update} from '../working/core511-source/scripts/core511/tests/pvp-fixture.mjs';
import {GameWriter} from '../working/core511-source/scripts/core511/writer-runtime.mjs';
import {readActorDropsR52} from '../working/core511-source/scripts/core511/actor-drop-read-r52.mjs';
import {captureCommitSectionsR57} from '../working/core511-source/scripts/core511/actor-commit-sections-r57.mjs';
import {ReadWorker} from '../working/core511-source/scripts/core511/read-worker.mjs';

test('native commit snapshot matches exact 25-owner/drop/encounter reads without extra writes, with size fallback',async t=>{
 const f=await setupPvp(t),{sql}=f;f.reset({area:'forest'});
 sql.prepare('UPDATE players SET last_seen=0 WHERE id<>?').run(f.id);
 const first=sql.prepare('SELECT * FROM players WHERE id=?').get(f.id),account=sql.prepare('SELECT * FROM accounts WHERE id=?').get(first.account_id),ids=[f.id];
 for(let i=1;i<25;i++){
  const id='read-group-'+i,aid='read-group-account-'+i;
  put(sql,'accounts',{...account,id:aid,username:aid,username_normalized:aid,email:aid+'@fixture.invalid',email_normalized:aid+'@fixture.invalid'});
  put(sql,'players',{...first,id,account_id:aid});ids.push(id);
 }
 const peer={realm:'read-group',channel:1,incarnation:'read-group-boot-0001'},writer=new GameWriter(f.f.database,{realmId:peer.realm,clock:()=>f.nowMs,ports:{guard:()=>true}});
 await writer.initialize();await writer.register(peer);
 const wanted=[];
 for(const [i,id]of ids.entries()){
  const owner=await writer.admit(id,peer,{sessionId:'session-'+id,guard:()=>true});wanted.push({actor:id,epoch:owner.epoch,area:'forest'});
  if(i%2===0)put(sql,'pve_engagements',{player_id:id,monster_id:'golge-attack511',spawn_round:1,next_hit_at_ms:f.nowMs+1000,expires_at_ms:f.nowMs+60000,hit_sequence:i,updated_at_ms:f.nowMs,last_skill_at_ms:0,attackers489:'{}'});
  put(sql,'world_drops',{id:'read-group-drop-'+i,owner_id:id,monster_id:'golge-read-group-'+i,kind:'essence',item_name:'Fixture',rarity:'common',power:1,amount:i+1,role:'all',enchantments:'[]',x:2700,y:2025,expires_at:Math.floor(f.nowMs/1000)+60,collectible_at:Math.floor(f.nowMs/1000)});
 }
 const cycle=sql.prepare('SELECT cycle FROM world_state WHERE id=1').get().cycle;
 const params=(actors,includeDrops=true)=>[1,peer.incarnation,cycle,f.nowMs,actors,includeDrops];
 const legacy=[];for(let i=0;i<wanted.length;i+=4)legacy.push(...readActorDropsR52(sql,params(wanted.slice(i,i+4))).actors);
 const grouped=readActorDropsR52(sql,params(wanted));assert.equal(grouped.complete,true);assert.deepEqual(grouped.actors,legacy);assert.equal(sql.isTransaction,false);

 const reward={result:{status:200},players:grouped.actors.map(a=>a.player),actorSectionsR52:{version:1,cycle,readSections:true,readDrops:true,actors:grouped.actors.map(a=>({id:a.id,owner:a.owner}))}};
 const beforeChanges=sql.prepare('SELECT total_changes() n').get().n;let captured;
 await f.f.database.atomic(()=>{captured=captureCommitSectionsR57(sql,reward,{nowMs:f.nowMs});});
 assert.deepEqual(captured.actorCommitSectionsR57,{...grouped,readAtMs:f.nowMs});
 assert.equal(sql.prepare('SELECT total_changes() n').get().n,beforeChanges,'capture must not mutate SQL');
 assert.equal(captureCommitSectionsR57(sql,reward,{nowMs:f.nowMs}),reward,'never capture outside a write transaction');
 await f.f.database.atomic(()=>{assert.equal(captureCommitSectionsR57(sql,{...reward,padding:'x'.repeat(512*1024)},{nowMs:f.nowMs}).actorCommitSectionsR57,undefined);});
 const reader=new ReadWorker(f.f.file,new Map(),{actorBundles:true});t.after(()=>reader.close());
 const threaded=(await reader.query('kernel511_actor_drops_r52',params(wanted))).rows;
 assert.deepEqual(JSON.parse(JSON.stringify(grouped)),threaded);assert.equal(threaded.actors[0].drops.find(d=>d.id==='read-group-drop-0').amount,1);assert.equal(threaded.actors[1].engagement,null);
 const noDrops=readActorDropsR52(sql,params(wanted,false));assert(noDrops.actors.every(a=>!Object.hasOwn(a,'drops')));
 const before=sql.prepare('SELECT total_changes() n').get().n;
 for(const actors of [[...wanted,wanted[0]],[wanted[0],wanted[0]],wanted.map((w,i)=>i===24?{...w,epoch:w.epoch+1}:w)])assert.throws(()=>readActorDropsR52(sql,params(actors)));
 assert.equal(sql.prepare('SELECT total_changes() n').get().n,before);assert.equal(sql.isTransaction,false);
 update(sql,'players',wanted[24].actor,{arena_match_id:'another-mode'});assert.throws(()=>readActorDropsR52(sql,params(wanted)),{code:'actor_drop_read_scope'});update(sql,'players',wanted[24].actor,{arena_match_id:''});
 // Each row fits the original per-owner limit; the aggregate exceeds the
 // new wire bound. No partial rows escape, and the legacy chunks still fit.
 sql.exec('DELETE FROM pve_engagements');
 for(const id of ids)put(sql,'pve_engagements',{player_id:id,monster_id:'golge-attack511',spawn_round:1,next_hit_at_ms:f.nowMs+1000,expires_at_ms:f.nowMs+60000,hit_sequence:1,updated_at_ms:f.nowMs,last_skill_at_ms:0,attackers489:JSON.stringify({fixture:'x'.repeat(26000)})});
 assert.deepEqual(readActorDropsR52(sql,params(wanted)),{version:1,complete:false,reason:'bounds'});assert.equal(sql.isTransaction,false);
 for(let i=0;i<wanted.length;i+=4)assert.equal(readActorDropsR52(sql,params(wanted.slice(i,i+4))).complete,true);
});
