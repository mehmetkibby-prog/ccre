import test from 'node:test';import assert from 'node:assert/strict';
import {fixture} from '../tests/checkpoint-fixture-r531.mjs';
import {deathActorNeedsCheckpointR57 as needed} from '../working/core511-source/scripts/core511/clean-join-r57.mjs';
import {EncounterCheckpoints} from '../working/core511-source/scripts/core511/encounter-checkpoint.mjs';
const enabled=process.env.CORE511_R57_CLEAN_JOIN==='1';
test('clean reward recipient follows the same no-write decision as ordinary drain; attacker remains captured',async t=>{
 const s=await fixture(t);assert.equal(needed(s.checkpoints,'p','p'),true);assert.equal(needed(s.checkpoints,'q','p'),!enabled);
 const before=s.authority.owner('q').sequence;assert.deepEqual(await s.checkpoints.drain('q'),{unchanged:true});assert.equal(s.authority.owner('q').sequence,before);
 s.state.patch('players','q',{x:7,position_revision:2});assert.equal(needed(s.checkpoints,'q','p'),true);
 const token=s.checkpoints.captureR53('q');assert.equal(token.payload.current.x,7);s.checkpoints.finishR53(token);
});
test('encounter-only changes and queued checkpoints cannot be omitted',async t=>{
 const s=await fixture(t),rows=new Map(),encounters=new EncounterCheckpoints(id=>rows.get(id)??null);s.checkpoints.encounters=encounters;for(const id of ['p','q'])encounters.hydrate(id,null);
 assert.equal(needed(s.checkpoints,'q','p'),!enabled);
 rows.set('q',{player_id:'q',monster_id:'m',spawn_round:1,next_hit_at_ms:1,expires_at_ms:2,hit_sequence:0,updated_at_ms:1,last_skill_at_ms:0,attackers489:'{}'});assert.equal(needed(s.checkpoints,'q','p'),true);rows.delete('q');
 const e=s.checkpoints.entries.get('q');e.pending=Promise.resolve();assert.equal(needed(s.checkpoints,'q','p'),true);e.pending=null;
 e.joinedR53={};assert.equal(needed(s.checkpoints,'q','p'),true);delete e.joinedR53;
});
test('clean selection retains foreign-epoch and quarantined-journal fences',async t=>{
 const s=await fixture(t),entry=s.checkpoints.entries.get('q'),error=Object.assign(Error('snapshot conflict'),{code:'checkpoint_snapshot_conflict'});
 entry.rejectedR531=error;assert.equal(needed(s.checkpoints,'q','p'),true);assert.throws(()=>s.checkpoints.captureR53('q'),e=>e===error);delete entry.rejectedR531;
 s.state.owners.get('q').epoch++;if(enabled)assert.throws(()=>needed(s.checkpoints,'q','p'),e=>e.code==='owner_epoch_fenced');else assert.equal(needed(s.checkpoints,'q','p'),true);
});
