import hashlib,json,os,sys,tempfile,zipfile
from pathlib import Path
os.umask(0o077)
archive=Path(sys.argv[0]).resolve()
try:
 with zipfile.ZipFile(archive) as z,tempfile.TemporaryDirectory(prefix='core-r102-auto-ip-') as temp:
  rows=json.loads(z.read('modules.json'))
  for name,digest in rows.items():
   if Path(name).name!=name or not name.endswith(('.py','.mjs')):raise RuntimeError('Paket modul yolu farkli')
   data=z.read('modules/'+name)
   if hashlib.sha256(data).hexdigest()!=digest:raise RuntimeError('Paket butunlugu bozuk')
   (Path(temp)/name).write_bytes(data)
  sys.path.insert(0,temp)
  from installer import main
  main(archive)
except Exception as error:
 print('DURDU: '+str(error),file=sys.stderr)
 sys.exit(1)
