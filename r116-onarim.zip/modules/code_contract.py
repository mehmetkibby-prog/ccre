# Exact reviewed R116 server-code contract.
PLAN_SHA256 = '37b3f5413e5d4fe000381d39ef32e60ae4258a2f05b0e6788b101785bf3d60cd'
