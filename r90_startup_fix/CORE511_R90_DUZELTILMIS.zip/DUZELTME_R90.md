# R90 acilis duzeltmesi

Ozgun R90 HTTP dosyasini degistiriyor fakat native-http-composition-proof.json dosyasini pakete almiyordu. Gercek HTTP sunucusu native_http_server_entry_changed ile acilisi reddediyordu.

Bu paket HTTP ile dogrulama kaydini birlikte gunceller. Acilis hash kontrolu korunur; paket yuklenirken eslesme ayrica denetlenir. Oyun degisiklikleri R90 ile aynidir. Istemci, hesaplar ve veritabani semasi degismez.

Once ozgun paketin geri almasi tamamlanmali ve R89 kurulu olmalidir. Tamamlanmamis eski kurulum kaydi varsa bu paketle kurtarmaya calismayin; ozgun R90 --recover kullanilir. Sonra bakimda ve oyuncular cikmisken bu paket --apply ile uygulanir. Normal yedek ve saglik kontrolleri korunur. Refused hatasinin gercek nedeni artik gorunur; disk kontrolu uzun dosya taramasindan once yapilir.
