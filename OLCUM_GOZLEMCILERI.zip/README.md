# Koşuda kullanılan gözlemci

Her koşunun source.json içindeki validation/recovery-observer.mjs SHA değeriyle birebir eşleşen dosya bu ZIP'tedir. Baseline gözlemci, arızalı son aday gözlemcisi ve çıktı sınırı giderilmiş düz koşu gözlemcisi korunur. Üretim oyun kaynağı bu gözlemci sürümleri arasında değişmedi.

Yeni kaynak ZIP'i düzeltilmiş, büyük çıktıyı tekrar etmeyen gözlemciyi varsayılan getirir. Eski bir arızalı koşunun gözlemcisini birebir tekrar kullanmak için bağımsız test klasörünüzde RUN_OBSERVERS.json'daki dosyayı validation/recovery-observer.mjs yerine kopyalayın; runner başta bu dosyanın SHA'sını yeniden kaydeder. Eski v2 gözlemcisinin düz yoğun yükte JSON çıktı sınırı hatası bilinir, bu nedenle yeni düz koşular düzeltilmiş sürümle çalıştırılmıştır. Baseline'ların kendi kaynak ZIP'leri zaten kendi gözlemcilerini içerir. Bu işlem yalnız test gözlemcisini değiştirir; oyun dosyalarına uygulanmaz.
