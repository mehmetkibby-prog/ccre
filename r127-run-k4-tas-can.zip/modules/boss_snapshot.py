"""Preserve only the two Efsane rows withdrawn by the stopped-host hotfix."""
from contextlib import closing, contextmanager
from hashlib import sha256
from pathlib import Path
import sqlite3

from storage import descriptor, encoded, require

MONSTER = 'rune-v2-boss-c4-1'
TABLES = ('monsters', 'rune_v2_boss_state484')
SCOPE = 'r1:rune_v2:4:rune-v2-boss-c4-1'


@contextmanager
def connection(live, *, write=False):
    target = next(r for r in live.manifest['realms'] if r['id'] == 'r1')
    path = Path(target['database']).resolve()
    efsane, academy = live.databases['r1'], live.databases['r2']
    require(descriptor(path) == efsane and
            (efsane['device'], efsane['inode']) != (academy['device'], academy['inode']),
            'Efsane veritabanı bağı değişti')
    uri = path.as_uri() + ('?mode=rw' if write else '?mode=ro')
    with closing(sqlite3.connect(uri, uri=True, timeout=5)) as db:
        db.row_factory = sqlite3.Row
        if write:
            db.execute('PRAGMA foreign_keys=ON')
            db.execute('PRAGMA synchronous=FULL')
        db.execute('BEGIN IMMEDIATE' if write else 'BEGIN')
        row = db.execute('SELECT realm_id,database_id FROM realm_identity WHERE id=1').fetchone()
        require(row and tuple(row) == ('r1', target['dbIdentity']), 'Efsane kimliği doğrulanamadı')
        yield db, target['dbIdentity']
        db.commit()


def rows(db):
    result = {}
    for table in TABLES:
        row = db.execute('SELECT * FROM '+table+' WHERE id=?', (MONSTER,)).fetchone()
        result[table] = dict(row) if row else None
        require(row is None or row['channel'] == 4, 'Boss kaydının kanalı farklı')
    monster = result['monsters']
    require(monster is None or
            (monster['area'],monster['is_boss'],monster['is_stone'],monster['summoned'],monster['loadlab_run_id']) ==
            ('rune_v2',0,0,0,''), 'Boss kaydının haritası veya türü farklı')
    return result


def snapshot(live):
    with connection(live) as (db, identity):
        data = {'dbIdentity': identity, 'scope': SCOPE, 'rows': rows(db)}
    return {'data': data, 'sha256': sha256(encoded(data)).hexdigest()}


def verify(saved, manifest):
    data = saved['data']
    identity = next(r['dbIdentity'] for r in manifest['realms'] if r['id'] == 'r1')
    require(sha256(encoded(data)).hexdigest() == saved['sha256']
            and data['scope'] == SCOPE and data['dbIdentity'] == identity
            and set(data['rows']) == set(TABLES), 'Boss geri dönüş kaydı doğrulanamadı')
    for row in data['rows'].values():
        require(row is None or (row['id'], row['channel']) == (MONSTER, 4), 'Boss geri dönüş kapsamı farklı')
    return data['rows']


def assert_withdrawn(live):
    require(all(row is None for row in snapshot(live)['data']['rows'].values()),
            'Efsane Kanal 4 bossu veya bekleyen saldırısı hâlâ etkin')


def restore(live, saved):
    expected = verify(saved, live.manifest)
    with connection(live, write=True) as (db, _):
        current = rows(db)
        initial = db.total_changes
        inserted = 0
        for table in TABLES:
            row = expected[table]
            if current[table] == row:
                continue
            require(current[table] is None and row is not None, 'Boss geri dönüşünde canlı kayıt çakışması')
            columns = [r['name'] for r in db.execute('PRAGMA table_info('+table+')')]
            require(set(columns) == set(row), 'Boss geri dönüşünde tablo sütunları farklı')
            names = ','.join('"'+n.replace('"','""')+'"' for n in columns)
            placeholders = ','.join('?' for n in columns)
            db.execute('INSERT INTO '+table+'('+names+') VALUES('+placeholders+')', [row[n] for n in columns])
            inserted += 1
        require(db.total_changes-initial == inserted and rows(db) == expected, 'Boss geri yükleme doğrulaması başarısız')
