"""Read a complete file or reconstruct it from verified bytes in the installed release."""
import base64
import hashlib
import json

from inplace_stage import checked_path
from storage import require


def read_payload(root, archive, plan, name):
    row = plan['files'][name]
    delta = row.get('delta')
    if delta is None:
        data = archive.read('payload/' + name)
    else:
        source = checked_path(root, delta['source']).read_bytes()
        source_hash = hashlib.sha256(source).hexdigest()
        if delta['source'] == name and source_hash == row['after']:
            data = source
        else:
            require(source_hash == delta['sourceSHA256'], 'Fark yamasının kaynak dosyası farklı: ' + name)
            patch = archive.read('delta/' + name + '.json')
            require(hashlib.sha256(patch).hexdigest() == delta['patchSHA256'], 'Fark yaması bozuk: ' + name)
            pieces = []
            offset = 0
            for start, end, replacement in json.loads(patch):
                require(type(start) is int and type(end) is int and offset <= start <= end <= len(source),
                        'Fark yamasının dosya aralığı geçersiz: ' + name)
                pieces.extend((source[offset:start], base64.b64decode(replacement, validate=True)))
                offset = end
            pieces.append(source[offset:])
            data = b''.join(pieces)
    require(len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['after'],
            'Kurulacak dosya paket kimliğiyle eşleşmiyor: ' + name)
    return data
