export const PAUSED_RUNE_PREDATOR = 'rune-v2-boss-c4-1';

// Both realms use the same monster IDs. Use the game's bound SQLite identity.
export function runePredatorPaused(sql) {
  const bound = sql.prepare("SELECT 1 FROM sqlite_schema WHERE type='table' AND name='realm_identity'").get();
  return Boolean(bound && sql.prepare('SELECT realm_id FROM realm_identity WHERE id=1').get()?.realm_id === 'r1');
}

// The host calls this inside its exclusive startup transaction, before any
// channel loads a combat snapshot. Keeping the defeat and contribution ledgers
// also keeps previously earned rewards and the original spawn identity intact.
export function withdrawRunePredator(sql) {
  if (!sql.isTransaction) throw Error('rune_predator_pause_requires_transaction');
  if (!runePredatorPaused(sql)) return;
  const monster = sql.prepare('SELECT area,channel,is_boss,is_stone,summoned,loadlab_run_id FROM monsters WHERE id=?').get(PAUSED_RUNE_PREDATOR);
  if (monster && (monster.area !== 'rune_v2' || monster.channel !== 4 || monster.is_boss ||
      monster.is_stone || monster.summoned || monster.loadlab_run_id !== '')) return;

  const total = sql.prepare('SELECT total_changes() AS n');
  const before = total.get().n;
  const cast = sql.prepare('DELETE FROM rune_v2_boss_state484 WHERE id=? AND channel=4').run(PAUSED_RUNE_PREDATOR);
  const beast = sql.prepare("DELETE FROM monsters WHERE id=? AND channel=4 AND area='rune_v2' AND is_boss=0 AND is_stone=0 AND summoned=0 AND loadlab_run_id=''").run(PAUSED_RUNE_PREDATOR);
  if (total.get().n - before !== cast.changes + beast.changes) throw Error('rune_predator_pause_unexpected_side_effect');
}
