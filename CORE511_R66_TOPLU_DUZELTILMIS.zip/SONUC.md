# R66 toplu sonuç — 28 Ekim 2026

R65 üzerine tek pakette giriş düzeltmesi, iki yönetim kaydı düzeltmesi ve düzenlenmiş panel hazırlandı. Canlı VDS'ye kurulum yapılmadı.

## Düzeltilen hatalar

**Efsun kaydında `ipc_frame_size`:** Ayar değişince kanalların aldığı yenileme verisi 1 MiB sınırını aşabiliyordu. `read_channel_refresh`, mevcut sınırlı parçalı aktarım yoluna eklenmemişti. Eksik giderildi. Çerçeve sınırı büyütülmedi; tek alınan veri parçalanıyor, ayar işlemi veya sorgu yeniden uygulanmıyor.

Mevcut canavarlar için 100 çevrimdışı oyuncunun 90'ar katılım kaydıyla veri büyüklüğü sınandı. Bu, 9.000 çevrimiçi oyuncu veya savaş performansı ölçümü değildir.

| Aynı efsun kaydı | R65 | R66 |
|---|---|---|
| Sonuç | HTTP 500, `ipc_frame_size` | HTTP 200 |
| 1 MiB üzerindeki kanal görüntüsü | Aktarılamıyor | Parçalı aktarım |
| Aynı sahip süreçleriyle tamamlama | Hayır | Evet |
| Sonraki ışınlanma | Hata senaryosu | Başarılı |

R66'da dört kanal görüntüsü birer kez okundu; 9 parça, en büyük parça 262.233 bayt. Hata kaydı yoktu; ortak dünya ve dört kanal aynı süreçlerle devam etti.

**Kırık Yaşam Çekirdeği kaydında `permanent_actor_set`:** Genel ayar kaydı boş oyuncu listesiyle tek oyuncu işlem yolunu çağırıyordu. Yalnız bu kayıt, yeniden yetki kontrolü yapan mevcut genel ayar sınırına alındı. Oyuncuya gönderme/geri alma, işlem kimliği ve veritabanı doğrulamaları korundu. Tekrar istek ikinci kayıt üretmiyor; eski sürüm ve geçersiz değerler reddediliyor.

**Aynı internetten toplu giriş:** Önceki R66 giriş düzeltmesi dahil edildi. Aynı IP'den 30 farklı geçerli hesap, önceki kodda 12 başarı/18 oran sınırı hatası; düzeltmeyle 30/30 başarı. Parola ve mevcut limitler korunuyor; IP sayımı mevcut parola kuyruğunun içinde yapılıyor.

## Panel

38 bölüm altı grupta toplandı: Genel yönetim; Eşya ve gelişim; Haritalar ve savaş; Etkinlikler ve ödüller; Ekonomi; Güvenlik ve sunucu.

Türkçe arama, hızlı erişim ve seçili bölüm göstergesi eklendi. Efsunlar ve Kale Savaşı ayrı bölümler oldu. Bazı dünya/yeniden doğma alanları doğru gruba taşındı. Kaydedilmemiş efsun taslağı bölüm değişince korunuyor. Canlı işlem yükü yalnız Genel Bakış'ta çalışıyor. Menü yeni ağ isteği veya oyun zamanlayıcısı başlatmıyor.

Mobil ve masaüstü görünüm sınandı. Kale girişleri/düğmeleri belirginleştirildi; mobilde yatay taşma görülmedi. İlk çizim R65 ile aynı tutulup yeni menü tarayıcı hazır olunca açılıyor; ilk DOM karşılaştırması 58.118 baytta birebir eşleşti.

## Yerel doğrulama

- **38/38 bölüm** açıldı; arama/gezinme çalıştı, JavaScript hatası görülmedi.
- **23 bölümde kayıt:** efsun, artı basma, malzemeler, binek, statü, rün, uzmanlık, kale, solo zindan, kule, Sis Yarığı, Karanlık Rün Sahili, etkinlikler, ortak etkinlik, görevler, savaş bileti, çark, kazan, Kırık Yaşam Çekirdeği, balıkçılık, Nesne Market, Arena Market ve şüpheli doğrulama ayarları. Gerçek HTTP işleyicileri ve geçici SQLite kullanıldı.
- Mobilde kale test savaşı başlatıldı ve bitirildi. Çark/balıkçılık toplamı %100 değilken kayıt engellendi; toplam düzeltilince kaydedildi.
- Yönetici yetkisi, Origin/gövde kontrolü, eski ayar sürümü, tekrar istek, kabul edilmiş oyuncu işlemlerinin tamamlanması ve hata sonrası toparlanma sınandı.
- Kurucular: panel **8**, hesap **5**, birleşik kurulum/geri alma **2**, paket yönlendirmesi **5** senaryoyu geçti. Son istemci için manifest/sürümleme ayrıca kontrol edildi. Gerçek dosyalar, SQLite ve hesap kayıtları kullanıldı; systemd ve oyun sağlık sinyali kontrollü test karşılıklarıydı.
- Önceki R66'nın 20/30 hesap açma-giriş, kanal seçimi, ilk oyun işlemleri, yeniden bağlanma ve açılış kontrolleri aynı giriş düzeltmesiyle geçti. Bu panel çalışması yeni bir 100 oyuncu gecikme ölçümü sunmaz.

Eski regresyon paketinde altı lonca testi zorunlu kanal seçimini yapmadan başlamaya çalışıyordu. Test hazırlığı güncel giriş sözleşmesine uyarlandı; altısı geçti. Bir başka test, R63'ün korumalı girdi kuyruğunu eski `barrier` göstergesiyle arıyordu; aynı başarısızlık R65'te de tekrarlandı. Test artık kabul edilmiş/henüz uygulanmamış kuyruğu ve kilit açıldıktan sonraki kalıcı sonucu doğruluyor; sekiz senaryo geçti. Bu uyarlamalar oyun kodunu değiştirmedi.

## Kurulum ve kapsam

Kaynak kimliği, dosya özetleri ve başlatma yapılandırması doğrulanır; bilinmeyen sürüm zorla geçilmez. Yeni panel ayrı sürüm adresine alınır, eski tarayıcı dosyaları silinmez. Yerel dışa aktarımda bulunmayan Vite başvuru dosyaları, VDS'nin doğrulanmış manifestindeki dosyalardan dönüştürülür.

Hesap düzeltmesinde kısa hesap servisi yeniden başlatması gerekir. Panel kurulumu boyunca hesap servisi açıktır. Açılış/ön kayıt ayarı, site ve veritabanları korunur. Geri alma veritabanı görüntüsü geri yüklemez.

Yerel kaynak dışa aktarımında canlı yük testi eklentisi ve bazı eski medya/SSR dosyaları bulunmuyor. Bot Testi'nin eklenti yok durumunu gösterdiği kontrol edildi; eklentinin VDS'de çalışması, harici e-posta/E-PIN teslimatı ve canlı Cloudflare yolu burada uçtan uca doğrulanmadı. Bölümlerin görüntülenmesi, tüm olası yönetici işlemlerinin her veri durumunda hatasız olduğuna dair garanti değildir. Ayrıntılı kanıtlar `panel-evidence/` altında saklanır.
