"""R66: giriş düzeltmesi, efsun kaydı ve düzenli yönetim paneli."""
import argparse,hashlib,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path

STATE=Path('/var/lib/core511/state.json')
ACCOUNT_ACTIVE=Path('/var/lib/core511/r66-accounts-updates/active.json')
PANEL_ACTIVE=Path('/var/lib/core511/r64-updates/active.json')
PARTS=('ACCOUNTS_R66.zip','PANEL_R66.zip')

def execute(action,directory,runner=None,read_state=None,exists=None):
 runner=runner or (lambda name,flag:subprocess.run([sys.executable,'-u',str(directory/name),flag],check=True))
 read_state=read_state or (lambda:json.loads(STATE.read_text()))
 exists=exists or (lambda p:p.exists())
 def run(name,flag):
  print('R66 ADIM: '+name+' '+flag,flush=True);runner(name,flag)
 if action in ('check','apply'):
  if exists(ACCOUNT_ACTIVE) or exists(PANEL_ACTIVE):raise RuntimeError('Yarım kurulum var. Önce aynı paketle --recover çalıştırın.')
  for name in PARTS:run(name,'--'+action)
  print('R66 TOPLU '+('KONTROL GEÇTİ.' if action=='check' else 'TAMAMLANDI. Giriş düzeltmesi ve yönetim paneli kuruldu. Açılış/ön kayıt ayarı korundu.'),flush=True)
 elif action=='recover':
  accounts,panel=exists(ACCOUNT_ACTIVE),exists(PANEL_ACTIVE)
  if accounts and panel:raise RuntimeError('İki kurulum kaydı aynı anda açık. Otomatik kurtarma durduruldu; bu çıktıyı paylaşın.')
  if not accounts and not panel:print('Yarım R66 kurulumu yok. Tamamlamak için --apply kullanabilirsiniz.',flush=True);return
  run(PARTS[0] if accounts else PARTS[1],'--recover')
  print('Kurtarma tamamlandı. R66 toplu kurulumu tamamlamak için aynı paketi --apply ile çalıştırın.',flush=True)
 else:
  if exists(ACCOUNT_ACTIVE) or exists(PANEL_ACTIVE):raise RuntimeError('Önce --recover çalıştırın.')
  changed=False
  if read_state().get('r64Deployment',{}).get('version')=='R66_PANEL':run(PARTS[1],'--rollback-latest');changed=True
  if read_state().get('r66Accounts',{}).get('version')=='R66_LOGIN':run(PARTS[0],'--rollback-latest');changed=True
  print('R66 geri alındı. Yeni hesaplar ve oyun verileri korundu.' if changed else 'Geri alınacak kurulu R66 bulunamadı.',flush=True)

def main():
 parser=argparse.ArgumentParser(description=__doc__);group=parser.add_mutually_exclusive_group(required=True)
 for action in ('check','apply','recover','rollback-latest'):group.add_argument('--'+action,action='store_true')
 args=parser.parse_args();action=next(k.replace('_','-') for k,v in vars(args).items() if v)
 os.umask(0o077)
 if os.geteuid()!=0:raise RuntimeError('Root olarak çalıştırın.')
 with zipfile.ZipFile(Path(sys.argv[0]).resolve()) as archive,tempfile.TemporaryDirectory(prefix='core-r66-toplu-') as temp:
  expected=json.loads(archive.read('bundle.json'))
  if expected.get('version')!='R66_TOPLU' or set(expected['parts'])!=set(PARTS):raise RuntimeError('Toplu paket kapsamı geçersiz.')
  for name in PARTS:
   data=archive.read(name)
   if hashlib.sha256(data).hexdigest()!=expected['parts'][name]:raise RuntimeError('Paket bütünlüğü bozuk: '+name)
   (Path(temp)/name).write_bytes(data)
  execute(action,Path(temp))

if __name__=='__main__':
 try:main()
 except (Exception,KeyboardInterrupt) as error:
  print('R66 TOPLU TAMAMLANMADI: '+(str(error) if isinstance(error,RuntimeError) else type(error).__name__),flush=True)
  print('Başarılı önceki adım korunur. Yukarıdaki DURDU satırını paylaşın; veritabanı yedeği geri yüklenmez.',flush=True)
  sys.exit(1)
