# R66 toplu güncelleme

Paket: `CORE511_R66_TOPLU.zip`. Kurulu **R65 ışınlanma düzeltmesi** üzerine uygulanır. Daha önce yalnız R66 giriş düzeltmesi kurulduysa onu tekrar kurmaz; paneli tamamlar.

Oyun Durumu panelinde **ön kayıt**, açılış saati henüz gelmemiş **otomatik açılış**, veya tamamlanmış **bakım** kullanılabilir. Oyunda oyuncu/admin bulunmamalı; karakterden çıktıktan sonra 45 saniye bekleyin. Ön kayıt ekranını kapatmanız gerekmez.

Dosya `/root/CORE511_R66_TOPLU.zip` konumundayken tek komut:

```bash
python3 -u /root/CORE511_R66_TOPLU.zip --apply
```

Kurucu kaynak ve dosya bütünlüğünü kendisi kontrol eder. Sonunda **R66 TOPLU TAMAMLANDI** yazmalıdır. Tek bileşenin tamamlanması, toplu kurulumun tamamlandığı anlamına gelmez.

İlk adımda giriş düzeltmesi için **hesap servisi kısa süreli yeniden başlar**. Bu aralıkta kayıt isteğini yeniden denemek gerekebilir. Panel hazırlanırken ve oyun sunucusu güncellenirken hesap servisi çalışır. Açılış saati, ön kayıt ayarı, hesaplar, karakterler ve site dosyaları korunur. Kurucu oyunu kendiliğinden açmaz.

Yalnız kontrol:

```bash
python3 -u /root/CORE511_R66_TOPLU.zip --check
```

Yarım işlem varsa kurtarma, ardından kurulumu tamamlamak için tekrar `--apply`:

```bash
python3 -u /root/CORE511_R66_TOPLU.zip --recover
```

R66 oyun ve hesap kodunu önceki sürüme döndürme:

```bash
python3 -u /root/CORE511_R66_TOPLU.zip --rollback-latest
```

Geri alma da boş oyun ve uygun oyun durumu ister. Yalnız kod ve başlatma seçimi geri çevrilir; veritabanı yedeği geri yüklenmez, yeni hesaplar silinmez. İki güncelleme komutunu aynı anda çalıştırmayın. `DURDU` yazarsa kontrolü atlamayın; son çıktıyı paylaşın.

Panelde yeni yollar:

- **Eşya ve gelişim → Efsunlar**
- **Haritalar ve savaş → Kale Savaşı**
- **Genel yönetim → Genel Bakış:** canlı işlem yükü ve işlemci profili.

Arama ve üstteki hızlı erişim düğmeleriyle doğrudan bölüm seçilebilir. Yeni panel ayrı sürüm adresinden yüklenir; eski dosya adresleri korunur. Açık eski panel sekmesinde normal sayfa yenileme yeni arayüzü getirir.

Canlı VDS'ye buradan kurulmadı. Google Drive indirme komutunda bu yeni paketin bağlantısı ve `SHA256_TOPLU.txt` özeti kullanılmalı; önceki sürümün bağlantısı kullanılmaz.
