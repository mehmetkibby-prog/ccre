from pathlib import Path
import importlib.util,json,unittest
R=Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('wrapper',R/'build/combined.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Wrapper(unittest.TestCase):
 def run_case(self,base,fail_site=False):
  calls=[]
  def run(command):
   calls.append(command)
   if command==['game','--check']:return json.dumps({'uygun':True,'taban':base}) if base else 'R63_RECOVERY zaten kurulu.'
   if command==['site','--apply'] and fail_site:raise RuntimeError('injected site failure')
   return ''
  if fail_site:
   with self.assertRaisesRegex(RuntimeError,'injected site failure'):m.workflow(['game'],['site'],['--apply'],run=run)
  else:m.workflow(['game'],['site'],['--apply'],run=run)
  return calls
 def test_fresh_r61_and_r62_roll_back_if_site_fails(self):
  for base in ['R61','R62']:
   with self.subTest(base=base):self.assertEqual(self.run_case(base,True)[-1],['game','--rollback-latest'])
 def test_existing_r63_not_rolled_back_for_site_failure(self):self.assertNotIn(['game','--rollback-latest'],self.run_case(None,True))
 def test_both_checks_before_any_apply(self):self.assertEqual(self.run_case('R62'),[['game','--check'],['site','--check'],['game','--apply'],['site','--apply']])
if __name__=='__main__':unittest.main(verbosity=2)
