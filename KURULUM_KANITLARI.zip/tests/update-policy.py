from pathlib import Path
import contextlib,importlib.util,json,sqlite3,tempfile,time,unittest
from unittest.mock import patch
R=Path(__file__).resolve().parents[1]
sp=importlib.util.spec_from_file_location('installer',R/'package/__main__.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
(R/'tests/central-policy.mjs').write_text(m.UPDATE_POLICY_JS)
class Policy(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);root=Path(self.tmp.name)
  self.game=root/'game.sqlite';self.accounts=root/'accounts.sqlite'
  with sqlite3.connect(self.game) as db:db.executescript('CREATE TABLE game_presence(expires_at_ms INTEGER);CREATE TABLE players(last_seen INTEGER);CREATE TABLE kernel511_admissions(id TEXT);')
  with sqlite3.connect(self.accounts) as db:db.executescript("CREATE TABLE launch_settings(id INTEGER PRIMARY KEY,mode TEXT,revision INTEGER,maintenance_deadline_ms INTEGER,enabled INTEGER);INSERT INTO launch_settings VALUES(1,'closed',7,0,1);CREATE TABLE launch_access(account_id TEXT);INSERT INTO launch_access VALUES('allowed-player');")
  self.live=object.__new__(m.Live);self.live.database=self.game;self.live.accounts_config={'database':str(self.accounts)};self.live.accounts_unit='accounts';self.live.unit='game';self.live.port=32100;self.live.inode=self.live.db_inode()
  self.panel={'phase':'waiting','revision':7,'jobsEnabled':True,'approvedRevision':7,'manualReset':None,'configurationPaused':False,'configurationResuming':False}
  self.states={'accounts':'active','game':'active'};self.service_calls=[]
  def service(unit,action):self.service_calls.append((unit,action));self.states[unit]='inactive'
  for target,value in [('local',lambda *a:self.panel.copy()),('prop',lambda unit,field:self.states[unit]),('service',service)]:
   p=patch.object(m,target,value);p.start();self.addCleanup(p.stop)
  self.live.central=lambda rev:self.live.pin_update_policy(self.panel['phase'],rev)
 def mode(self,mode,enabled=1,revision=7,deadline=0):
  with sqlite3.connect(self.accounts) as db:db.execute('UPDATE launch_settings SET mode=?,enabled=?,revision=?,maintenance_deadline_ms=?',(mode,enabled,revision,deadline))
 def test_manual_prereg_allows_running_simulation_but_preserves_access(self):
  before=self.accounts.read_bytes();self.assertEqual(self.live.maintenance(),7);self.live.stop_services();self.assertEqual(self.accounts.read_bytes(),before);self.assertEqual(self.service_calls,[('game','stop'),('accounts','stop')]);self.assertEqual(self.live._update_policy,('waiting',7))
 def test_maintenance_still_requires_drain(self):
  self.mode('maintenance');self.panel.update(phase='maintenance',jobsEnabled=False,approvedRevision=None)
  self.assertEqual(self.live.maintenance(),7);self.live.stop_services()
  self.panel['jobsEnabled']=True
  with self.assertRaises(m.Refused):self.live.maintenance()
 def test_open_normal_ended_unknown_refused(self):
  for phase in ['open','normal','ended',None]:
   self.panel['phase']=phase
   with self.subTest(phase=phase),self.assertRaises(m.Refused):self.live.maintenance()
  self.assertFalse(self.service_calls)
 def test_busy_configuration_reset_and_stale_approval_refused(self):
  for field,value in [('configurationPaused',True),('configurationResuming',True),('manualReset',{'pending':True}),('approvedRevision',6),('jobsEnabled',None)]:
   old=self.panel[field];self.panel[field]=value
   with self.subTest(field=field),self.assertRaises(m.Refused):self.live.maintenance()
   self.panel[field]=old
 def test_waiting_paused_world_allowed(self):
  self.panel.update(jobsEnabled=False,approvedRevision=None);self.assertEqual(self.live.maintenance(),7)
 def test_active_player_admin_or_admission_refused(self):
  for table,column,value in [('game_presence','expires_at_ms',int(time.time()*1000)+100000),('players','last_seen',int(time.time())),('kernel511_admissions','id','allowed-player')]:
   with sqlite3.connect(self.game) as db:db.execute(f'INSERT INTO {table}({column}) VALUES(?)',(value,))
   with self.subTest(table=table),self.assertRaisesRegex(m.Refused,'aktif_oyuncu'):self.live.maintenance()
   with sqlite3.connect(self.game) as db:db.execute(f'DELETE FROM {table}')
  self.assertFalse(self.service_calls)
 def test_admission_between_preflight_and_stop_refused(self):
  self.live.maintenance()
  with sqlite3.connect(self.game) as db:db.execute("INSERT INTO kernel511_admissions VALUES('late-allowed-player')")
  with self.assertRaisesRegex(m.Refused,'aktif_oyuncu'):self.live.stop_services()
 def test_mode_or_revision_changed_during_stop_refused(self):
  self.live.maintenance()
  for mode,revision in [('open',7),('scheduled',7),('closed',8),('maintenance',7)]:
   self.mode(mode,revision=revision)
   with self.subTest(mode=mode,revision=revision),self.assertRaises(m.Refused):self.live.stop_services()
 def test_offline_modes_enabled_deadline_and_revision(self):
  self.states['accounts']='inactive'
  for mode,enabled,deadline in [('open',1,0),('scheduled',1,0),('closed',0,0),('maintenance',1,int(time.time()*1000)+60000)]:
   self.mode(mode,enabled=enabled,deadline=deadline)
   with self.subTest(mode=mode,enabled=enabled),self.assertRaises(m.Refused):self.live.offline_maintenance()
 def test_central_policy_pin_cannot_change(self):
  self.live.pin_update_policy('waiting',7)
  for phase,rev in [('waiting',8),('maintenance',7),('open',7),('waiting',True)]:
   with self.subTest(phase=phase,rev=rev),self.assertRaises(m.Refused):self.live.pin_update_policy(phase,rev)
if __name__=='__main__':unittest.main(verbosity=2)
