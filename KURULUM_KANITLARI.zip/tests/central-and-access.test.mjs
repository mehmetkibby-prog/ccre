import assert from 'node:assert/strict';
import test from 'node:test';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import {randomBytes} from 'node:crypto';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {DatabaseSync} from 'node:sqlite';
import {createLaunchService,ensureLaunchSchema} from '/workspace/ccre/r62_reward_recovery_work/trees/R62_FIX/working/native510-bb3a6cc689c6/vds-server/src/launch-service.mjs';
import {RealmServiceVerifier} from '/workspace/ccre/r62_reward_recovery_work/trees/R62_FIX/working/native510-bb3a6cc689c6/vds-server/src/realm-service-auth.mjs';
const run=promisify(execFile),root='/workspace/ccre/r62_reward_recovery_work/trees/R62_FIX/working';
function dbFixture(){const db=new DatabaseSync(':memory:');db.exec("CREATE TABLE accounts(id TEXT PRIMARY KEY);INSERT INTO accounts VALUES('owner'),('permitted'),('waiting');");ensureLaunchSchema(db,{accountsOnly:true});db.prepare("UPDATE launch_settings SET enabled=1,mode='closed',revision=7 WHERE id=1").run();return {db,launch:createLaunchService(db,{accountsOnly:true})};}
test('native preregistration permission controls gameplay without opening public access',()=>{
 const {db,launch}=dbFixture();try{
  assert.equal(launch.status('permitted').canPlay,false);assert.equal(launch.status('waiting').canPlay,false);
  launch.grant('permitted',true);
  for(const id of ['permitted','waiting']){const s=launch.status(id);assert.equal(s.phase,'waiting');assert.equal(s.registrationOpen,true);assert.equal(s.canPlay,id==='permitted');}
  assert.equal(launch.settings().mode,'closed');assert.equal(launch.settings().revision,7);
  launch.grant('permitted',false);assert.equal(launch.status('permitted').canPlay,false);
 }finally{db.close();}
});
test('real signed installer reads accept only drained maintenance or manual preregistration',async t=>{
 const {db,launch}=dbFixture(),dir=fs.mkdtempSync(path.join(os.tmpdir(),'r63-update-policy-')),key=randomBytes(32);
 fs.writeFileSync(path.join(dir,'key'),key.toString('hex'));let deny=false,blocked=false,race=false,calls=[];
 const verifier=new RealmServiceVerifier(new Map([['r1',key]]));
 const server=http.createServer(async(req,res)=>{try{
  let body='';for await(const b of req)body+=b;
  const route=req.headers['x-col-service-path'];assert.equal(req.url,'/api/realm/internal');assert(verifier.verify({method:req.method,pathname:route,headers:req.headers,body}));
  const data=JSON.parse(body);calls.push({route,data});if(deny){res.writeHead(403);res.end('{"error":"denied"}');return;}
  let reply;if(route==='/internal/maintenance/status')reply=launch.controlState();
  else if(route==='/internal/security/check')reply={blocked,securityVersion:1};
  else {assert.equal(route,'/internal/admin');assert.equal(data.resource,'launch');assert.equal(data.method,'GET');assert.equal(data.actorId,'owner');assert.equal(data.securityVersion,1);reply={settings:launch.settings(),status:launch.status()};if(race)db.exec("UPDATE launch_settings SET mode='open',revision=revision+1");}
  res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(reply));
 }catch(e){res.writeHead(500);res.end(JSON.stringify({error:e.message}));}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const game=path.join(dir,'game.json'),accounts=path.join(dir,'accounts.json'),manifest=path.join(dir,'manifest.json');
 fs.writeFileSync(manifest,JSON.stringify({authPort:server.address().port}));fs.writeFileSync(game,JSON.stringify({realm:{keyFile:path.join(dir,'key'),id:'r1',manifestFile:manifest}}));fs.writeFileSync(accounts,JSON.stringify({environment:{ADMIN_USER_ID:'owner'}}));
 const script=fs.readFileSync(new URL('./central-policy.mjs',import.meta.url),'utf8');
 const invoke=expected=>run(process.execPath,['--input-type=module','-e',script,root,game,accounts,'7',expected],{timeout:10000});
 const set=(mode,enabled=1,deadline=0)=>{deny=false;blocked=false;race=false;calls=[];db.prepare('UPDATE launch_settings SET mode=?,enabled=?,revision=7,maintenance_deadline_ms=?,public_opens_at=?').run(mode,enabled,deadline,Date.now()+3600000);};
 try{
  await t.test('manual preregistration preserves granted access and all settings',async()=>{set('closed');launch.grant('permitted',true);const before=JSON.stringify(launch.settings()),access=db.prepare('SELECT * FROM launch_access').all();assert.deepEqual(JSON.parse((await invoke('waiting')).stdout),{phase:'waiting',revision:7});assert.equal(JSON.stringify(launch.settings()),before);assert.deepEqual(db.prepare('SELECT * FROM launch_access').all(),access);assert.equal(launch.status('permitted').canPlay,true);assert.equal(launch.status('waiting').canPlay,false);assert.equal(calls.filter(c=>c.route==='/internal/admin').length,1);});
  await t.test('maintenance past deadline accepted',async()=>{set('maintenance',1,Date.now()-1000);assert.equal(JSON.parse((await invoke('maintenance')).stdout).phase,'maintenance');});
  for(const [name,mode,enabled,deadline,expected] of [['open','open',1,0,'waiting'],['disabled closed','closed',0,0,'waiting'],['scheduled waiting','scheduled',1,0,'waiting'],['maintenance grace','maintenance',1,Date.now()+60000,'maintenance']])await t.test(name+' rejected',async()=>{set(mode,enabled,deadline);await assert.rejects(invoke(expected));});
  await t.test('revision changed during authenticated lookup rejected',async()=>{set('closed');race=true;await assert.rejects(invoke('waiting'));});
  await t.test('blocked configured owner rejected',async()=>{set('closed');blocked=true;await assert.rejects(invoke('waiting'));});
  await t.test('central authorization failure rejected',async()=>{set('closed');deny=true;await assert.rejects(invoke('waiting'));});
 }finally{await new Promise(r=>server.close(r));db.close();fs.rmSync(dir,{recursive:true,force:true});}
});
