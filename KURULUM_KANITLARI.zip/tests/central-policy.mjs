
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
const [root,g,a,rev,expected]=process.argv.slice(1),revision=Number(rev);
const read=p=>JSON.parse(fs.readFileSync(p,'utf8')),game=read(g);
const {maintenanceClient}=await import(pathToFileURL(root+'/core511-source/scripts/delivery511/maintenance-client.mjs'));
const client=maintenanceClient({gameConfig:game,accountsConfig:read(a),manifest:read(game.realm.manifestFile)});
const p=await client.policy();
if(!Number.isSafeInteger(revision)||revision<1||p.revision!==revision||expected&&p.phase!==expected)
 throw Error('update_policy_changed');
if(p.phase==='maintenance'){
 if(!Number.isSafeInteger(p.deadlineMs)||p.deadlineMs>Date.now())throw Error('maintenance_not_drained');
}else if(p.phase==='waiting'){
 const {settings,status}=await client.admin({resource:'launch',method:'GET'});
 if(settings?.mode!=='closed'||settings.enabled!==1||settings.revision!==revision||status?.phase!=='waiting'||status.revision!==revision)
  throw Error('manual_preregistration_required');
 const latest=await client.policy();
 if(latest.phase!=='waiting'||latest.revision!==revision)throw Error('update_policy_changed');
}else throw Error('maintenance_or_manual_preregistration_required');
process.stdout.write(JSON.stringify({phase:p.phase,revision}));
