from pathlib import Path
import contextlib,hashlib,importlib.util,io,json,sqlite3,sys,unittest,zipfile
from unittest.mock import patch
R=Path(__file__).resolve().parents[1];E=R/'installer-evidence'
def module(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
base=module('fixture',R/'build/installer-fixture.py');m=base.m;RealLive=m.Live;wrapper=module('wrapper',R/'build/combined.py')
class RoundTrip(base.Installer):
 mode='closed'
 base_version='R61'
 def setUp(self):
  super().setUp();outer=self;oldLive=m.Live;self.states={'coreoflife-r1.service':'active','coreoflife-accounts.service':'active'}
  self.accounts=self.dir/'accounts.sqlite'
  with sqlite3.connect(self.accounts) as db:
   db.executescript('CREATE TABLE launch_settings(id INTEGER PRIMARY KEY,mode TEXT,revision INTEGER,maintenance_deadline_ms INTEGER,enabled INTEGER);CREATE TABLE launch_access(account_id TEXT,granted_at INTEGER);CREATE TABLE accounts(id TEXT PRIMARY KEY,username TEXT);')
   db.execute('INSERT INTO launch_settings VALUES(1,?,119,0,1)',(self.mode,));db.execute("INSERT INTO accounts VALUES('permitted','TestPlayer')");db.execute("INSERT INTO launch_access VALUES('permitted',1234)")
  class Live(oldLive):
   pin_update_policy=RealLive.pin_update_policy
   maintenance=RealLive.maintenance
   offline_maintenance=RealLive.offline_maintenance
   empty=RealLive.empty
   stop_services=RealLive.stop_services
   def __init__(live):
    super().__init__();live.port=32100;live.accounts_config={'database':str(outer.accounts)}
   def central(live,revision):
    with sqlite3.connect(outer.accounts) as db:mode,rev,enabled=db.execute('SELECT mode,revision,enabled FROM launch_settings').fetchone()
    m.require(rev==revision and (mode=='maintenance' or mode=='closed' and enabled==1),'signed_policy_rejected')
    live.pin_update_policy('maintenance' if mode=='maintenance' else 'waiting',rev)
   def start_services(live,revision):
    outer.actions.append('start');outer.states[live.accounts_unit]='active';live.central(revision);outer.states[live.unit]='active';live.ready(revision);m.startup_verify(live)
    if outer.fail_start:outer.fail_start=False;raise m.Refused('injected_health_failure')
   def ready(live,revision):live.maintenance(revision)
  def local(port,route):
   with sqlite3.connect(self.accounts) as db:mode,rev=db.execute('SELECT mode,revision FROM launch_settings').fetchone()
   waiting=mode=='closed';return {'phase':'waiting' if waiting else mode,'revision':rev,'jobsEnabled':waiting,'approvedRevision':rev if waiting else None,'manualReset':None,'configurationPaused':False,'configurationResuming':False}
  old_prop=m.prop
  def prop(unit,field):return self.states[unit] if field=='ActiveState' else old_prop(unit,field)
  def service(unit,action):
   self.assertEqual(action,'stop');self.states[unit]='inactive'
   if unit=='coreoflife-r1.service':self.actions.append('stop')
  for name,value in [('Live',Live),('local',local),('prop',prop),('service',service)]:
   p=patch.object(m,name,value);p.start();self.addCleanup(p.stop)
  self.Live=Live
 def run_main(self,*args):
  out=io.StringIO();original=wrapper.workflow
  def dispatch(game,site,argv):
   def run(command):
    with patch.object(sys,'argv',command[1:]):m.main()
    return ''
   return original(game,site,argv,run=run)
  try:
   with patch.object(wrapper,'workflow',side_effect=dispatch),contextlib.redirect_stdout(out),contextlib.redirect_stderr(out):wrapper.main(R/'artifacts/CORE511_R63_DUZELTILMIS.zip',['--game-only',*args])
  finally:
   with (E/(self.mode+'-roundtrip.log')).open('a') as f:f.write('\n$ '+' '.join(args)+'\n'+out.getvalue())
  return out.getvalue()
 def install_original_r62(self):
  import types
  prior=R.parent/'r62_polish_work/candidate/CORE_OF_LIFE_R62.zip'
  self.assertEqual(hashlib.sha256(prior.read_bytes()).hexdigest(),'bc5e319debdb97bb641dcec514fe3ce69efffa69a99741f3308b6d46efcea6b6')
  with zipfile.ZipFile(prior) as z:raw=z.read('GAME_R62.zip')
  archive=self.dir/'original-r62.zip';archive.write_bytes(raw)
  with zipfile.ZipFile(archive) as z:source=z.read('__main__.py');metadata=json.loads(z.read('patch.json'))
  ref=types.ModuleType('original_r62');ref.__file__=str(archive);exec(compile(source,str(archive),'exec'),ref.__dict__)
  values={'STATE':self.state,'BACKUPS':self.dir/'r62-prior-backups','Live':self.Live,'R61_SYSTEMD_ROOT':self.systemd,'prop':m.prop,'command':m.command}
  with contextlib.ExitStack() as stack,contextlib.redirect_stdout(io.StringIO()),contextlib.redirect_stderr(io.StringIO()):
   for key,value in values.items():stack.enter_context(patch.object(ref,key,value))
   stack.enter_context(patch.object(sys,'argv',[str(archive),'--base-package',str(self.dir/'CORE511_R46.zip'),'--apply']))
   ref.main()
  self.assertIn('hotfixR62_POLISH',json.loads(self.state.read_text()));self.actions.clear()
 def test_roundtrip_failure_recovery_flags_and_current_database(self):
  self.build_r56_fixture()
  if self.base_version=='R62':self.install_original_r62()
  (self.dir/'CORE511_R46.zip').unlink();before=self.snapshot();accounts=self.accounts.read_bytes();db_inode=self.db.stat().st_ino
  check=self.run_main('--check');self.assertIn('\"taban\": \"'+self.base_version+'\"',check);self.assertEqual(self.snapshot(),before);self.assertEqual(self.actions,[])
  self.fail_start=True
  with self.assertRaisesRegex(m.Refused,'injected_health_failure'):self.run_main('--apply')
  self.assertEqual(self.snapshot(),before);self.assertEqual(self.accounts.read_bytes(),accounts);self.actions.clear()
  self.run_main('--apply');self.assertEqual(self.actions,['stop','start']);self.actions.clear()
  self.assertEqual(self.accounts.read_bytes(),accounts);self.assertIn('hotfixR63_RECOVERY',json.loads(self.state.read_text()))
  installed=self.snapshot();self.run_main('--apply');self.assertEqual(self.snapshot(),installed);self.assertEqual(self.actions,[])
  self.run_main('--set-flag','CORE511_R62_REWARD_RECOVERY=0');self.run_main('--set-flag','CORE511_R62_REWARD_RECOVERY=1');self.assertEqual(self.accounts.read_bytes(),accounts)
  with sqlite3.connect(self.db) as db:db.execute("UPDATE players SET gems=gems+123 WHERE id='real-1'")
  current=self.db.read_bytes();self.run_main('--rollback-latest');self.assertEqual(self.snapshot(),before);self.assertEqual(self.db.stat().st_ino,db_inode);self.assertEqual(self.db.read_bytes(),current);self.assertEqual(self.accounts.read_bytes(),accounts)
  result={'status':'PASS','mode':self.mode,'base':self.base_version,'sourceCore':self.spec['afterCore'],'checks':['read-only check','automatic rollback after injected health failure','apply and R63 marker','idempotent existing R63','feature switch off/on','rollback preserves current game database','entire accounts database unchanged including launch_access and mode','real empty-server checks before and after stop'],'serviceHealthAndSignedCentralMocked':True,'rootSimulatedByFakeroot':True,'actualZipNodeSQLiteBackupAndRollback':True,'liveDeployment':False}
  (E/(self.mode+'-roundtrip.json')).write_text(json.dumps(result,indent=2)+'\n')
class Maintenance(RoundTrip):mode='maintenance'
class Preregistration(RoundTrip):
 mode='closed'
 base_version='R62'
if __name__=='__main__':
 suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(c) for c in [Maintenance,Preregistration]);result=unittest.TextTestRunner(verbosity=2).run(suite);sys.exit(not result.wasSuccessful())
