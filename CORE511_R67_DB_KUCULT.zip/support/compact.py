"""R67 game DB compaction, with registrations online and durable recovery."""
import argparse
import contextlib
import json
import os
from pathlib import Path
import stat
import subprocess
import time
import zipfile

import compact_db as dbtools
import installer as m
from storage import atomic, descriptor, digest, encoded, journal, lock, read, require, sync_dir

ROOT = Path('/var/lib/core511/db-compact-r67')
ACTIVE = ROOT / 'active.json'
RESERVE = 512 * 1024**2
MIN_FREE = 64 * 1024**2


def say(value):
    print(value, flush=True)


def private(folder, create=False):
    if create:
        folder.mkdir(mode=0o700, parents=True, exist_ok=True)
    st = folder.lstat()
    require(folder.resolve() == folder and stat.S_ISDIR(st.st_mode) and st.st_uid == 0
            and stat.S_IMODE(st.st_mode) == 0o700, 'İşlem dizini güvenli değil')


def other_operation():
    require(not [p for p in m.STATE.parent.glob('*/active.json') if p != ACTIVE],
            'Başka bir kurulum/sıfırlama yarım kalmış')


def write_record(folder, record, phase):
    record['phase'] = phase
    journal(folder / 'journal.json', record)
    journal(ACTIVE, {'directory': str(folder), 'phase': phase})


def guard_file(unit):
    return m.SYSTEMD / (unit + '.d') / '97-core511-db-compact.conf'


def guards(record, enable):
    body = ('[Unit]\nConditionPathExists=!' + str(ACTIVE) + '\n').encode()
    for unit in record['guardUnits']:
        require(unit in (record['gameUnit'], record['rtUnit']), 'Servis kapsamı değişmiş')
        file = guard_file(unit)
        if file.exists():
            require(not file.is_symlink() and file.read_bytes() == body, 'Başka servis koruması var')
        if enable:
            atomic(file, body, 0o644)
        elif file.exists():
            file.unlink()
            sync_dir(file.parent)
    m.reload_units()


def unchanged(live, record, restarting=False):
    other_operation()
    require(digest(m.STATE) == record['stateSHA256'] and digest(live.config_file) == record['configSHA256'],
            'Oyun kurulumu veya yapılandırması değişti')
    require(descriptor(live.database) == record['database']
            and list(dbtools.identity(live.database)) == record['fileIdentity'],
            'Veritabanı kimliği veya izinleri değişti')
    if restarting:
        now = live.accounts_identity()
        require({k: v for k, v in now.items() if k not in ('pid', 'start')} ==
                {k: v for k, v in record['accounts'].items() if k not in ('pid', 'start')},
                'Hesap servisinin ayarı veya veritabanı değişti')
        record['accounts'] = now
    else:
        live.account_stable(record['accounts'])


def stop(record):
    for unit in reversed(record['guardUnits']):
        m.service(unit, 'stop')
        require(m.prop(unit, 'ActiveState') in ('inactive', 'failed'), 'Oyun servisi durmadı')


def quiet(record):
    """Refuse all other open DB/sidecar handles; permission errors fail closed."""
    file = Path(record['database']['path'])
    ids = set()
    for suffix in ('', '-wal', '-shm', '-journal'):
        p = Path(str(file) + suffix)
        if p.exists():
            st = p.stat()
            ids.add((st.st_dev, st.st_ino))
    for process in Path('/proc').iterdir():
        if not process.name.isdigit():
            continue
        try:
            for fd in (process / 'fd').iterdir():
                try:
                    st = fd.stat()
                except FileNotFoundError:
                    continue
                require((st.st_dev, st.st_ino) not in ids, 'Veritabanını kullanan süreç var: ' + process.name)
        except (FileNotFoundError, ProcessLookupError):
            continue


def backup_lock(live):
    folder = live.database.parent / 'backups'
    require(folder.is_dir() and not folder.is_symlink() and folder.resolve() == folder,
            'Oyun günlük yedek dizini doğrulanamadı')
    p = folder / '.backup.lock'
    require(p.is_file() and not p.is_symlink(), 'Oyun günlük yedek kilidi yok')
    return lock(p)


def space(live, sizes):
    need = sizes['logicalBytes'] * 2 + RESERVE
    for p in (ROOT, live.database.parent):
        st = os.statvfs(p)
        require(st.f_bavail * st.f_frsize >= need,
                'Güvenli çalışma kopyası için boş alan yetersiz; veritabanı değiştirilmedi')


def clean_working(folder):
    # Only the throwaway copy inside this tool's private journal directory.
    for suffix in ('', '-wal', '-shm', '-journal'):
        p = folder / ('working.sqlite' + suffix)
        if p.exists():
            st = p.lstat()
            require(p.resolve() == p and stat.S_ISREG(st.st_mode) and st.st_uid == 0 and st.st_nlink == 1,
                    'Çalışma kopyası yolu değişmiş')
            p.unlink()
    sync_dir(folder)


def snapshot_check(folder, record):
    file = folder / 'compact.sqlite'
    require(list(dbtools.identity(file)) == record['snapshotIdentity']
            and digest(file) == record['snapshotSHA256'], 'Doğrulanmış küçültme kopyası değişmiş')
    return file


def finish(live, folder, record):
    # Once starting is durable, NEVER restore a DB snapshot: the restarted
    # game may already have committed newer world state or owner/admin changes.
    unchanged(live, record)
    write_record(folder, record, 'starting')
    guards(record, False)
    for unit in record['units']:
        if m.prop(unit, 'ActiveState') != 'active':
            m.service(unit, 'start')
    live.ready(record)
    unchanged(live, record)
    write_record(folder, record, 'validated')
    live.central('restore', record['policy'])
    write_record(folder, record, 'complete')
    clean_working(folder)
    ACTIVE.unlink()
    sync_dir(ROOT)


def recover(live):
    marker = read(ACTIVE)
    folder = Path(marker['directory'])
    require(folder.parent == ROOT, 'Kurtarma dizini kapsamı geçersiz')
    private(folder)
    record = read(folder / 'journal.json')
    require(record['version'] == 'R67_DB_COMPACT' and record['gameUnit'] == live.unit
            and record['rtUnit'] == live.rt_unit and record['units'][0] == live.unit
            and set(record['units']) <= set(record['guardUnits']) <= {live.unit, live.rt_unit},
            'Kurtarma kaydı kapsamı farklı')
    unchanged(live, record, restarting=True)
    phase = record['phase']
    require(phase in ('prepared', 'gated', 'stopped', 'snapshotting', 'snapshot_ready', 'publishing',
                      'published', 'verified', 'starting', 'validated', 'complete'), 'Kurtarma aşaması tanınmıyor')
    if phase in ('starting', 'validated', 'complete'):
        # Do not stop or overwrite an already restarted live game.
        finish(live, folder, record)
        say('KURTARMA TAMAMLANDI. Yeni oyun kayıtları korundu.')
        return
    if phase in ('publishing', 'published', 'verified'):
        require(all(m.prop(u, 'ActiveState') in ('inactive', 'failed') for u in record['guardUnits']),
                'Koruma dışında oyun açılmış; yeni kayıtların üzerine yazılmadı')
    guards(record, True)
    stop(record)
    quiet(record)
    with dbtools.exclusive(live.database) as db:
        if phase in ('publishing', 'published', 'verified'):
            snapshot = snapshot_check(folder, record)
            # SQLite rolls back an interrupted backup transaction on reopening.
            # A healthy but different DB might contain newer records; never
            # overwrite it just because an old recovery snapshot is available.
            dbtools.integrity(db)
            require(dbtools.fingerprint(db) == record['fingerprint'],
                    'Kurtarma sırasında yeni/farklı kayıt bulundu; üzerine yazılmadı')
            dbtools.publish(snapshot, db, live.database, record['fingerprint'], record['journalMode'])
        else:
            dbtools.integrity(db)
            if record.get('fingerprint'):
                require(dbtools.fingerprint(db) == record['fingerprint'], 'Hazırlıktaki oyun kayıtları değişmiş')
        unchanged(live, record)
    finish(live, folder, record)
    say('KURTARMA TAMAMLANDI. Oyun ve hesap kayıtları korundu.')


def apply(live, plan):
    require(live.state.get('r64Deployment', {}).get('version') == 'R67_ENTRY', 'Önce R67 kurulmalı')
    m.initial_core(live, plan)
    live.active_binding()
    live.health()
    policy = live.central()
    require(m.allowed_policy(policy) and policy['realm']['status'] in ('open', 'maintenance'),
            'Ön kayıt veya bakım modu gerekli; oyundaysanız çıkıp 45 saniye bekleyin')
    with contextlib.closing(dbtools.connect(live.database, True)) as db:
        sizes = dbtools.size(db)
    say('Oyun DB: %.2f GiB; boş sayfalar: %.2f GiB' %
        (sizes['logicalBytes'] / 2**30, sizes['freeBytes'] / 2**30))
    if sizes['freeBytes'] < MIN_FREE:
        say('Küçültme gerekmiyor; oyun servisleri durdurulmadı.')
        return
    space(live, sizes)
    live.empty()
    units = [live.unit]
    guarded = [live.unit]
    if m.prop(live.rt_unit, 'LoadState') != 'not-found':
        guarded.append(live.rt_unit)
        if m.prop(live.rt_unit, 'ActiveState') == 'active':
            units.append(live.rt_unit)
    folder = ROOT / (time.strftime('%Y%m%dT%H%M%SZ', time.gmtime()) + '-' + os.urandom(4).hex())
    folder.mkdir(mode=0o700)
    record = {'version': 'R67_DB_COMPACT', 'accounts': live.accounts_identity(), 'policy': policy,
              'database': descriptor(live.database), 'fileIdentity': list(dbtools.identity(live.database)),
              'stateSHA256': digest(m.STATE), 'configSHA256': digest(live.config_file),
              'gameUnit': live.unit, 'rtUnit': live.rt_unit, 'units': units, 'guardUnits': guarded,
              'before': sizes}
    write_record(folder, record, 'prepared')
    try:
        live.central('gate', policy)
        write_record(folder, record, 'gated')
        guards(record, True)
        stop(record)
        quiet(record)
        live.empty()
        unchanged(live, record)
        write_record(folder, record, 'stopped')
        with dbtools.exclusive(live.database) as db:
            dbtools.integrity(db)
            record['fingerprint'] = dbtools.fingerprint(db)
            record['journalMode'] = db.execute('PRAGMA journal_mode').fetchone()[0]
            record['before'] = dbtools.size(db)
            write_record(folder, record, 'snapshotting')
            snapshot = dbtools.make_snapshot(db, folder, record['fingerprint'])
            record['snapshotSHA256'] = digest(snapshot)
            record['snapshotIdentity'] = list(dbtools.identity(snapshot))
            write_record(folder, record, 'snapshot_ready')
            unchanged(live, record)
            require(m.same_policy(live.central(), policy), 'Hazırlık sırasında açılış ayarı değişti')
            clean_working(folder)
            write_record(folder, record, 'publishing')
            dbtools.publish(snapshot_check(folder, record), db, live.database,
                            record['fingerprint'], record['journalMode'])
            record['after'] = dbtools.size(db)
            unchanged(live, record)
            write_record(folder, record, 'published')
        write_record(folder, record, 'verified')
        finish(live, folder, record)
        say('KÜÇÜLTME TAMAMLANDI. Oyun kayıtları ve ayarlar doğrulandı; dört kanal hazır.')
        say('Oyun DB: %.2f GiB → %.2f GiB. Ön kayıt servisi yeniden başlatılmadı.' %
            (record['before']['logicalBytes'] / 2**30, record['after']['logicalBytes'] / 2**30))
    except BaseException:
        say('İşlem tamamlanamadı; kayıtlar korunarak kurtarma deneniyor.')
        try:
            if ACTIVE.exists():
                recover(live)
        except BaseException:
            say('Kurtarma tamamlanamadı. Aynı paketi --recover ile çalıştırın; hesap servisi açık bırakıldı.')
        raise


def main(archive, argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    for flag in ('inspect', 'apply', 'recover'):
        action.add_argument('--' + flag, action='store_true')
    args = parser.parse_args(argv)
    require(os.geteuid() == 0, 'Root olarak çalıştırın')
    with zipfile.ZipFile(archive) as z:
        plan = json.loads(z.read('update.json'))
    with lock(m.STATE.parent / 'r23-backups/install.lock'):
        other_operation()
        live = m.Live()
        if args.inspect:
            with contextlib.closing(dbtools.connect(live.database, True)) as db:
                say(json.dumps(dbtools.size(db), ensure_ascii=False))
            return
        private(ROOT, create=True)
        with backup_lock(live):
            if ACTIVE.exists():
                say('Yarım kalan küçültme denetleniyor.')
                recover(live)
            else:
                require(not args.recover, 'Yarım küçültme kaydı yok')
                apply(live, plan)
        subprocess.run(['df', '-h', '/'], check=True)
