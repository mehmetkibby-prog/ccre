"""Offline SQLite compaction with exact records, schema and rowid preservation."""
import contextlib
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import stat
import time

from storage import require, sync_dir


def quote(name):
    return '"' + name.replace('"', '""') + '"'


def identity(file):
    file = Path(file)
    st = file.lstat()
    require(file.resolve() == file and stat.S_ISREG(st.st_mode) and st.st_nlink == 1,
            'Veritabanı yolu normal, tek bağlantılı dosya olmalı')
    return (st.st_dev, st.st_ino, st.st_uid, st.st_gid, stat.S_IMODE(st.st_mode))


def connect(file, readonly=False):
    return sqlite3.connect(Path(file).as_uri() + ('?mode=ro' if readonly else '?mode=rw'),
                           uri=True, timeout=3, isolation_level=None)


def size(db):
    total, page, free = (db.execute('PRAGMA ' + name).fetchone()[0]
                         for name in ('page_count', 'page_size', 'freelist_count'))
    return {'logicalBytes': total * page, 'freeBytes': free * page, 'pageSize': page}


def value_bytes(value):
    return json.dumps(value, ensure_ascii=True, separators=(',', ':'),
                      default=lambda x: {'blob': x.hex()}).encode()


def table_specs(db):
    specs = []
    for namespace, name, kind, _, without_rowid, _ in db.execute('PRAGMA table_list'):
        if namespace != 'main' or name == 'sqlite_schema' or kind == 'view':
            continue
        require(kind == 'table', 'Sanal/gölge tablo desteklenmiyor: ' + name)
        cols = list(db.execute('PRAGMA table_xinfo(' + quote(name) + ')'))
        names = [r[1] for r in cols]
        hidden = None
        if not without_rowid and not name.startswith('sqlite_'):
            hidden = next((n for n in ('_rowid_', 'rowid', 'oid')
                           if n not in {c.lower() for c in names}), None)
            require(hidden is not None, 'Gizli kayıt kimliği okunamıyor: ' + name)
        specs.append({'name': name, 'columns': names, 'rowid': hidden,
                      'writable': [r[1] for r in cols if r[6] == 0]})
    return sorted(specs, key=lambda x: x['name'])


def fingerprint(db):
    """No row contents logged. Include implicit rowids used by game cursors."""
    schema = db.execute('SELECT type,name,tbl_name,sql FROM sqlite_schema ORDER BY type,name').fetchall()
    output = {'schema': hashlib.sha256(value_bytes(schema)).hexdigest(), 'tables': {},
              'meta': {n: db.execute('PRAGMA ' + n).fetchone()[0]
                       for n in ('user_version', 'application_id', 'page_size', 'encoding', 'auto_vacuum')}}
    for spec in table_specs(db):
        cols = ([spec['rowid']] if spec['rowid'] else []) + spec['columns']
        selection = ','.join(map(quote, cols))
        order = '1' if spec['rowid'] else ','.join(str(i + 1) + ' COLLATE BINARY' for i in range(len(cols)))
        h = hashlib.sha256()
        count = 0
        last = time.monotonic()
        for row in db.execute('SELECT ' + selection + ' FROM ' + quote(spec['name']) + ' ORDER BY ' + order):
            data = value_bytes(row)
            h.update(len(data).to_bytes(8, 'big'))
            h.update(data)
            count += 1
            if time.monotonic() - last > 5:
                print('Kayıtlar doğrulanıyor: ' + spec['name'], flush=True)
                last = time.monotonic()
        output['tables'][spec['name']] = {'count': count, 'sha256': h.hexdigest()}
    foreign = sorted(db.execute('PRAGMA foreign_key_check').fetchall(), key=value_bytes)
    output['foreignKeys'] = hashlib.sha256(value_bytes(foreign)).hexdigest()
    return output


def integrity(db):
    require(db.execute('PRAGMA integrity_check').fetchall() == [('ok',)],
            'SQLite sağlamlık kontrolü başarısız')


@contextlib.contextmanager
def progress(db, message, timeout=1200):
    start = time.monotonic()
    last = [start]
    def tick():
        now = time.monotonic()
        if now - last[0] >= 5:
            print(message + ': ' + str(int(now - start)) + ' sn', flush=True)
            last[0] = now
        return int(now - start > timeout)
    db.set_progress_handler(tick, 10000)
    try:
        yield
    finally:
        db.set_progress_handler(None, 0)


def sync_file(path):
    with Path(path).open('rb') as f:
        os.fsync(f.fileno())
    sync_dir(Path(path).parent)


def backup(src, dst):
    start = time.monotonic()
    last = [start]
    def tick(status, remaining, total):
        now = time.monotonic()
        require(now - start < 1200, 'SQLite kopyalama süresi doldu')
        if now - last[0] >= 5:
            print('Veritabanı kopyalanıyor: %' + str(int(100 * (total - remaining) / max(1, total))), flush=True)
            last[0] = now
    src.backup(dst, pages=2048, progress=tick, sleep=.05)


def make_snapshot(src, folder, expected):
    """Work on a private copy. The live connection stays exclusively locked."""
    working = folder / 'working.sqlite'
    compact = folder / 'compact.sqlite'
    require(not working.exists() and not compact.exists(), 'Hazırlık dosyası zaten var')
    fd = os.open(working, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    os.close(fd)
    with contextlib.closing(connect(working)) as work:
        work.execute('PRAGMA synchronous=FULL')
        backup(src, work)
        require(fingerprint(work) == expected, 'Çalışma kopyasında kayıtlar eşleşmedi')
        added = []
        existing = {r[0] for r in work.execute('SELECT name FROM sqlite_schema')}
        for spec in table_specs(work):
            if not spec['rowid'] or list(work.execute('PRAGMA index_list(' + quote(spec['name']) + ')')):
                continue
            # SQLite preserves hidden rowids during VACUUM when a table has an
            # index. Add one only in the throwaway copy, then remove it below.
            require(spec['writable'], 'İndekslenebilir sütun bulunamadı')
            name = 'compact_r67_' + hashlib.sha256(spec['name'].encode()).hexdigest()[:24]
            require(name not in existing, 'Geçici indeks adı çakışıyor')
            work.execute('CREATE INDEX ' + quote(name) + ' ON ' + quote(spec['name']) + '(' + quote(spec['writable'][0]) + ')')
            added.append(name)
        with progress(work, 'Boş sayfalar çıkarılıyor'):
            work.execute('VACUUM INTO ?', (str(compact),))
    os.chmod(compact, 0o600)
    with contextlib.closing(connect(compact)) as db:
        db.execute('PRAGMA synchronous=FULL')
        for name in added:
            db.execute('DROP INDEX ' + quote(name))
        # Checkpoint only this private snapshot, never a running game database.
        if db.execute('PRAGMA journal_mode').fetchone()[0] == 'wal':
            require(db.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()[0] == 0, 'Kopya WAL kapatılamadı')
        integrity(db)
        require(fingerprint(db) == expected, 'Küçültülmüş kopya kayıt/şema/kimlik eşleşmedi')
    sync_file(compact)
    return compact


@contextlib.contextmanager
def exclusive(file):
    """Caller has stopped guarded game services and owns scheduled-backup lock."""
    ident = identity(file)
    with contextlib.closing(connect(file)) as db:
        db.execute('PRAGMA synchronous=FULL')
        db.execute('PRAGMA locking_mode=EXCLUSIVE')
        db.execute('BEGIN EXCLUSIVE')
        db.execute('COMMIT')
        require(identity(file) == ident, 'Veritabanı kimliği değişti')
        yield db
        require(identity(file) == ident, 'Veritabanı kimliği/izinleri değişti')


def publish(src_file, dst, file, expected, journal_mode):
    with contextlib.closing(connect(src_file, True)) as source:
        integrity(source)
        require(fingerprint(source) == expected, 'Kurtarma kopyası eşleşmiyor')
        backup(source, dst)
    require(dst.execute('PRAGMA journal_mode').fetchone()[0] == journal_mode,
            'Veritabanı günlük biçimi değişti')
    if journal_mode == 'wal':
        require(dst.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()[0] == 0,
                'Durdurulmuş oyun WAL dosyası kapatılamadı')
    integrity(dst)
    require(fingerprint(dst) == expected, 'Canlı dosyada kayıt/şema/kimlik eşleşmedi')
    sync_file(file)
