"""R67 cleanup: obsolete staging copies, verified duplicate downloads and caches."""
import argparse,hashlib,json,os,re,sqlite3,stat,subprocess,sys,time,zipfile
from pathlib import Path
import installer as m
import retention
from storage import atomic,descriptor,digest,encoded,journal,lock,read,require,sync_dir

DATA=Path('/var/lib/core511');DOWNLOADS=Path('/var/tmp');ARCHIVES=Path('/root')

def regular(p):
 s=p.lstat()
 require(stat.S_ISREG(s.st_mode) and s.st_uid==0 and s.st_nlink==1 and p.resolve()==p,'Normal, özel root dosyası değil: '+str(p))
 parent=p.parent.lstat()
 require(stat.S_ISDIR(parent.st_mode) and parent.st_uid==0 and not parent.st_mode&0o022,'Dosyanın üst dizini özel değil: '+str(p.parent))
 return (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)

def sqlite_header(p):
 regular(p)
 with p.open('rb') as f:return f.read(16)==b'SQLite format 3\x00'

def bound_record(record,live):
 return record.get('databases')=={'game':descriptor(live.database),'accounts':descriptor(live.accounts_database)}

def process_files():
 identities=set()
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   for fd in (proc/'fd').iterdir():
    try:s=fd.stat();identities.add((s.st_dev,s.st_ino))
    except FileNotFoundError:pass
  except (FileNotFoundError,ProcessLookupError):continue
 return identities

def candidates(live):
 for folder in (DATA,DATA/'launch-reset-r63',DATA/'r63-recovery-backups'):
  if folder.exists():
   s=folder.lstat();require(stat.S_ISDIR(s.st_mode) and s.st_uid==0 and not s.st_mode&0o022 and folder.resolve()==folder,'İşlem dizini izinleri değişmiş: '+str(folder))
 require(not list(DATA.glob('*/active.json')),'Yarım kurulum/sıfırlama var; temizlik yapılmadı')
 result=[];skipped=[]
 live_ids={(descriptor(p)['device'],descriptor(p)['inode']) for p in (live.database,live.accounts_database)}
 opened=process_files();external=retention.system_references()
 def add(file,kind,record_file):
  if not file.exists() and not file.is_symlink():return
  try:
   info=regular(file);require(info[:2] not in live_ids|opened,'Dosya canlı veya açık')
   require(not retention.references(external,{file}),'Dosyaya çalışan servis/süreç başvuruyor')
   result.append({'path':str(file),'identity':info,'bytes':file.stat().st_blocks*512,'kind':kind,
                  'journal':str(record_file) if record_file else None,'journalSHA256':digest(record_file) if record_file else None})
  except (OSError,RuntimeError) as e:skipped.append({'path':str(file),'reason':str(e)})
 reset=DATA/'launch-reset-r63'
 if reset.exists():
  require(not reset.is_symlink() and reset.resolve()==reset,'Sıfırlama dizini yolu değişmiş')
  for record_file in sorted(reset.glob('*/journal.json')):
   try:
    regular(record_file);record=read(record_file);folder=record_file.parent
    require(record.get('version')==1 and record.get('phase') in ('complete','recovered') and bound_record(record,live),'Tamamlanmış, aynı DB’ye ait sıfırlama değil')
    require(all(sqlite_header(folder/(role+'-before.sqlite')) for role in ('game','accounts')),'Korunacak geri dönüş çifti bulunamadı')
    for role in ('game','accounts'):
     file=folder/(role+'-clean.sqlite')
     if file.exists():require(sqlite_header(file),'Hazırlık kopyası tanınmıyor')
     for suffix in ('','-wal','-shm','-journal'):add(Path(str(file)+suffix),'completed reset staging',record_file)
   except (OSError,RuntimeError,ValueError) as e:skipped.append({'path':str(record_file.parent),'reason':str(e)})
 recovery=DATA/'r63-recovery-backups'
 if recovery.exists():
  require(not recovery.is_symlink() and recovery.resolve()==recovery,'Kurtarma dizini yolu değişmiş')
  for record_file in sorted(recovery.glob('*/journal.json')):
   try:
    regular(record_file);record=read(record_file);root=Path(record.get('root',''))
    require(root.is_absolute() and root.parent==m.RELEASES and root!=live.root and record.get('unit')==live.unit,'Eski kurulum kaydı tanınmıyor')
    require(record.get('status') in ('prepared','installed','rolled_back') and isinstance(record.get('files'),list),'Kurulum aşaması belirsiz')
    for suffix in ('','-wal','-shm','-journal'):add(record_file.parent/('game.sqlite.partial'+suffix),'obsolete partial install snapshot',record_file)
    # A final verified snapshot can only be removed after a completed install or rollback.
    meta=record.get('databaseBackup',{});file=record_file.parent/'game.sqlite'
    if record['status'] in ('installed','rolled_back') and meta.get('file')=='game.sqlite' and meta.get('status')=='verified' and file.exists():
     info=regular(file)
     require(info[:3]==(meta['dev'],meta['ino'],meta['bytes']),'Geçici kurulum yedeği kimliği farklı')
     add(file,'obsolete completed install snapshot',record_file)
   except (OSError,RuntimeError,ValueError,KeyError) as e:skipped.append({'path':str(record_file.parent),'reason':str(e)})
 # Only exact duplicate downloaded ZIPs with a surviving /root original.
 originals={}
 for p in ARCHIVES.glob('*.zip'):
  if not re.fullmatch(r'(?:CORE511|CORE_OF_LIFE)_R[0-9]+_[A-Za-z0-9_]+\.zip',p.name):continue
  try:
   info=regular(p)
   if info[2]<=100*1024**2:originals.setdefault(info[2],[]).append(p)
  except (OSError,RuntimeError):continue
 known={}
 for folder in DOWNLOADS.iterdir() if DOWNLOADS.exists() else []:
  if not re.fullmatch(r'(?:core-r\d+(?:-fix)?|core-reset-r\d+|r\d+-fix|col-mobil)-[A-Za-z0-9_-]+',folder.name):continue
  if folder.is_symlink() or not folder.is_dir() or folder.resolve()!=folder:continue
  if retention.references(external,{folder}):continue
  for p in folder.glob('*.zip'):
   try:
    info=regular(p)
    if info[2] not in originals:continue
    h=digest(p)
    for original in originals[info[2]]:
     oh=known.setdefault(str(original),digest(original))
     if h==oh:
      add(p,'duplicate download',None)
      if result and result[-1]['path']==str(p):result[-1].update(original=str(original),originalSHA256=h)
      break
   except (OSError,RuntimeError):continue
 return {'files':result,'skipped':skipped,'allocatedBytes':sum(row['bytes'] for row in result)}

def apply_files(live,plan,recheck):
 audit=DATA/'disk-cleanup-r67';audit.mkdir(mode=0o700,exist_ok=True)
 require(not audit.is_symlink() and audit.resolve()==audit and audit.stat().st_uid==0 and stat.S_IMODE(audit.stat().st_mode)==0o700,'Temizlik günlüğü izinleri değişmiş')
 log=audit/(time.strftime('%Y%m%dT%H%M%S')+'-'+os.urandom(4).hex()+'.json')
 saved={'phase':'planned','files':plan['files'],'deleted':[]};journal(log,saved)
 for row in plan['files']:
  recheck();p=Path(row['path']);require(regular(p)==tuple(row['identity']),'Temizlenecek dosya değişmiş')
  require(tuple(row['identity'][:2]) not in process_files(),'Dosya bir süreç tarafından açıldı')
  require(not retention.references(retention.system_references(),{p}),'Dosya artık kullanılıyor')
  if row['journal']:
   record_file=Path(row['journal']);regular(record_file);require(digest(record_file)==row['journalSHA256'],'İşlem günlüğü değişmiş')
   if row['kind']=='completed reset staging':
    require(all(sqlite_header(p.parent/(role+'-before.sqlite')) for role in ('game','accounts')),'Korunacak geri dönüş yedeği değişmiş')
  if row.get('original'):
   original=Path(row['original']);regular(original);require(digest(original)==row['originalSHA256']==digest(p),'Orijinal indirme değişmiş')
  saved['deleting']=str(p);journal(log,saved);p.unlink();sync_dir(p.parent)
  saved['deleted'].append(str(p));journal(log,saved);print('Temizlendi: '+str(p),flush=True)
 saved['phase']='complete';journal(log,saved);return saved

def main(archive):
 p=argparse.ArgumentParser(description=__doc__);a=p.add_mutually_exclusive_group(required=True);a.add_argument('--inspect',action='store_true');a.add_argument('--apply',action='store_true');args=p.parse_args()
 require(os.geteuid()==0,'Root olarak çalıştırın')
 with zipfile.ZipFile(archive) as z:plan=json.loads(z.read('update.json'))
 with lock(DATA/'r23-backups/install.lock'):
  live=m.Live();require(live.state.get('r64Deployment',{}).get('version')=='R67_ENTRY','Önce R67 kurulmalı')
  m.initial_core(live,plan);live.active_binding();live.health(empty=False);identity=live.accounts_identity();state_sha=digest(m.STATE)
  def recheck():
   require(digest(m.STATE)==state_sha and not list(DATA.glob('*/active.json')),'Kurulum durumu değişmiş')
   live.account_stable(identity);live.active_binding();live.health(empty=False)
  # Share both native scheduled-backup locks; no running backup is interrupted.
  import contextlib
  with contextlib.ExitStack() as stack:
   for parent in sorted({live.database.parent,live.accounts_database.parent}):
    folder=parent/'backups';require(folder.is_dir() and not folder.is_symlink(),'Günlük yedek dizini doğrulanamadı')
    file=folder/'.backup.lock';require(file.is_file() and not file.is_symlink(),'Günlük yedek kilidi bulunamadı')
    stack.enter_context(lock(file))
   selected=candidates(live);print('Temizlenebilir dosyalar: '+str(round(selected['allocatedBytes']/1024**3,2))+' GiB',flush=True)
   for row in selected['files']:print('ADAY: '+row['path'],flush=True)
   for row in selected['skipped']:print('KORUNDU: '+row['path']+' ('+row['reason']+')',flush=True)
   print('KORUNUR: canlı veritabanları, günlük yedekler, sıfırlama öncesi yedek çifti, oyun sürümleri.',flush=True)
   if not args.apply:return
   recheck();apply_files(live,selected,recheck)
  # Package cache is redownloadable; journalctl removes only archived journals.
  for cmd in (['apt-get','clean'],['journalctl','--rotate','--vacuum-size=500M']):
   recheck();print('Sistem temizliği: '+' '.join(cmd),flush=True)
   try:
    result=subprocess.run(cmd,timeout=60)
    if result.returncode:print('Bu sistem temizliği tamamlanamadı; oyun dosyaları korunuyor.',flush=True)
   except (OSError,subprocess.TimeoutExpired):print('Bu sistem temizliği atlandı.',flush=True)
  recheck();print('TEMİZLİK TAMAMLANDI. Oyun ve kayıt servisleri yeniden başlatılmadı.',flush=True)
  subprocess.run(['df','-h','/'],check=True)
