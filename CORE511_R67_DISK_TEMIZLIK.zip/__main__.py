import hashlib,json,os,sys,tempfile,zipfile
from pathlib import Path
archive=Path(sys.argv[0]).resolve();os.umask(0o077)
try:
 with zipfile.ZipFile(archive) as z,tempfile.TemporaryDirectory(prefix='core-cleanup-r67-') as temp:
  manifest=json.loads(z.read('modules.json'));expected={'installer.py','storage.py','r63_support.py','retention.py','central.mjs','cleanup.py'}
  if set(manifest)!=expected:raise RuntimeError('Paket dosya listesi bozuk')
  for name,sha in manifest.items():
   data=z.read('support/'+name)
   if hashlib.sha256(data).hexdigest()!=sha:raise RuntimeError('Paket bütünlüğü bozuk')
   (Path(temp)/name).write_bytes(data)
  sys.path.insert(0,temp);from cleanup import main
  main(archive)
except BlockingIOError:
 print('DURDU: Başka bir kurulum veya yedek çalışıyor. Bitince aynı komutu tekrar çalıştırın.',flush=True);sys.exit(1)
except (Exception,KeyboardInterrupt) as e:
 print('DURDU: '+(str(e) if isinstance(e,RuntimeError) else type(e).__name__),flush=True);sys.exit(1)
