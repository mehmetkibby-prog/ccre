"""Core of Life R63: verified game and website installers in one download."""
import hashlib,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path

def execute(command):
 result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 print(result.stdout,end='',flush=True)
 if result.returncode:raise subprocess.CalledProcessError(result.returncode,command,output=result.stdout)
 return result.stdout

def workflow(game,site,args,run=execute):
 if '--game-only' in args:return run([*game,*[a for a in args if a!='--game-only']])
 if '--site-only' in args:return run([*site,*[a for a in args if a!='--site-only']])
 if args and args[0] in ('--flags','--set-flag'):return run([*game,*args])
 if len(args)!=1 or args[0] not in ('--check','--apply','--rollback-latest'):
  raise ValueError('Kullanım: python3 CORE511_R63_DUZELTILMIS.zip --check | --apply | --rollback-latest | --flags | --set-flag ANAHTAR=0\nAyrı sunucular/özel yollar için: --game-only veya --site-only ve ilgili kurucunun seçenekleri.')
 action=args[0]
 # Both concrete preflights must pass before either component is changed.
 game_state=run([*game,'--check']);run([*site,'--check'])
 if action=='--check':return
 if action=='--rollback-latest':
  run([*site,'--rollback-latest']);run([*game,'--rollback-latest']);return
 fresh=False
 for line in game_state.splitlines():
  try:row=json.loads(line)
  except ValueError:continue
  if isinstance(row,dict) and row.get('uygun') is True and row.get('taban') in ('R61','R62'):fresh=True
 run([*game,'--apply'])
 try:run([*site,'--apply'])
 except Exception:
  # Site installer restores its prior site on failure. Roll back only a game
  # install performed by this invocation, never an already installed R63.
  if fresh:
   try:run([*game,'--rollback-latest'])
   except Exception as error:print('Otomatik oyun geri alma tamamlanamadı: '+str(error),file=sys.stderr)
  raise
 print('R63 oyun ve ön kayıt sitesi kuruldu. Seçtiğiniz bakım veya ön kayıt modu korundu; oyunu admin panelinden açabilirsiniz.')

def main(archive=None,args=None):
 args=list(sys.argv[1:] if args is None else args)
 if not args or args==['--help']:
  print(__doc__+'\n--check  --apply  --rollback-latest  --flags  --set-flag ANAHTAR=0\n--game-only / --site-only: yalnız ilgili bileşeni çalıştır.');return
 with tempfile.TemporaryDirectory(prefix='core-r63-') as folder,zipfile.ZipFile(archive or sys.argv[0]) as z:
  manifest=json.loads(z.read('BUNDLE.json'));paths={}
  for key,name in (('game','GAME_R63.zip'),('site','SITE_R62.zip'),('proof','CORE511_R46.zip')):
   data=z.read(name);meta=manifest['files'][name]
   if len(data)!=meta['bytes'] or hashlib.sha256(data).hexdigest()!=meta['sha256']:raise ValueError('Paket bütünlüğü doğrulanamadı: '+name)
   path=Path(folder)/name;path.write_bytes(data);os.chmod(path,0o600);paths[key]=[sys.executable,str(path)]
  if '--base-package' not in args:paths['game'].extend(['--base-package',paths['proof'][1]])
  workflow(paths['game'],paths['site'],args)

if __name__=='__main__':
 try:main()
 except Exception as error:print('DURDURULDU: '+str(error),file=sys.stderr);sys.exit(1)
